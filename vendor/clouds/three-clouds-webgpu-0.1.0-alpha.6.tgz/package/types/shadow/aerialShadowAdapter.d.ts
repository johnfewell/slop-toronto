import { Node, TextureNode } from 'three/webgpu';
import { AerialPerspectiveNode } from '@takram/three-atmosphere/webgpu';
export declare function assertAerialShadowInputs(node: object): void;
export declare function aerialPerspectiveWithCloudShadow(colorNode: Node<'vec4'>, depthNode: Node<'float'> | TextureNode, shadowLengthNode: Node<'vec2'> | null, shadowNode: Node<'float'> | null, normalNode?: Node<'vec3'> | TextureNode, lightingMaskNode?: Node<'float'> | null): AerialPerspectiveNode;
