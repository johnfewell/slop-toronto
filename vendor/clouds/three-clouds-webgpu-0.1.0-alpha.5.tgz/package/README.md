# three-clouds-webgpu

A standalone WebGPU / TSL port of
[@takram/three-clouds](https://github.com/takram-design-engineering/three-geospatial)
0.7.6, the geospatial volumetric clouds library, for the
[three.js](https://threejs.org/) `WebGPURenderer`.

**This is an unofficial port.** It is not affiliated with, endorsed by, or
supported by takram, and it claims no API ownership or maintenance commitment
over the original. The original library, its design and its shaders are by
**Shota Matsuda / [takram](https://github.com/takram-design-engineering)**, MIT
licensed. This port follows them module by module and cites the original at
every ported function.

## Status

- **Feature-complete.** The clouds march, cloud layers, cloud shadows, light
  shafts and haze are all ported.
- **Beyond the original, opt-in.** Named cloud-type presets, a cloud-type map
  for regional variation, evolving weather on a wind field, towering
  convection, seeded procedural weather maps, cloud-shape controls, rain
  shafts, lightning, moonlight, clouds in the environment map (with a Water Pro
  sky adapter), a static rendering mode for still scenes and a cirrus deck.
  Each is off by default and documented with its cost in
  [docs/EXPERIMENTAL.md](docs/EXPERIMENTAL.md).
- **Parity with the WebGL original:** 57 pass, 5 documented expected
  differences and 1 fail, over 63 A/B cases captured on hardware.
  `node scripts/verify-results.mjs` prints every case's verdict from the
  committed metrics. The one fail is a cloud-shadow case, see
  [Known differences](#known-differences). An earlier run reported 0 fails
  because both sides shared a wrong shadow range; fixing it exposed 13 shadow
  differences, and the committed metrics are where those stand now.
- **Performance:** at library defaults the port is faster than the WebGL
  original at DPR 1 and slower at DPR 2, in a real scene. Storybook Basic, both
  sides at their own defaults, uncapped rAF mean frame, N=5, ABBA order, on an
  Apple M4 Mac mini: **0.92x** the original's frame time at DPR 1 and **1.11x**
  at DPR 2. With settings matched in the parity harness it took **1.38x to
  1.71x** across the four state-matched cases, dominated by the cloud-shadow
  pass rather than by the march. Measured 2026-10-04 at commit `f52bcea9`;
  [docs/BENCHMARKS.md](docs/BENCHMARKS.md) has the protocol, the September 2026
  figures these replace, and what moved between them. Since then commit
  `648d3a94` skips the shadow march's weather read when no layer casts a
  shadow, which cuts the
  port's frame by 26 % at 1280x720 and 32 % at 2560x1440 on the harness
  baseline. Library defaults cast shadows, so the Storybook figures are
  unchanged.
- **Not on npm.** Install from a tarball you pack from a clone, see below.

## Relation to the takram packages

The port does not fork takram's code base. It is a **consumer** of the
published WebGPU builds that already exist, and it reimplements only the clouds:

- `@takram/three-atmosphere` and `@takram/three-geospatial` are **peer
  dependencies**. The atmosphere model, the ellipsoid maths and the WebGPU node
  helpers come from there, at their published versions.
- `@takram/three-clouds` (the WebGL original) is **not a dependency** of the
  library. It is installed by `examples/parity` and `examples/storybook` as the
  A-side reference the port is compared against, which is what makes the parity
  ladder and the side-by-side stories possible, and its sources are vendored
  read-only under `reference/` for diffing against the port.
- Anything this port adds is additive: new node outputs, `enabled`, `time`,
  `frame`, `warnings`, `debug`, `resetHistory()` and `dispose()`. The complete
  1:1 mapping from the original's public surface is
  [docs/MIGRATION.md](docs/MIGRATION.md).

Because the WebGPU packages are consumed at their published versions rather than
vendored, a change takram publishes upstream reaches this port on the next
install.

## Install

Not published to npm. Build the package from a clone and pack it:

```bash
git clone https://github.com/johnfewell/three-clouds-webgpu.git
cd three-clouds-webgpu
corepack enable            # pins pnpm 11.8.0 via packageManager
pnpm install --frozen-lockfile
pnpm build
pnpm pack                  # writes three-clouds-webgpu-<version>.tgz
```

Then add the tarball to your project, for example from a `vendor/` folder:

```bash
pnpm add three-clouds-webgpu@file:vendor/three-clouds-webgpu-<version>.tgz
pnpm add three@0.184.0 @takram/three-atmosphere@0.19.1 @takram/three-geospatial@0.9.1
```

Building requires Node 24. Rendering requires a browser with WebGPU. The
package ships the four baked textures at `three-clouds-webgpu/assets/*`;
[WEBGPU.md](WEBGPU.md#baked-assets) shows how to resolve or serve them.

The peer range is `three >=0.184.0 <0.185.0`; Quick start explains why. A
clone on r185 builds and runs, because `pnpm install` applies
`patches/three.patch`, but that patch does not ship in the tarball.

## Quick start

Requirements:

- A browser with WebGPU (Chrome, or another with native WebGPU). The WebGL2
  fallback backend is refused, as the original does not support it either.
- Peer dependencies: `@takram/three-atmosphere` 0.19.1, `@takram/three-geospatial`
  0.9.1, and **`three` r184**.
- **Use `three` r184.** On r185 the published `@takram` packages crash on
  import, at `@takram/three-atmosphere/build/webgpu.js`, for every entrypoint:
  they read `struct().layout` at module-evaluation time and r185 removed that
  from `three`. This is upstream's defect, not something this package can work
  around — the fix used while developing here (`patches/three.patch`) is not
  part of the published tarball, so there is nothing for you to apply. r184
  imports cleanly unpatched and is what this package is verified against.
  Tracked upstream as
  [three-geospatial#111](https://github.com/takram-design-engineering/three-geospatial/issues/111);
  the peer range widens once it is fixed.

The canonical wiring is the [Usage snippet in WEBGPU.md](WEBGPU.md#usage). It
is the source of [examples/basic](examples/basic/src/main.ts), and a test keeps
the two identical, so the documented wiring cannot drift.

In short: build the pass with `clouds({ sceneDepth })`, add `layerNode` and
`depthVelocityNode` to the scene pass's multiple render targets, then assign
`cloudsPass.composite(output)` as the post-processing output. Every knob lives
on `cloudsPass.cloudsContext`, and `time` and `frame` are yours to advance.
WEBGPU.md covers the API, performance settings and the changes from the WebGL
API.

## Examples

- **`examples/basic`** — the minimal plain Three.js consumer ([examples/basic/src/main.ts](examples/basic/src/main.ts)).
- **`examples/tiles`** — Google Photorealistic 3D Tiles with clouds, atmosphere, and cloud shadows on tiles ([examples/tiles/README.md](examples/tiles/README.md)).
- **`examples/r3f`** — React Three Fiber consumer with `<Clouds>` ([examples/r3f/README.md](examples/r3f/README.md)).
- **`examples/storybook`** — interactive Storybook stories ([examples/storybook/README.md](examples/storybook/README.md)).
- **`examples/parity`** — the 63-case A/B visual comparison ladder ([examples/parity/README.md](examples/parity/README.md)).

## Live demo

- Storybook (live): https://three-clouds-webgpu-demo.netlify.app (needs a WebGPU
  browser; the WebGL original's stories sit beside the port's, one sidebar
  click away). The port's section also has stories for the cloud types,
  convection, evolving weather, the night sky, the cloud environment map, the
  other opt-in experiments, and showcase stories for lightning, rain shafts,
  scene presets and static mode.
- A side-by-side demo video (the original vs the port) is also available. It
  is not stored in this repository.

To run the stories from a clone:

```bash
pnpm --filter clouds-storybook dev --port 6008
```

Then open
`http://localhost:6008/?path=/story/clouds-webgpu-clouds--basic`. The Basic and
Custom Layers stories need no credentials. The 3D Tiles stories need a Google
Maps Platform key or a Cesium Ion token, passed as `STORYBOOK_GOOGLE_MAP_API_KEY`
and `STORYBOOK_ION_API_TOKEN` in `.env.local`; see
[examples/storybook/README.md](examples/storybook/README.md#credentials).

## Features

- A volumetric cloud march with up to four cloud layers, density profiles,
  and the original's baked textures (or procedural ones)
- Cascaded cloud shadow maps on the scene and in the aerial perspective
- Light shafts (crepuscular rays) and haze
- Temporal upscaling or full-resolution temporal anti-aliasing
- The original's quality presets and knob names (the
  [migration table](docs/MIGRATION.md) maps every WebGL property)
- Cloud variety, opt-in: six named cloud-type presets
  (`applyCloudTypePreset`: fair-weather cumulus, stratocumulus deck, overcast
  sheet, high cirrus, ground fog, mixed sky), a cloud-type map that varies
  shape by location, evolving weather on a wind field, towering convection with
  anvils, and seeded procedural weather maps
- Opt-in renderer experiments (compute resolve, wind reprojection, distant cloud
  shadows, directional skylight), documented with their cost in
  [docs/EXPERIMENTAL.md](docs/EXPERIMENTAL.md)
- Opt-in sky features: cloud-shape controls (darker bases, a horizon coverage
  bank, wind shear, edge shape), rain shafts under convective cells, lightning
  flashes, moonlit clouds, a cirrus deck, clouds in `scene.environmentNode`
  (and a `WaterProCloudSky` adapter for Water Pro), and a static mode that
  skips the cloud passes once a still scene has converged
- Whole-scene helpers: `syncCelestialDirections` sets the sun and moon from a
  place and an instant, and `applyScenePreset` picks a sky by name
- Reference mode: `applyReferenceMode` pins every port-only default to the
  original's behaviour, and `applyPortDefaults` restores the defaults
- A React Three Fiber `<Clouds>` component

## Known differences

- **Procedural textures.** The original's compiled Worley loop differs from
  its own source. The port follows the source, so procedural local weather
  differs. Baked textures are unaffected
  ([ADR-014](docs/adr/014-worley-compiled-path-divergence.md)).
- **Debug views** (cascades, sample count, front depth) are not pixel-parity
  ([ADR-011 Amendment 6](docs/adr/011-parity-methodology.md)), and the shadow
  map view differs only in a channel that does not affect rendering
  ([ADR-011 Amendment 13](docs/adr/011-parity-methodology.md)).
- **The atmosphere uses its LUT lookup.** One case, `below-deck-1km`, keeps
  the raymarch
  ([ADR-013 Amendment 6](docs/adr/013-atmosphere-source-of-truth.md)).
- **Cloud shadows: one ladder case fails.** `layers-4-shadow` is held to a
  floor set before the shadow-range fix
  ([ADR-015](docs/adr/015-layers-4-shadow-temporal-shadow-resolve.md)), and its
  committed capture measures below it (SSIM 0.930 against 0.9715). It is
  committed as a fail, not waived. `shadow-sphere` and `shadow-cascades-2x512`,
  which failed in earlier captures, now pass.
- **Port-only defaults.** The shadow map updates every other frame, and light
  shafts are marched once per 2×2 quad. Setting `shadow.updateInterval = 1` or
  `lightShaftsHalfResolution = false` restores the original's behaviour
  ([WEBGPU.md](WEBGPU.md#performance)). Two experimental options also ship on:
  `cloudFrontRefinement` (cloud edges land on the real boundary) and
  `distantShapeDetailFade` (removes distant horizon speckle).
  `applyReferenceMode` turns all of these off at once.

Every design decision is recorded in the [ADRs](docs/adr/), with the evidence
that settled it.

## Contributing

[CONTRIBUTING.md](CONTRIBUTING.md) has the development setup, the checks, the
comment rules and how to propose a change.

## License and credits

[MIT](LICENSE). Copyright (c) 2024 Shota Matsuda (the original work this is
ported from) and (c) 2026 John Fewell (this port).

This is a port of **[@takram/three-clouds](https://github.com/takram-design-engineering/three-geospatial)**
by Shota Matsuda. Other adapted code, with every licence named and every
required notice reproduced, is registered in
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md): cascaded shadow maps from
[three-csm](https://github.com/StrandedKitty/three-csm/) and three.js, Perlin
noise from GLM, tileable volume noise from
[TileableVolumeNoise](https://github.com/sebh/TileableVolumeNoise), structured
volume sampling from [volsample](https://github.com/huwb/volsample), temporal
antialiasing from [Playdead](https://github.com/playdeadgames/temporal), and
Catmull-Rom texture sampling from
[TheRealMJP's gist](https://gist.github.com/TheRealMJP/c83b8c0f46b63f3a88a5986f4fa982b1).

No NVIDIA data ships in this repository. The default jitter volume is this
repository's own void-and-cluster blue noise, generated from a seed
([ADR-009](docs/adr/009-stbn-jitter-volume.md)); a Storybook knob still fetches
NVIDIA's spatiotemporal blue-noise dataset at runtime, in your browser, exactly
as the WebGL reference does, and NVIDIA's licence does not permit redistributing
it.
