import { Matrix4, Vector3, Camera, Vector2 } from 'three';
export declare class CameraUniforms {
    readonly viewMatrix: import('three/webgpu').UniformNode<"mat4", Matrix4>;
    readonly inverseViewMatrix: import('three/webgpu').UniformNode<"mat4", Matrix4>;
    readonly inverseProjectionMatrix: import('three/webgpu').UniformNode<"mat4", Matrix4>;
    readonly cameraNear: import('three/webgpu').UniformNode<"float", number>;
    readonly cameraFar: import('three/webgpu').UniformNode<"float", number>;
    readonly cameraPosition: import('three/webgpu').UniformNode<"vec3", Vector3>;
    readonly cameraPositionECEF: import('three/webgpu').UniformNode<"vec3", Vector3>;
    readonly cameraDirectionECEF: import('three/webgpu').UniformNode<"vec3", Vector3>;
    readonly reprojectionMatrix: import('three/webgpu').UniformNode<"mat4", Matrix4>;
    readonly viewReprojectionMatrix: import('three/webgpu').UniformNode<"mat4", Matrix4>;
    private previousProjectionMatrix;
    private previousViewMatrix;
    isPerspectiveCamera: boolean;
    update(camera: Camera, worldToECEFMatrix: Matrix4, temporal?: {
        frame: number;
        resolution: Vector2;
        jitterOut: Vector2;
    }): void;
    copyReprojectionMatrix(camera: Camera): void;
    resetPreviousMatrices(): void;
}
