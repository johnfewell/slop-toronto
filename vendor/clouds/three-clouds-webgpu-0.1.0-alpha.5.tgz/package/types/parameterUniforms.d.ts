import { Data3DTexture, Vector2, Texture, Vector3 } from 'three';
import { TextureNode, UniformNode } from 'three/webgpu';
import { CloudsContext } from './CloudsContext.js';
export interface ParameterUniforms {
    resolution: UniformNode<'vec2', Vector2>;
    frame: UniformNode<'float', number>;
    temporalJitter: UniformNode<'vec2', Vector2>;
    targetUvScale: UniformNode<'vec2', Vector2>;
    mipLevelScale: UniformNode<'float', number>;
    stbnTexture: TextureNode;
    scatteringCoefficient: UniformNode<'float', number>;
    absorptionCoefficient: UniformNode<'float', number>;
    minDensity: UniformNode<'float', number>;
    minExtinction: UniformNode<'float', number>;
    minTransmittance: UniformNode<'float', number>;
    localWeatherTexture: TextureNode;
    localWeatherRepeat: UniformNode<'vec2', Vector2>;
    localWeatherOffset: UniformNode<'vec2', Vector2>;
    coverage: UniformNode<'float', number>;
    shapeTexture: TextureNode;
    shapeRepeat: UniformNode<'vec3', Vector3>;
    shapeOffset: UniformNode<'vec3', Vector3>;
    shapeDetailTexture: TextureNode;
    shapeDetailRepeat: UniformNode<'vec3', Vector3>;
    shapeDetailOffset: UniformNode<'vec3', Vector3>;
    turbulenceTexture: TextureNode;
    turbulenceRepeat: UniformNode<'vec2', Vector2>;
    turbulenceDisplacement: UniformNode<'float', number>;
    hazeDensityScale: UniformNode<'float', number>;
    hazeExponent: UniformNode<'float', number>;
    hazeScatteringCoefficient: UniformNode<'float', number>;
    hazeAbsorptionCoefficient: UniformNode<'float', number>;
}
export interface OwnedPlaceholders {
    localWeather: Texture;
    turbulence: Texture;
    shape: Data3DTexture;
    shapeDetail: Data3DTexture;
    stbn: Data3DTexture;
}
export declare function createParameterUniforms(ctx: CloudsContext): ParameterUniforms & {
    placeholders: OwnedPlaceholders;
};
export declare function updateParameterUniforms(uniforms: ParameterUniforms & {
    placeholders: OwnedPlaceholders;
}, ctx: CloudsContext): void;
export declare function disposePlaceholders(placeholders: OwnedPlaceholders): void;
