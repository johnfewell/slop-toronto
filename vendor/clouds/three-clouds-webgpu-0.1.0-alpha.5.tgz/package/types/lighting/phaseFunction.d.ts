import { Node } from 'three/webgpu';
export declare function henyeyGreenstein(g1: number, g2: number, cosTheta: number): [number, number];
export declare function phaseFunction(cosTheta: number, attenuation: number, scatterAnisotropy1: number, scatterAnisotropy2: number, scatterAnisotropyMix: number): number;
export declare function draine(u: number, g: number, a: number): number;
export declare function accuratePhaseFunction(cosTheta: number, attenuation: number): number;
export declare function phaseFunctionDefault(cosTheta: number, scatterAnisotropy1: number, scatterAnisotropy2: number, scatterAnisotropyMix: number): number;
export declare const phaseFunctionTSL: import('three/src/nodes/TSL.js').FnNode<[number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
export declare const accuratePhaseFunctionTSL: import('three/src/nodes/TSL.js').FnNode<[number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
