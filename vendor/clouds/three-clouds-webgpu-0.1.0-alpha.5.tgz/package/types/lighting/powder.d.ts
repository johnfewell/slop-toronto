import { Node } from 'three/webgpu';
export declare const powderTerm: import('three/src/nodes/TSL.js').FnNode<[number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
