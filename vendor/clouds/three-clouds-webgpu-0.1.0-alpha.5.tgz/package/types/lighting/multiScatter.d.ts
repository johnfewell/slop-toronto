import { Node } from 'three/webgpu';
export declare function approximateMultipleScattering(opticalDepth: number, cosTheta: number, multiScatteringOctaves: number, scatterAnisotropy1: number, scatterAnisotropy2: number, scatterAnisotropyMix: number, accurate?: boolean): number;
export interface ApproxMultiScatterTSL {
    prepare: (cosTheta: Node<'float'>) => void;
    evaluate: (opticalDepth: Node<'float'>, cosTheta: Node<'float'>) => Node<'float'>;
}
export declare function createApproxMultiScatterTSL(multiScatteringOctaves: number, scatterAnisotropy1: Node<'float'>, scatterAnisotropy2: Node<'float'>, scatterAnisotropyMix: Node<'float'>, accurate?: boolean): ApproxMultiScatterTSL;
