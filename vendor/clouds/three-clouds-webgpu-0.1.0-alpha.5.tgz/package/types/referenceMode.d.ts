import { CloudsContext } from './CloudsContext.js';
import { CloudShapeParams } from './experimental/cloudShape.js';
import { ExperimentalCloudOptions } from './experimental/options.js';
export declare const PORT_DEFAULT_LIGHT_SHAFTS_HALF_RESOLUTION = true;
export declare const REFERENCE_SHADOW_UPDATE_INTERVAL = 1;
export declare const REFERENCE_EXPERIMENTAL: Readonly<ExperimentalCloudOptions>;
export declare const REFERENCE_CLOUD_SHAPE: Readonly<CloudShapeParams>;
export interface ReferenceModePins {
    readonly shadowUpdateInterval: number;
    readonly lightShaftsHalfResolution: boolean;
    readonly experimental: ExperimentalCloudOptions;
    readonly cloudShape: Readonly<CloudShapeParams>;
}
export declare const REFERENCE_MODE: ReferenceModePins;
export declare const REFERENCE_MODE_PORT_ONLY_PATHS: readonly string[];
export declare function referenceModePins(ctx: CloudsContext): ReferenceModePins;
export declare function applyReferenceMode(ctx: CloudsContext): boolean;
export declare function applyPortDefaults(ctx: CloudsContext): boolean;
