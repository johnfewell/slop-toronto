import { Storage3DTexture, StorageTexture, Node, Renderer, Texture } from 'three/webgpu';
export interface ProceduralTextureLike<T extends Texture = Texture> {
    readonly size: number;
    readonly texture: T;
    needsRender: boolean;
    render: (renderer: Renderer) => void;
    dispose: () => void;
}
export interface Procedural3DTextureParameters {
    size: number;
    generate: (point: Node<'vec3'>) => Node<'float'>;
}
export declare class Procedural3DTexture implements ProceduralTextureLike<Storage3DTexture> {
    readonly size: number;
    needsRender: boolean;
    readonly texture: Storage3DTexture;
    private readonly computeNode;
    constructor({ size, generate }: Procedural3DTextureParameters);
    render(renderer: Renderer): void;
    dispose(): void;
}
export interface ProceduralTexture2DParameters {
    size: number;
    generate: (uv: Node<'vec2'>) => Node<'vec4'>;
}
export declare class ProceduralTexture2D implements ProceduralTextureLike<StorageTexture> {
    readonly size: number;
    needsRender: boolean;
    readonly texture: StorageTexture;
    private readonly computeNode;
    constructor({ size, generate }: ProceduralTexture2DParameters);
    render(renderer: Renderer): void;
    dispose(): void;
}
