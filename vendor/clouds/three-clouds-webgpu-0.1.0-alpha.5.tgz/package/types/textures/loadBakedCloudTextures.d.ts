import { Data3DTexture, Texture } from 'three';
/** The four textures a {@link CloudsContext} marches against */
export interface BakedCloudTextures {
    localWeatherTexture: Texture;
    turbulenceTexture: Texture;
    shapeTexture: Data3DTexture;
    shapeDetailTexture: Data3DTexture;
}
/**
 * Where to fetch each of the four. The shapes are raw 3D payloads sized by
 * {@link CLOUD_SHAPE_TEXTURE_SIZE} and {@link CLOUD_SHAPE_DETAIL_TEXTURE_SIZE}
 * rather than images, so they cannot go through a `TextureLoader`.
 *
 * The defaults for all four are exported from the package root.
 */
export interface BakedCloudTextureUrls {
    localWeather: string;
    turbulence: string;
    shape: string;
    shapeDetail: string;
}
/**
 * Load the four baked assets the original ships, with the same filters and
 * wrapping it applies. Assign the result to the matching context properties:
 *
 * ```ts
 * const cloudsContext = cloudsPass.cloudsContext
 * const baked = await loadBakedCloudTextures({
 *   localWeather: DEFAULT_LOCAL_WEATHER_URL,
 *   turbulence: DEFAULT_TURBULENCE_URL,
 *   shape: DEFAULT_SHAPE_URL,
 *   shapeDetail: DEFAULT_SHAPE_DETAIL_URL
 * })
 * cloudsContext.localWeatherTexture = baked.localWeatherTexture
 * cloudsContext.shapeTexture = baked.shapeTexture
 * cloudsContext.shapeDetailTexture = baked.shapeDetailTexture
 * cloudsContext.turbulenceTexture = baked.turbulenceTexture
 * ```
 *
 * The 3D loads use `fetch`, so a cross-origin file:// page needs the assets
 * served over http. All four resolve or reject together.
 */
export declare function loadBakedCloudTextures(urls: BakedCloudTextureUrls): Promise<BakedCloudTextures>;
/**
 * The white-noise hash volume the jitter defaulted to before blue noise. It is
 * still exported because the parity harness samples it, and its bytes are part
 * of the ladder's committed evidence, so replacing the default with it would
 * move every captured metric.
 */
export declare function createHashJitterTexture(): Data3DTexture;
/**
 * The 128x128x64 blue-noise jitter volume the context uses when you do not
 * assign one, built offline by `scripts/generate-blue-noise.mjs` and embedded
 * as a rank map. Slice k is that map shifted by k times the golden ratio
 * conjugate, so consecutive slices decorrelate. Generated per call and cached
 * by {@link CloudsContext.stbnTexture}.
 *
 * To sample NVIDIA's STBN exactly as the original does instead, load it from
 * upstream and assign it (see ADR-009).
 */
export declare function createJitterTexture(): Data3DTexture;
