import { Node } from 'three/webgpu';
export declare const localWeather: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector2 | Node<"vec2">], import('three/webgpu').VarNode<"vec4", import('three/webgpu').JoinNode<"vec4">>>;
