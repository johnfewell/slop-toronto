import { Node } from 'three/webgpu';
export declare const perlinWorley: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"float">>;
export declare const worleyFbm: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"float">>;
export declare const cloudShape: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"float">>;
export declare const cloudShapeDetail: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"float">>;
