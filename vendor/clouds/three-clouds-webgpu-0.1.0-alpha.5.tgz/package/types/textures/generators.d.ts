import { Procedural3DTexture, ProceduralTexture2D, ProceduralTextureLike } from './ProceduralTexture.js';
export declare const TURBULENCE_SIZE = 128;
export declare const LOCAL_WEATHER_SIZE = 512;
export declare class CloudShape extends Procedural3DTexture {
    constructor();
}
export declare class CloudShapeDetail extends Procedural3DTexture {
    constructor();
}
export declare class Turbulence extends ProceduralTexture2D {
    constructor();
}
export declare class LocalWeather extends ProceduralTexture2D {
    constructor();
}
export type { ProceduralTextureLike };
