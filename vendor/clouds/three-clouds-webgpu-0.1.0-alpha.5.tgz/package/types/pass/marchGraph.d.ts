import { Camera } from 'three';
import { Node, NodeMaterial, StructNode, TextureNode } from 'three/webgpu';
import { CloudsContext } from '../CloudsContext.js';
import { CloudShadowDescriptor, UniformArrayLike } from '../CloudsPassNode.js';
import { CirrusDeckUniforms } from '../experimental/cirrusDeck.js';
import { CloudShapeDeps } from '../experimental/cloudShape.js';
import { CloudTypeBlendNodes } from '../experimental/cloudTypeMap.js';
import { ConvectiveDeps } from '../experimental/convectiveProfile.js';
import { EvolvingWeather } from '../experimental/evolvingWeather.js';
import { LightningUniforms } from '../experimental/lightning.js';
import { MoonlightNodes } from '../experimental/moonlight.js';
import { RainShaftDeps } from '../experimental/rainShafts.js';
import { WindHistory } from '../experimental/WindHistory.js';
import { LayerUniforms } from '../layerUniforms.js';
import { createGroundSunSkyIrradiance, createGroundSunSkyIrradianceInterpolated } from '../lighting/sunSkyLight.js';
import { buildCloudsFragment, CloudsFragmentDeps } from '../march/cloudsFragment.js';
import { MarchCloudsDeps } from '../march/primaryMarch.js';
import { createGetRayDistanceToScene } from '../march/sceneDepth.js';
import { createMarchShadowLength, createMarchShadowLengthQuadPartial, ShadowLengthMarchDeps } from '../march/shadowLengthMarch.js';
import { MarchUniforms } from '../marchUniforms.js';
import { ParameterUniforms } from '../parameterUniforms.js';
import { ShadowSamplerDeps } from '../shadow/sampleShadowOpticalDepth.js';
export declare function selectGroundSunSkyIrradiance(accurate: boolean, sunDirectionECEF: Parameters<typeof createGroundSunSkyIrradiance>[0], cache: Parameters<typeof createGroundSunSkyIrradianceInterpolated>[0]): ReturnType<typeof createGroundSunSkyIrradiance>;
export declare function cloudTypeBlend(ctx: CloudsContext, paramU: ParameterUniforms): CloudTypeBlendNodes | undefined;
export declare function createShadowLengthMarches(ctx: CloudsContext, marchU: MarchUniforms, sampleShadowOD: ShadowLengthMarchDeps['sampleShadowOpticalDepth'] | null, quadShadowLength: boolean): {
    marchShadowLengthFn: ReturnType<typeof createMarchShadowLength> | null;
    marchShadowLengthQuadPartialFn: ReturnType<typeof createMarchShadowLengthQuadPartial> | null;
};
export declare function buildDistantShadowExperiment(ctx: CloudsContext, deps: ShadowSamplerDeps): MarchCloudsDeps['sampleShadowOpticalDepth'];
export declare function buildLightningExperiment(ctx: CloudsContext, marchOpticalDepth: MarchCloudsDeps['marchOpticalDepth'], uniforms: LightningUniforms): Pick<MarchCloudsDeps, 'lightningInScatter'>;
export declare function buildSkylightExperiment(ctx: CloudsContext, marchU: MarchUniforms, layerU: LayerUniforms): Pick<MarchCloudsDeps, 'prepareSkylight' | 'skyLightModulation'>;
export declare function withMoonlight(producer: (position: Node<'vec3'>, height: Node<'float'>) => StructNode, moonlight: MoonlightNodes | null): (position: Node<'vec3'>, height: Node<'float'>) => StructNode;
export declare function buildMoonlight(ctx: CloudsContext, marchU: MarchUniforms): MoonlightNodes | null;
export declare function buildFragmentDeps(ctx: CloudsContext, marchU: MarchUniforms, layerU: LayerUniforms, paramU: ParameterUniforms, windHistory: WindHistory, cloudShadow: () => CloudShadowDescriptor, factories: Pick<CloudsFragmentDeps, 'marchClouds' | 'applyAerialPerspective' | 'getRayDistanceToScene' | 'stbn' | 'marchShadowLength' | 'marchShadowLengthQuadPartial' | 'approximateHaze' | 'marchRainShafts' | 'compositeCirrusDeck'>): CloudsFragmentDeps;
export declare function applyMarchFragmentNode(material: NodeMaterial, ctx: CloudsContext, fragOut: ReturnType<typeof buildCloudsFragment>): void;
export interface MarchGraphHost {
    ensureShadowRT(width: number, height: number, depth: number): void;
    cloudShadow: () => CloudShadowDescriptor;
    shadowFromECEF: UniformArrayLike<'mat4'>;
    viewZFromECEF: Node<'vec4'>;
    windHistory: WindHistory;
    weatherEvolution: EvolvingWeather;
    convectiveDeps: (ctx: CloudsContext, layerU: LayerUniforms, paramU: ParameterUniforms) => ConvectiveDeps | null;
    cloudShapeDeps: (ctx: CloudsContext) => CloudShapeDeps;
    rainShaftDeps: (ctx: CloudsContext, layerU: LayerUniforms, paramU: ParameterUniforms) => RainShaftDeps | null;
    lightningUniforms: LightningUniforms;
    cirrusDeckUniforms: (ctx: CloudsContext) => CirrusDeckUniforms | null;
}
export interface MarchFactoryOverrides {
    maxIterationCount?: Node<'float'>;
    maxIterationCountToSun?: Node<'float'>;
    cloudFrontRefinement?: boolean;
    shadows?: boolean;
    shapeDetail?: boolean;
}
export declare function buildMarchFactories(ctx: CloudsContext, marchU: MarchUniforms, layerU: LayerUniforms, paramU: ParameterUniforms, quadShadowLength: boolean, host: MarchGraphHost, overrides?: MarchFactoryOverrides): {
    marchClouds: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, import('three').Vector2 | Node<"vec2">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], StructNode>;
    applyAerialPerspective: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, import('three').Vector4 | Node<"vec4">], import('three/webgpu').VarNode<"vec4", import('three/webgpu').JoinNode<"vec4">>>;
    stbn: Node<"float">;
    marchShadowLength: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, import('three').Vector2 | Node<"vec2">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"float", import('three/webgpu').VarNode<"float", import('three/webgpu').ConstNode<"float", number>>>> | null;
    marchShadowLengthQuadPartial: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, import('three').Vector2 | Node<"vec2">, number | Node<"float"> | Node<"uint">, Node<"int">], import('three/webgpu').VarNode<"float", import('three/webgpu').VarNode<"float", import('three/webgpu').ConstNode<"float", number>>>> | null;
    approximateHaze: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec4", import('three/webgpu').VarNode<"vec4", import('three/webgpu').ConstNode<"vec4", import('three').Vector4>>>> | null;
    marchRainShafts: ((cameraPosition: Node<"vec3">, rayDirection: Node<"vec3">, sunShadowLength: Node<"float">, sceneRayDistance: Node<"float">) => Node<"vec4">) | undefined;
    compositeCirrusDeck: ((cameraPosition: Node<"vec3">, rayDirection: Node<"vec3">, sceneRayDistance: Node<"float">, shadowLength: Node<"float">, color: Node<"vec4">, hitClouds: Node<"float">, frontDepth: Node<"float">) => Node<"vec4">) | undefined;
};
export declare function buildSceneDepthNode(ctx: CloudsContext, paramU: ParameterUniforms, sceneDepth: TextureNode | null, camera: Camera | null): ReturnType<typeof createGetRayDistanceToScene> | null;
