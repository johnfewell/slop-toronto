import { NodeBuilder } from 'three/webgpu';
import { CloudsContext } from '../CloudsContext.js';
export declare function hashGraphFlags(enabled: boolean, sceneDepthNull: boolean, flags: ReturnType<CloudsContext['graphFlags']>): number;
export declare function supportsQuadOperations(builder: NodeBuilder): boolean;
