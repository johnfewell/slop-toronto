import { Node, Texture } from 'three/webgpu';
import { CloudsContext, DebugView } from '../CloudsContext.js';
import { CloudShadowDescriptor } from '../CloudsPassNode.js';
import { MarchCloudsDeps } from '../march/primaryMarch.js';
import { CloudsResolveOutputs } from '../resolve/cloudsResolve.js';
export declare function buildDebugCascadeColor(opts: {
    debug: DebugView;
    viewMatrix: Node<'mat4'>;
    cameraNear: Node<'float'>;
    ecefToWorldMatrix: Node<'mat4'>;
    altitudeCorrection: Node<'vec3'>;
    cascadeCount: number;
    cloudShadow: () => CloudShadowDescriptor;
}): MarchCloudsDeps['getDebugCascadeColor'];
export declare function resolveDebugColor(ctx: CloudsContext, resolved: CloudsResolveOutputs, depthVelocityBuffer: Texture): Node<'vec4'>;
