import { DataArrayTexture, DataTexture } from 'three';
import { RenderTarget, NodeFrame } from 'three/webgpu';
export declare function createLayerTarget(lightShafts: boolean): RenderTarget;
export declare function createResolveTarget(_name: string, lightShafts: boolean, compute?: boolean): RenderTarget;
export declare function createShadowAtlasTexture(width: number, height: number, depth: number, { renderTarget }: {
    renderTarget: boolean;
}): DataArrayTexture;
export declare function createShadowLengthPlaceholder(): DataTexture;
export declare const SHADOW_ATLAS = "shadowAtlas";
export declare const SHADOW_VELOCITY = "shadowVelocity";
export declare const shadowPassOutput: import('three/src/nodes/TSL.js').Struct;
export declare function createShadowTarget(width: number, height: number, depth: number, compute?: boolean, withVelocity?: boolean): RenderTarget;
export declare function clearHistoryPair(renderer: NonNullable<NodeFrame['renderer']>, a: RenderTarget | null, b: RenderTarget | null, layers?: number): void;
