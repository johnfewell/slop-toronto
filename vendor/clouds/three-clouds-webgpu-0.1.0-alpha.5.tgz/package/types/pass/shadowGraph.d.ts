import { NodeMaterial, RenderTarget, TextureNode } from 'three/webgpu';
import { CloudsContext } from '../CloudsContext.js';
import { CloudShapeDeps } from '../experimental/cloudShape.js';
import { ConvectiveDeps } from '../experimental/convectiveProfile.js';
import { EvolvingWeather } from '../experimental/evolvingWeather.js';
import { LayerUniforms } from '../layerUniforms.js';
import { MarchUniforms } from '../marchUniforms.js';
import { ParameterUniforms } from '../parameterUniforms.js';
import { ShadowPassUniforms } from './shadowUniforms.js';
export interface ShadowGraphHost {
    material: NodeMaterial;
    ensureShadowRT(width: number, height: number, depth: number): void;
    shadowRT(): RenderTarget | null;
    odTexNode(): TextureNode | null;
    weatherEvolution: EvolvingWeather;
    convectiveDeps: (ctx: CloudsContext, layerU: LayerUniforms, paramU: ParameterUniforms) => ConvectiveDeps | null;
    cloudShapeDeps: (ctx: CloudsContext) => CloudShapeDeps;
}
export declare function buildShadowPassGraph(ctx: CloudsContext, marchU: MarchUniforms, layerU: LayerUniforms, paramU: ParameterUniforms, su: ShadowPassUniforms, host: ShadowGraphHost): TextureNode | null;
