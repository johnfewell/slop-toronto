import { Matrix4, Vector2 } from 'three';
import { UniformNode } from 'three/webgpu';
import { CloudsContext } from '../CloudsContext.js';
export interface ShadowPassUniforms {
    maxIterationCount: UniformNode<'float', number>;
    minStepSize: UniformNode<'float', number>;
    maxStepSize: UniformNode<'float', number>;
    minDensity: UniformNode<'float', number>;
    minExtinction: UniformNode<'float', number>;
    minTransmittance: UniformNode<'float', number>;
    opticalDepthTailScale: UniformNode<'float', number>;
    inverseShadowMatrix: UniformNode<'mat4', Matrix4>;
    reprojectionMatrix: UniformNode<'mat4', Matrix4>;
    mipLevel: UniformNode<'float', number>;
    cascadeIndex: UniformNode<'float', number>;
    shadowResolution: UniformNode<'vec2', Vector2>;
}
export declare function createShadowPassUniforms(ctx: CloudsContext): ShadowPassUniforms;
export declare function shadowTemporalAlpha(ctx: CloudsContext): number;
export declare function updateShadowPassUniforms(u: ShadowPassUniforms, ctx: CloudsContext): void;
