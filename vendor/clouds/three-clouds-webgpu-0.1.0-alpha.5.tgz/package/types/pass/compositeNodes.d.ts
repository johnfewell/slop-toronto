import { TempNode, TextureNode, Node, NodeBuilder, NodeFrame } from 'three/webgpu';
import { AerialPerspectiveNode } from '@takram/three-atmosphere/webgpu';
import { CloudsPassNode } from '../CloudsPassNode.js';
export declare class CloudsTextureNode extends TextureNode {
    static get type(): string;
    readonly passNode: CloudsPassNode;
    constructor(passNode: CloudsPassNode, textureIndex: number);
    setup(builder: NodeBuilder): Node | null | undefined;
}
export declare class CloudsCompositeNode extends TempNode {
    static get type(): string;
    private readonly passNode;
    private readonly dst;
    private lastBuiltVersion;
    private readonly builtPipelines;
    private readonly builtMaterials;
    constructor(passNode: CloudsPassNode, dst: Node<'vec4'> | AerialPerspectiveNode);
    customCacheKey(): number;
    updateBefore(_frame: NodeFrame): boolean | undefined;
    setup(builder: NodeBuilder): Node | null | undefined;
}
