import { DensityProfile, DensityProfileLike } from './DensityProfile.js';
declare const paramKeys: readonly ["channel", "altitude", "height", "densityScale", "shapeAmount", "shapeDetailAmount", "weatherExponent", "shapeAlteringBias", "coverageFilterWidth", "shadow", "densityProfile"];
/**
 * The shape of the per-layer options object accepted by {@link CloudLayer} and
 * {@link CloudLayers}. Every key is optional; an absent key keeps the current
 * value, so a partial object is a patch rather than a replacement.
 */
export interface CloudLayerLike extends Partial<Pick<CloudLayer, Exclude<(typeof paramKeys)[number], 'densityProfile'>>> {
    densityProfile?: DensityProfileLike;
}
/**
 * Which channel of the local weather texture one layer reads. The four layers
 * default to `r`, `g`, `b` and `a`, so a two-channel weather map still gives
 * two independent layers.
 */
export type TextureChannel = 'r' | 'g' | 'b' | 'a';
/**
 * One of the four cloud layers. A layer owns a height band, the shape and
 * weather weights inside it, and whether it casts a cloud shadow. Four of them
 * are packed into the uniforms every frame and read in one march, so the count
 * is fixed.
 *
 * Units are kilometres (the atmosphere's length unit), not metres.
 */
export declare class CloudLayer {
    /** The all-defaults layer every other layer starts from */
    static readonly DEFAULT: CloudLayer;
    /** Local weather channel this layer reads */
    channel: TextureChannel;
    /** Height of the band's base, in km */
    altitude: number;
    /** Thickness of the band, in km. 0 leaves the lane empty */
    height: number;
    /** Weight of this layer's density in the march */
    densityScale: number;
    /** Weight of the base shape noise */
    shapeAmount: number;
    /**
     * Weight of the high-frequency detail noise. Ignored when
     * `CloudsContext.shapeDetail` is off
     */
    shapeDetailAmount: number;
    /** Exponent applied to the weather channel. 1 keeps it unchanged */
    weatherExponent: number;
    /**
     * Bias on the shape-altering parabola, which moves density toward the middle
     * of the band
     */
    shapeAlteringBias: number;
    /**
     * Width of the soft ramp where weather crosses the coverage threshold. 0 cuts
     * hard
     */
    coverageFilterWidth: number;
    /** Vertical density distribution inside the band */
    densityProfile: DensityProfile;
    /**
     * Whether this layer casts into the cloud shadow map. Turning any layer's
     * flag on or off changes the compiled graph, so it needs a history reset.
     */
    shadow: boolean;
    /** Build a layer, optionally patching over the defaults */
    constructor(options?: CloudLayerLike);
    /** Patch this layer from a partial object, skipping absent keys */
    set(options?: CloudLayerLike): this;
    /** A new layer with the same values, density profile copied */
    clone(): CloudLayer;
    /** Copy every value from another layer, density profile included */
    copy(other: CloudLayer): this;
}
export {};
