import { FC, Ref } from 'react';
import { ExpandNestedProps } from '@takram/three-geospatial/r3f';
import { CloudLayer as CloudLayerImpl, CloudLayerLike } from '../CloudLayer.js';
export interface CloudLayerProps extends CloudLayerLike, ExpandNestedProps<CloudLayerLike, 'densityProfile'> {
    ref?: Ref<CloudLayerImpl>;
    index?: number;
}
export declare const CloudLayer: FC<CloudLayerProps>;
