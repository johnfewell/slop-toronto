import { FC, ReactNode } from 'react';
import { CloudLayers as CloudLayersImpl } from '../CloudLayers.js';
export interface CloudLayersContextValue {
    layers: CloudLayersImpl;
    indexPool: number[];
    disableDefault: boolean;
}
export declare const CloudLayersContext: import('react').Context<CloudLayersContextValue | null>;
export interface CloudLayersProps {
    layers: CloudLayersImpl;
    disableDefault?: boolean;
    children?: ReactNode;
}
export declare const CloudLayers: FC<CloudLayersProps>;
