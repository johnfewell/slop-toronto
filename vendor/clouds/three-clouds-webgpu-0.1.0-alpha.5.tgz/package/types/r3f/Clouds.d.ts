import { FC, ReactNode, Ref } from 'react';
import { Data3DTexture, Matrix4, Texture, Vector3 } from 'three';
import { Storage3DTexture, TextureNode } from 'three/webgpu';
import { CloudsContext, DebugView } from '../CloudsContext.js';
import { CloudsPassNode } from '../CloudsPassNode.js';
import { ExperimentalCloudOptions } from '../experimental/options.js';
import { QualityPreset } from '../qualityPresets.js';
import { ProceduralTextureLike } from '../textures/ProceduralTexture.js';
export interface CloudsPassContextValue {
    pass: CloudsPassNode;
    context: CloudsContext;
}
export declare const CloudsPassContext: import('react').Context<CloudsPassContextValue | null>;
export declare function useClouds(): CloudsPassContextValue;
declare const SCALAR_KEYS: readonly ["coverage", "scatteringCoefficient", "absorptionCoefficient", "turbulenceDisplacement", "skyLightScale", "groundBounceScale", "powderScale", "powderExponent", "scatterAnisotropyMix", "resolutionScale", "sunAngularRadius", "bottomRadius", "correctAltitude", "cameraHeight", "time", "frame", "enabled", "warnings"];
type ScalarProps = Partial<Pick<CloudsContext, (typeof SCALAR_KEYS)[number]>>;
export interface CloudsProps extends ScalarProps {
    ref?: Ref<CloudsPassNode>;
    sceneDepth: TextureNode | null;
    debug?: DebugView;
    disableDefaultLayers?: boolean;
    experimental?: Partial<ExperimentalCloudOptions>;
    qualityPreset?: QualityPreset;
    sunDirection?: Vector3;
    worldToECEFMatrix?: Matrix4;
    localWeatherTexture?: Texture | ProceduralTextureLike | string;
    shapeTexture?: Data3DTexture | ProceduralTextureLike<Storage3DTexture> | string;
    shapeDetailTexture?: Data3DTexture | ProceduralTextureLike<Storage3DTexture> | string;
    turbulenceTexture?: Texture | ProceduralTextureLike | string;
    stbnTexture?: Data3DTexture | string;
    children?: ReactNode;
}
export declare const Clouds: FC<CloudsProps>;
export {};
