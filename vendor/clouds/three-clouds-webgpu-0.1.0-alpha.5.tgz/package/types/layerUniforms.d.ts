import { Vector3, Vector4 } from 'three';
import { UniformNode } from 'three/webgpu';
import { CloudsContext } from './CloudsContext.js';
export interface LayerUniforms {
    minLayerHeights: UniformNode<'vec4', Vector4>;
    maxLayerHeights: UniformNode<'vec4', Vector4>;
    minIntervalHeights: UniformNode<'vec3', Vector3>;
    maxIntervalHeights: UniformNode<'vec3', Vector3>;
    densityScales: UniformNode<'vec4', Vector4>;
    shapeAmounts: UniformNode<'vec4', Vector4>;
    shapeDetailAmounts: UniformNode<'vec4', Vector4>;
    weatherExponents: UniformNode<'vec4', Vector4>;
    shapeAlteringBiases: UniformNode<'vec4', Vector4>;
    coverageFilterWidths: UniformNode<'vec4', Vector4>;
    minHeight: UniformNode<'float', number>;
    maxHeight: UniformNode<'float', number>;
    shadowTopHeight: UniformNode<'float', number>;
    shadowBottomHeight: UniformNode<'float', number>;
    shadowLayerMask: UniformNode<'vec4', Vector4>;
    densityProfileExpTerms: UniformNode<'vec4', Vector4>;
    densityProfileExponents: UniformNode<'vec4', Vector4>;
    densityProfileLinearTerms: UniformNode<'vec4', Vector4>;
    densityProfileConstantTerms: UniformNode<'vec4', Vector4>;
}
export declare function createLayerUniforms(): LayerUniforms;
export declare function updateLayerUniforms(uniforms: LayerUniforms, ctx: CloudsContext): void;
