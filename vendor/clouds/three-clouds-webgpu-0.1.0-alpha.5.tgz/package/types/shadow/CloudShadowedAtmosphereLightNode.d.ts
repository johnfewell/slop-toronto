import { Node, NodeBuilder } from 'three/webgpu';
import { AtmosphereLightNode, AtmosphereLight } from '@takram/three-atmosphere/webgpu';
export declare class CloudShadowedAtmosphereLightNode extends AtmosphereLightNode {
    static get type(): string;
    shadowTransmittanceFn: ((pos: Node<'vec3'>, radius: Node<'float'>, jitter: Node<'float'>) => Node<'float'>) | null;
    shadowRadiusFn: ((worldPosition: Node<'vec3'>) => Node<'float'>) | null;
    stbnNode: Node<'float'> | null;
    constructor(light?: AtmosphereLight | null);
    setupDirect(builder: NodeBuilder): ReturnType<AtmosphereLightNode['setupDirect']>;
}
