import { Node, TextureNode } from 'three/webgpu';
import { UniformArrayLike } from '../CloudsPassNode.js';
export declare const vogelDisk: import('three/src/nodes/TSL.js').FnNode<[number | Node<"int"> | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec2", import('three/webgpu').JoinNode<"vec2">>>;
export declare const getShadowUv: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Matrix4 | Node<"mat4">], Node<"vec2">>;
export declare const getDistanceToShadowTop: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], any>;
export interface ShadowSamplerDeps {
    shadowBuffer: TextureNode;
    shadowTexelSize: Node<'vec2'>;
    shadowIntervals: UniformArrayLike<'vec2'>;
    shadowMatrices: UniformArrayLike<'mat4'>;
    shadowFar: Node<'float'>;
    viewMatrix: Node<'mat4'>;
    cameraNear: Node<'float'>;
    sunDirection: Node<'vec3'>;
    bottomRadius: Node<'float'>;
    shadowTopHeight: Node<'float'>;
    ecefToWorldMatrix: Node<'mat4'>;
    altitudeCorrection: Node<'vec3'>;
    worldToUnit: Node<'float'>;
    temporalJitter: Node<'vec2'>;
    resolution: Node<'vec2'>;
    cascadeCount: Node<'int'>;
    shadowSampleCount: number;
    shadowFromECEFMatrices?: UniformArrayLike<'mat4'>;
    viewZFromECEF?: Node<'vec4'>;
}
export declare function createSampleShadowOpticalDepth(deps: ShadowSamplerDeps, outsideValue?: number): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"float", import('three/webgpu').VarNode<"float", import('three/webgpu').ConstNode<"float", number>>>>;
export declare function cpuVogelDisk(index: number, sampleCount: number, phi: number): [number, number];
export declare function cpuReadShadowOpticalDepth(shadow: {
    r: number;
    g: number;
    b: number;
    a: number;
}, distanceToTop: number, distanceOffset: number, worldToUnit: number): number;
export declare function cpuGetFadedCascadeIndex(depth: number, intervals: Array<[number, number]>, jitter: number): number;
export declare function cpuInterleavedGradientNoise(x: number, y: number): number;
