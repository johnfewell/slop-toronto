import { Node } from 'three/webgpu';
import { CloudShadowDescriptor } from '../CloudsPassNode.js';
export declare const webglFragCoord: (coord: Node<"vec2">) => Node<"vec2">;
export interface GroundShadowExtraDeps {
    viewMatrix: Node<'mat4'>;
    cameraNear: Node<'float'>;
    sunDirection: Node<'vec3'>;
    bottomRadius: Node<'float'>;
    ecefToWorldMatrix: Node<'mat4'>;
    altitudeCorrection: Node<'vec3'>;
    worldToUnit: Node<'float'>;
    temporalJitter: Node<'vec2'>;
    resolution: Node<'vec2'>;
}
export declare function createSampleCloudShadowOpticalDepth(descriptor: CloudShadowDescriptor, deps: GroundShadowExtraDeps, options?: {
    shadowSampleCount?: number;
}): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"float", import('three/webgpu').VarNode<"float", import('three/webgpu').ConstNode<"float", number>>>>;
export declare function createCloudShadowTransmittance(descriptor: CloudShadowDescriptor, deps: GroundShadowExtraDeps, options?: {
    enabled?: boolean;
    shadowSampleCount?: number;
}): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
export declare function cpuReadGroundShadowOpticalDepth(shadow: {
    r: number;
    g: number;
    b: number;
    a: number;
}, distanceToTop: number, worldToUnit: number): number;
export declare function webglFragCoordCPU(coord: readonly [number, number], framebufferHeight: number): [number, number];
