import { Node, NodeBuilder } from 'three/webgpu';
import { AerialPerspectiveNode } from '@takram/three-atmosphere/webgpu';
export declare const BC_SENTINEL_SURFACE = 0.5;
export declare const BC_SENTINEL_SKY = 0.25;
export declare class CloudShadowedAerialPerspectiveNode extends AerialPerspectiveNode {
    static get type(): string;
    shadowNode: Node<'float'> | null;
    lightingMaskNode: Node<'float'> | null;
    budgetClosure: 'off' | 'read1' | 'read2';
    opticalDepthNode: Node<'float'> | null;
    setup(builder: NodeBuilder): unknown;
}
