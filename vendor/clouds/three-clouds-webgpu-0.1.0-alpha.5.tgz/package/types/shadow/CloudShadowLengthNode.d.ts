import { Node, TextureNode } from 'three/webgpu';
export interface CloudShadowLengthDeps {
    shadowLengthTextureNode: TextureNode;
    isLive: () => boolean;
}
export declare function buildCloudShadowLength(deps: CloudShadowLengthDeps): Node<'vec2'>;
export declare function cloudShadowLengthCPU(shadowLengthVal: number, shadowStartVal: number, lightShafts: boolean, enabled: boolean): [number, number];
