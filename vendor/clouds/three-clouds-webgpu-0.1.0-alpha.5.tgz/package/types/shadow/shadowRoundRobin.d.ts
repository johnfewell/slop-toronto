import { Matrix4, Vector3 } from 'three';
export interface RoundRobinCascade {
    readonly matrix: Matrix4;
    readonly inverseMatrix: Matrix4;
}
export declare const ROUND_ROBIN_MAX_DRIFT = 0.25;
export declare const ROUND_ROBIN_MIN_SUN_COS: number;
export declare class ShadowRoundRobin {
    private next;
    private count;
    private readonly matrices;
    private readonly inverseMatrices;
    private readonly sunDirections;
    invalidate(): void;
    plan(cascades: readonly RoundRobinCascade[], count: number, sunDirection: Vector3, forceAll: boolean): number | null;
    record(cascades: readonly RoundRobinCascade[], count: number, sunDirection: Vector3, only: number | null): void;
    private drifted;
}
