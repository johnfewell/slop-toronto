import { Matrix4, Vector2, Vector3, Camera, PerspectiveCamera } from 'three';
export type FrustumSplitFunction = (length: number, near: number, far: number, lambda?: number, result?: number[]) => number[];
export interface FrustumSplitFunctions {
    uniform: FrustumSplitFunction;
    logarithmic: FrustumSplitFunction;
    practical: FrustumSplitFunction;
}
export type FrustumSplitMode = keyof FrustumSplitFunctions;
export declare const frustumSplitFunctions: FrustumSplitFunctions;
export declare function splitFrustum(mode: FrustumSplitMode, count: number, near: number, far: number, lambda?: number, result?: number[]): number[];
export declare class FrustumCorners {
    readonly near: [Vector3, Vector3, Vector3, Vector3];
    readonly far: [Vector3, Vector3, Vector3, Vector3];
    constructor();
    constructor(camera: Camera, far: number);
    clone(): FrustumCorners;
    copy(other: FrustumCorners): this;
    setFromCamera(camera: Camera, far: number): this;
    split(clipDepths: readonly number[], result?: FrustumCorners[]): FrustumCorners[];
    applyMatrix4(matrix: Matrix4): this;
}
export interface Cascade {
    readonly interval: Vector2;
    readonly matrix: Matrix4;
    readonly inverseMatrix: Matrix4;
    readonly projectionMatrix: Matrix4;
    readonly inverseProjectionMatrix: Matrix4;
    readonly viewMatrix: Matrix4;
    readonly inverseViewMatrix: Matrix4;
}
export interface CascadedShadowMapsOptions {
    cascadeCount: number;
    mapSize: Vector2;
    maxFar?: number | null;
    farScale?: number;
    splitMode?: FrustumSplitMode;
    splitLambda?: number;
    margin?: number;
    fade?: boolean;
}
export declare const cascadedShadowMapsDefaults: {
    maxFar: null;
    farScale: number;
    splitMode: "practical";
    splitLambda: number;
    margin: number;
    fade: true;
};
export declare const MAX_CASCADE_COUNT = 4;
export declare class CascadedShadowMaps {
    readonly cascades: Cascade[];
    readonly mapSize: Vector2;
    maxFar: number | null;
    farScale: number;
    splitMode: FrustumSplitMode;
    splitLambda: number;
    margin: number;
    fade: boolean;
    private readonly cameraFrustum;
    private readonly frusta;
    private readonly splits;
    private _far;
    constructor(options: CascadedShadowMapsOptions);
    get cascadeCount(): number;
    set cascadeCount(value: number);
    get far(): number;
    private updateIntervals;
    private getFrustumRadius;
    private updateMatrices;
    update(camera: PerspectiveCamera, sunDirection: Vector3, distance?: number): void;
}
export declare function getSunDistanceFudge(sunDirection: Vector3, surfaceNormal: Vector3): number;
