import { Node } from 'three/webgpu';
import { UniformArrayLike } from '../CloudsPassNode.js';
export interface FadedCascadeIndexDeps {
    viewMatrix: Node<'mat4'>;
    cameraNear: Node<'float'>;
    shadowFar: Node<'float'>;
    shadowIntervals: UniformArrayLike<'vec2'>;
    cascadeCount: Node<'int'>;
}
export declare function createFadedCascadeIndex(deps: FadedCascadeIndexDeps): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], Node<"int">>;
export declare function createFadedCascadeIndexFromViewZ(deps: Omit<FadedCascadeIndexDeps, 'viewMatrix'>): import('three/src/nodes/TSL.js').FnNode<[number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"int">>;
