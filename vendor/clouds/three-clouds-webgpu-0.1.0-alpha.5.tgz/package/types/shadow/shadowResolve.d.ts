import { Texture } from 'three';
import { Node, TextureNode } from 'three/webgpu';
export interface ShadowVelocityDeps {
    odBuffer: Texture | TextureNode;
    frontDepthUnit?: Node<'float'>;
    inverseShadowMatrix: Node<'mat4'>;
    reprojectionMatrix: Node<'mat4'>;
    worldToECEFMatrix: Node<'mat4'>;
    ecefToWorldMatrix: Node<'mat4'>;
    altitudeCorrection: Node<'vec3'>;
    sunDirection: Node<'vec3'>;
    bottomRadius: Node<'float'>;
    shadowTopHeight: Node<'float'>;
    worldToUnit: Node<'float'>;
    shadowBottomHeight: Node<'float'>;
    resolution: Node<'vec2'>;
    cascadeIndex: Node<'float'>;
}
export declare function buildShadowVelocity(deps: ShadowVelocityDeps): import('three/webgpu').VarNode<"vec4", import('three/webgpu').JoinNode<"vec4">>;
export interface ShadowResolveDeps {
    odBuffer: Texture | TextureNode;
    velocityBuffer: Texture | TextureNode;
    historyBuffer: Texture | TextureNode;
    texelSize: Node<'vec2'>;
    varianceGamma: Node<'float'>;
    temporalAlpha: Node<'float'>;
    resolution: Node<'vec2'>;
    cascadeIndex: Node<'float'>;
}
export declare function buildShadowCascadeResolve(deps: ShadowResolveDeps): import('three/webgpu').VarNode<"vec4", TextureNode<"vec4">>;
export declare function getClosestFragmentCPU(velocityData: number[][], x: number, y: number, width: number, height: number): [number, number, number, number];
export declare function shadowCascadeResolveCPU(odData: [number, number, number, number][], velocityData: number[][], historyData: [number, number, number, number][], x: number, y: number, width: number, height: number, texelSizeX: number, texelSizeY: number, varianceGamma: number, temporalAlpha: number, varianceClipFn: (current: [number, number, number, number], neighbours: [number, number, number, number][], history: [number, number, number, number], gamma: number) => [number, number, number, number]): [number, number, number, number];
