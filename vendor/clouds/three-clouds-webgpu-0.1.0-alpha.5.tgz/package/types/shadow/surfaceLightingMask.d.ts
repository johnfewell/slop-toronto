import { Node } from 'three/webgpu';
export declare const applySurfaceLightingMask: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], Node<"vec3">>;
export declare function cpuSurfaceLightingMask(selfLit: readonly number[], postLit: readonly number[], mask: number): number[];
