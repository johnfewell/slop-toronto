import { Node } from 'three/webgpu';
export interface MarchOpticalDepthDeps {
    sampleWeather: (uv: Node<'vec2'>, height: Node<'float'>, mipLevel: Node<'float'>, heightFraction?: Node<'vec4'>) => Node<'vec4'>;
    sampleMedia: (weatherDensity: Node<'vec4'>, weatherHeightFraction: Node<'vec4'>, position: Node<'vec3'>, uv: Node<'vec2'>, mipLevel: Node<'float'>, jitter: Node<'float'>) => Node<'vec4'>;
    bottomRadius: Node<'float'>;
    minSecondaryStepSize: Node<'float'>;
    secondaryStepScale: Node<'float'>;
    minLayerHeights: Node<'vec4'>;
    maxLayerHeights: Node<'vec4'>;
    scatteringCoefficient: Node<'float'>;
    absorptionCoefficient: Node<'float'>;
}
export declare function createMarchOpticalDepth(deps: MarchOpticalDepthDeps): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec2", import('three/webgpu').JoinNode<"vec2">>>;
export declare function iterationCountCPU(maxIterationCount: number, mipLevel: number, jitter: number): number;
export declare function marchOpticalDepthCPU(extinction: number, maxIterationCount: number, mipLevel: number, jitter: number, minSecondaryStepSize: number, secondaryStepScale: number): {
    opticalDepth: number;
    rayDistance: number;
};
export declare function geometricSeriesOD(extinction: number, iterationCount: number, minSecondaryStepSize: number, secondaryStepScale: number): number;
