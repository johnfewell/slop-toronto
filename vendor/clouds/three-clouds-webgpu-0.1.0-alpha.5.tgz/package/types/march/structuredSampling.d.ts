import { Node } from 'three/webgpu';
export declare const getStructureNormal: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec3", Node<"vec3">>>;
export declare const intersectStructuredPlanes: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec2", import('three/webgpu').JoinNode<"vec2">>>;
