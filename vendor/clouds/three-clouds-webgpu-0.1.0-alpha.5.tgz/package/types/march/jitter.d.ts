import { Data3DTexture } from 'three';
import { Node, TextureNode } from 'three/webgpu';
export declare const referenceFragCoord: () => Node<"vec2">;
export declare function getSTBN(stbnTexture: Data3DTexture | TextureNode, frame: Node<'float'> | Node<'int'>, coordinate?: Node<'vec2'>, name?: string): Node<'float'>;
