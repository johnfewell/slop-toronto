import { Node, NodeBuilder } from 'three/webgpu';
export interface ShadowLengthMarchDeps {
    sampleShadowOpticalDepth: (position: Node<'vec3'>, sunRayDistance: Node<'float'>, filterRadius: Node<'float'>, jitter: Node<'float'>) => Node<'float'>;
    perspectiveStepScale: Node<'float'>;
    minShadowLengthStepSize: Node<'float'>;
    maxShadowLengthIterationCount: number;
}
export declare function createMarchShadowLength(deps: ShadowLengthMarchDeps): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, import('three').Vector2 | Node<"vec2">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"float", import('three/webgpu').VarNode<"float", import('three/webgpu').ConstNode<"float", number>>>>;
export declare function createMarchShadowLengthQuadPartial(deps: ShadowLengthMarchDeps): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, import('three').Vector2 | Node<"vec2">, number | Node<"float"> | Node<"uint">, Node<"int">], import('three/webgpu').VarNode<"float", import('three/webgpu').VarNode<"float", import('three/webgpu').ConstNode<"float", number>>>>;
export declare function enableSubgroups(builder: NodeBuilder): void;
export declare function quadLane(): Node<'int'>;
export declare const sumQuadShadowLength: import('three/src/nodes/TSL.js').FnNode<[number | Node<"float"> | Node<"uint">, boolean | Node<"bool">, import('three').Vector2 | Node<"vec2">], Node<"float">>;
export declare function clampShadowAtCloudFront(shadowNearFarY: number, frontDepth: number, alpha: number): number;
export declare function marchShadowLengthCPU(sampleOD: (position: [number, number, number]) => number, rayOrigin: [number, number, number], rayDirection: [number, number, number], rayNear: number, rayFar: number, jitter: number, minStepSize: number, maxIterationCount: number, perspectiveStepScale: number): number;
export declare function marchShadowLengthQuadPartialCPU(sampleOD: (position: [number, number, number]) => number, rayOrigin: [number, number, number], rayDirection: [number, number, number], rayNear: number, rayFar: number, jitter: number, minStepSize: number, maxIterationCount: number, perspectiveStepScale: number, lane: number): number;
export declare function getShadowRayNearFarCPU(cameraHeight: number, shadowTopHeight: number, cameraNear: number, ground: boolean, firstX: number, firstW: number, secondW: number, maxShadowLengthRayDistance: number): [number, number];
