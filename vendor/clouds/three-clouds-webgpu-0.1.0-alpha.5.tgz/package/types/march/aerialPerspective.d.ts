import { Node, StructNode } from 'three/webgpu';
export declare function createApplyAerialPerspective(getIndirectLuminanceToPoint: (cameraPositionECEF: Node<'vec3'>, frontPositionECEF: Node<'vec3'>, shadowLength: Node<'vec2'>) => StructNode): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, import('three').Vector4 | Node<"vec4">], import('three/webgpu').VarNode<"vec4", import('three/webgpu').JoinNode<"vec4">>>;
export declare function shadowLengthToPoint(rayLength: Node<'float'>, shadowLength: Node<'float'>): Node<'vec2'>;
export declare const shadowLengthToAttachment: import('three/src/nodes/TSL.js').FnNode<[number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"vec2">>;
export declare function shadowLengthToPointCPU(rayLength: number, shadowLength: number): [number, number];
export declare function shadowLengthToAttachmentCPU(shadowLength: number, sceneRayDistance: number): [number, number];
export declare function applyAerialPerspectiveCPU(colorRGB: [number, number, number], opacity: number, transmittance: [number, number, number], inscatter: [number, number, number]): [number, number, number, number];
