import { Node, StructNode } from 'three/webgpu';
import { RainShaftDeps } from '../experimental/rainShafts.js';
export interface RainShaftMarchDeps {
    density: RainShaftDeps['density'];
    getCloudsSunSkyIrradiance: (position: Node<'vec3'>, height: Node<'float'>) => StructNode;
    bottomRadius: Node<'float'>;
    baseHeight: Node<'float'>;
    maxRayDistance: Node<'float'>;
}
export declare function createRainShaftMarch(deps: RainShaftMarchDeps): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec4", import('three/webgpu').JoinNode<"vec4">>>;
export declare function rainShaftSegmentCPU(cameraRadius: number, cameraAlongRay: number, shellRadius: number, maxRayDistance: number, sceneRayDistance: number): {
    near: number;
    far: number;
    steps: number;
};
export declare function rainShaftStepCPU(transmittance: number, extinction: number, stepSize: number, ambient: number): {
    transmittance: number;
    inScatter: number;
};
