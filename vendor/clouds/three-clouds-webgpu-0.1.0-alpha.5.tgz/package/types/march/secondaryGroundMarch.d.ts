import { Node, StructNode } from 'three/webgpu';
export interface GroundBounceDeps {
    marchOpticalDepth: (position: Node<'vec3'>, rayDirection: Node<'vec3'>, maxIterationCount: Node<'float'>, mipLevel: Node<'float'>, jitter: Node<'float'>) => Node<'vec2'>;
    getGroundSunSkyIrradiance: (position: Node<'vec3'>, surfaceNormal: Node<'vec3'>, height: Node<'float'>) => StructNode;
    maxIterationCountToGround: Node<'float'>;
    coverage: Node<'float'>;
}
export declare function createApproximateRadianceFromGround(deps: GroundBounceDeps): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"vec3">>;
export declare function approximateRadianceFromGroundCPU(opticalDepthToGround: number, sunIrradiance: [number, number, number], skyIrradiance: [number, number, number], coverage: number): [number, number, number];
