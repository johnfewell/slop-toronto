import { Node } from 'three/webgpu';
export declare const layerOutputStruct: import('three/src/nodes/TSL.js').Struct;
export declare const writeLayer: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').StructNode>;
