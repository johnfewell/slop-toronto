import { Camera } from 'three';
import { Node, TextureNode } from 'three/webgpu';
export declare const sceneDepthStruct: import('three/src/nodes/TSL.js').Struct;
export interface SceneDepthDeps {
    sceneDepthTexture: TextureNode;
    camera: Camera;
    reversedDepthBuffer?: boolean;
    logarithmicDepthBuffer?: boolean;
    targetUvScale?: Node<'vec2'>;
    temporalJitter?: Node<'vec2'>;
}
export declare function createGetRayDistanceToScene(deps: SceneDepthDeps): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">], import('three/webgpu').StructNode>;
export declare function logarithmicToPerspectiveDepthCPU(depth: number, near: number, far: number): number;
export declare function perspectiveDepthToViewZCPU(depth: number, near: number, far: number, reversed?: boolean): number;
export declare function orthographicDepthToViewZCPU(depth: number, near: number, far: number, reversed?: boolean): number;
export declare function getRayDistanceToSceneCPU(depth: number, near: number, far: number, isPerspective: boolean, reversedDepthBuffer: boolean, rayDirDotCamDir: number): {
    viewZ: number;
    rayDistance: number;
};
