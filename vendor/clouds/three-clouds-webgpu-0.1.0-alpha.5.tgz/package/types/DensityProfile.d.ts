export interface DensityProfileLike extends Partial<Pick<DensityProfile, 'expTerm' | 'exponent' | 'linearTerm' | 'constantTerm'>> {
}
export declare class DensityProfile {
    expTerm: number;
    exponent: number;
    linearTerm: number;
    constantTerm: number;
    constructor(expTerm?: number, exponent?: number, linearTerm?: number, constantTerm?: number);
    set(expTerm?: number, exponent?: number, linearTerm?: number, constantTerm?: number): this;
    clone(): DensityProfile;
    copy(other: DensityProfile): this;
}
