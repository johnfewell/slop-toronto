export declare function shadowLengthResolveCPU(opts: {
    current: [number, number, number, number];
    history: [number, number, number, number];
    prevUvInBounds: boolean;
    isCurrentFrame: boolean;
    neighbours: [number, number, number, number][];
    gamma: number;
}): [number, number, number, number];
