import { Vector2 } from 'three';
import { Node } from 'three/webgpu';
export declare const bayerIndices: readonly number[];
export declare const bayerOffsets: readonly Vector2[];
export declare function bayerIndex2D(x: number, y: number): number;
export declare function referenceBayerRowCPU(topDownPixelY: number, _height: number): number;
export declare function referenceBayerRow(topDownPixelY: Node<'int'>, _height: Node<'float'>): Node<'int'>;
