import { Node } from 'three/webgpu';
export declare const getSphericalUv: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">], import('three/webgpu').VarNode<"vec2", import('three/webgpu').JoinNode<"vec2">>>;
export declare const getCubeSphereUv: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"vec2">>;
export declare const getGlobeUv: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"vec2">>;
export declare const getMipLevel: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector2 | Node<"vec2">, import('three').Vector2 | Node<"vec2">], Node<"float">>;
export declare function cpuGetSphericalUv(px: number, py: number, pz: number): [number, number];
export declare function cpuGetCubeSphereUv(px: number, py: number, pz: number): [number, number];
