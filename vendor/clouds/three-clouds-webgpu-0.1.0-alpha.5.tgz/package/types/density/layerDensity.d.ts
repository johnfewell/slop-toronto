import { Node } from 'three/webgpu';
export declare const getLayerDensity: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">], Node<"vec4">>;
export declare function getLayerDensityCPU(heightFraction: number, expTerm: number, exponent: number, linearTerm: number, constantTerm: number): number;
