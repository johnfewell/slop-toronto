import { Node, TextureNode } from 'three/webgpu';
import { LayerStructure } from '../CloudLayers.js';
import { CloudShapeDeps } from '../experimental/cloudShape.js';
import { CloudTypeBlendNodes } from '../experimental/cloudTypeMap.js';
import { ConvectiveDeps } from '../experimental/convectiveProfile.js';
export declare function createSampleMedia(shapeTexture: TextureNode, shapeRepeat: Node<'vec3'>, shapeOffset: Node<'vec3'>, shapeAmounts: Node<'vec4'>, shapeDetailTexture: TextureNode, shapeDetailRepeat: Node<'vec3'>, shapeDetailOffset: Node<'vec3'>, shapeDetailAmounts: Node<'vec4'>, turbulenceTexture: TextureNode, turbulenceRepeat: Node<'vec2'>, turbulenceDisplacement: Node<'float'>, localWeatherRepeat: Node<'vec2'>, localWeatherOffset: Node<'vec2'>, densityScales: Node<'vec4'>, densityProfileExpTerms: Node<'vec4'>, densityProfileExponents: Node<'vec4'>, densityProfileLinearTerms: Node<'vec4'>, densityProfileConstantTerms: Node<'vec4'>, turbulenceFlag: boolean, shapeDetailFlag: boolean, shapeDetailFadeFlag: boolean, structure?: LayerStructure, convective?: ConvectiveDeps | null, cloudTypes?: CloudTypeBlendNodes, cloudShape?: CloudShapeDeps | null): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, import('three').Vector3 | Node<"vec3">, import('three').Vector2 | Node<"vec2">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"vec4">>;
export declare function computeMediaOutputs(densityVec4: Node<'vec4'>, scatteringCoefficient: Node<'float'>, absorptionCoefficient: Node<'float'>): {
    densitySum: Node<"float">;
    weight: Node<"vec4">;
    scattering: Node<"float">;
    extinction: Node<"float">;
};
export interface MediaSample {
    density: number;
    weight: [number, number, number, number];
    scattering: number;
    extinction: number;
}
export declare const DETAIL_FADE_MIP = 0.5;
export declare function detailFadeStrength(mipLevel: number): number;
export declare function detailLotteryWeight(mipLevel: number): number;
export declare const DETAIL_MEAN = 0.7147;
export declare const DETAIL_POW6_MEAN = 0.1657;
export declare function cpuSampleMedia(weatherDensity: [number, number, number, number], weatherHeightFraction: [number, number, number, number], shapeValue: number, shapeAmounts: [number, number, number, number], densityScales: [number, number, number, number], densityProfileExpTerms: [number, number, number, number], densityProfileExponents: [number, number, number, number], densityProfileLinearTerms: [number, number, number, number], densityProfileConstantTerms: [number, number, number, number], scatteringCoefficient: number, absorptionCoefficient: number, options: {
    shapeDetail: boolean;
    shapeDetailFade?: boolean;
    detailValue?: number;
    shapeDetailAmounts?: [number, number, number, number];
    mipLevel: number;
    jitter: number;
    structure?: LayerStructure;
    erosionShape?: number;
}): MediaSample;
