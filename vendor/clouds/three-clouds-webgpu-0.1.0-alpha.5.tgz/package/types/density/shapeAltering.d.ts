import { Node } from 'three/webgpu';
export declare const shapeAlteringFunction: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">], Node<"vec4">>;
export declare function cpuShapeAltering(heightFraction: number, bias: number): number;
