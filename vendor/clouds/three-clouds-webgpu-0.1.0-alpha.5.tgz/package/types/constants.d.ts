export declare const CLOUD_SHAPE_TEXTURE_SIZE = 128;
export declare const CLOUD_SHAPE_DETAIL_TEXTURE_SIZE = 32;
export declare const DEFAULT_LOCAL_WEATHER_URL = "assets/local_weather.png";
export declare const DEFAULT_SHAPE_URL = "assets/shape.bin";
export declare const DEFAULT_SHAPE_DETAIL_URL = "assets/shape_detail.bin";
export declare const DEFAULT_TURBULENCE_URL = "assets/turbulence.png";
