import { Vector4, Node } from 'three/webgpu';
import { ProceduralTexture2D } from '../textures/ProceduralTexture.js';
export type WeatherPattern = 'clumps' | 'bands' | 'scattered';
export type WeatherChannel = 'low' | 'mid' | 'high';
export interface WeatherChannelParameters {
    pattern?: WeatherPattern;
    scale?: number;
    coverage?: number;
    clumpiness?: number;
    bands?: number;
    gap?: number;
    octaves?: number;
}
export interface ProceduralWeatherParameters {
    seed?: number;
    size?: number;
    low?: WeatherChannelParameters;
    mid?: WeatherChannelParameters;
    high?: WeatherChannelParameters;
}
export interface WeatherChannelNodes {
    salt: Node<'float'>;
    saltIsEven: boolean;
    pattern: WeatherPattern;
    octaves: number;
    scale: Node<'float'>;
    coverage: Node<'float'>;
    clumpiness: Node<'float'>;
    bands: Node<'float'>;
    gap: Node<'float'>;
}
export type ProceduralWeatherGenerator = (uv: Node<'vec2'>) => Node<'vec4'>;
export declare function createProceduralWeather(low: WeatherChannelNodes, mid: WeatherChannelNodes, high: WeatherChannelNodes): ProceduralWeatherGenerator;
export declare class ProceduralWeather extends ProceduralTexture2D {
    readonly generate: ProceduralWeatherGenerator;
    private readonly seedU;
    private readonly scaleU;
    private readonly coverageU;
    private readonly clumpinessU;
    private readonly bandsU;
    private readonly gapU;
    get seed(): number;
    set seed(value: number);
    get scale(): Vector4;
    set scale(value: Vector4);
    get coverage(): Vector4;
    set coverage(value: Vector4);
    get clumpiness(): Vector4;
    set clumpiness(value: Vector4);
    get bands(): Vector4;
    set bands(value: Vector4);
    get gap(): Vector4;
    set gap(value: Vector4);
    constructor(parameters?: ProceduralWeatherParameters);
    update(): void;
}
