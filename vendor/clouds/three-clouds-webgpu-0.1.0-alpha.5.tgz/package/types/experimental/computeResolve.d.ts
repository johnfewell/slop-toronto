import { Texture } from 'three';
import { Node, StorageTexture, TextureNode } from 'three/webgpu';
import { CloudsResolveDeps, CloudsResolveShadowLengthDeps } from '../resolve/cloudsResolve.js';
export declare function createResolveTile(input: Texture | TextureNode, size: Node<'vec2'>, stride: number, halo: number, layer?: Node<'float'>): {
    fill: import('three/src/nodes/TSL.js').FnNode<[], void>;
    load: import('three/src/nodes/TSL.js').FnNode<[Node<"ivec2">], Node<"vec4">>;
    sample: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector2 | Node<"vec2">], Node<"vec4">>;
};
type ResolveTile = ReturnType<typeof createResolveTile>;
export declare function createTileClip(tile: ResolveTile, size: Node<'vec2'>, upscale: boolean, opaque?: boolean): import('three/src/nodes/TSL.js').FnNode<[Node<"ivec2">, import('three').Vector2 | Node<"vec2">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec4", Node<"vec4">>>;
export declare function createTileClosest(tile: ResolveTile): import('three/src/nodes/TSL.js').FnNode<[Node<"ivec2">], import('three/webgpu').VarNode<"vec4", import('three/webgpu').VarNode<"vec4", import('three/webgpu').ConstNode<"vec4", import('three').Vector4>>>>;
export declare function buildComputeCloudsResolve(deps: CloudsResolveDeps, shadow: CloudsResolveShadowLengthDeps | null, upscale: boolean, output: StorageTexture, shadowOutput?: StorageTexture): import('three/webgpu').ComputeNode;
export {};
