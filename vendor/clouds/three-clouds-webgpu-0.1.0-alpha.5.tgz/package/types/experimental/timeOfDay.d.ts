import { Vector3 } from 'three';
/**
 * Where the observer is: degrees, metres. A `Geodetic` from
 * `@takram/three-geospatial` is accepted as it stands.
 */
export interface TimeOfDayLocation {
    readonly longitude: number;
    readonly latitude: number;
    readonly height?: number;
}
/** Both bodies as ECEF unit vectors, which is what every consumer wants */
export interface CelestialDirections {
    readonly sunDirection: Vector3;
    readonly moonDirection: Vector3;
}
/**
 * A place a direction can be written to: a plain `Vector3` like
 * `CloudsContext.sunDirection`, or a uniform wrapper like
 * `atmosphere.sunDirectionECEF`. Both are what the shipped consumers hold, so
 * no consumer changes shape to take part.
 */
export type CelestialVector = Vector3 | {
    readonly value: Vector3;
};
/** One consumer. `sunDirection` is required, `moonDirection` is optional */
export interface CelestialSink {
    sunDirection: CelestialVector;
    moonDirection?: CelestialVector;
}
/** The `Vector3` behind a sink field, whatever shape that field has */
export declare function celestialVector(target: CelestialVector): Vector3;
/**
 * Sun and moon directions for an instant and a place, in ECEF, unit length
 */
export declare function computeCelestialDirections(date: Date | number, location: TimeOfDayLocation, result?: CelestialDirections): CelestialDirections;
/**
 * The instant a local solar time of day names, on a date already in some
 * timezone. `timeOfDay` is a fraction of a day in LOCAL SOLAR time: 0 is local
 * midnight, 0.5 local noon. Longitude is the only thing that converts it, at 15
 * degrees per hour, so the result wraps across UTC midnight instead of
 * clamping.
 *
 * Solar rather than civil time, because this is a sun-direction helper: civil
 * "18:00" is the observer's timezone, which is not where the sun is.
 *
 * Throws a RangeError outside [0, 1), because a wrapped fraction would silently
 * pick a different time of day than the caller asked for.
 */
export declare function resolveTimeOfDay(date: Date | number, timeOfDay: number, location: TimeOfDayLocation): Date;
/** What a caller hands {@link syncCelestialDirections} */
export interface TimeOfDayRequest {
    /** The date the time of day lands on, in any timezone */
    readonly date: Date | number;
    readonly location: TimeOfDayLocation;
    /**
     * Local solar time as a fraction of a day, in [0, 1). Omit it to use the
     * date's own UTC time, which is what a UTC-driven consumer wants.
     */
    readonly timeOfDay?: number;
}
/**
 * Compute both directions and write each into the sinks that take it: one call
 * for the whole sun sync, which is the part consumers get wrong. The
 * atmosphere, the clouds and the shadow dependencies each read their own copy,
 * and a scene missing two of the three is black or unshadowed rather than
 * broken.
 *
 * A sink with no `moonDirection` gets the sun and nothing else, so the clouds
 * context takes part unchanged. Returns the same values it wrote, so a caller can
 * light the scene from them without computing twice.
 */
export declare function syncCelestialDirections(sinks: CelestialSink | readonly CelestialSink[], request: TimeOfDayRequest): CelestialDirections;
