import { StorageArrayTexture } from 'three/webgpu';
import { ShadowResolveDeps } from '../shadow/shadowResolve.js';
export declare function buildComputeShadowResolve(deps: ShadowResolveDeps, output: StorageArrayTexture): import('three/webgpu').ComputeNode;
