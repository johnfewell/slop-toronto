import { Vector3 } from 'three';
import { Node, StructNode } from 'three/webgpu';
export declare const FULL_MOON_IRRADIANCE_RATIO = 0.0000025;
export declare const TWILIGHT_SIN_ELEVATION = -0.104528;
export declare function twilightBlendCPU(sunElevation: number): number;
export declare function illuminatedFractionCPU(sunDirection: Vector3, moonDirection: Vector3): number;
export declare function moonlightCPU(sunDirection: Vector3, moonDirection: Vector3, cameraPositionECEF: Vector3, gain: number, color: Vector3, out: {
    lightDirection: Vector3;
    irradianceRatio: Vector3;
}): {
    blend: number;
    illuminated: number;
};
export interface MoonlightNodes {
    direction: Node<'vec3'>;
    addMoonlight: <T extends StructNode>(irradiance: T) => StructNode;
}
export declare function createMoonlightNodes(deps: {
    lightDirection: Node<'vec3'>;
    irradianceRatio: Node<'vec3'>;
    sunAngularRadius: number;
}): MoonlightNodes;
