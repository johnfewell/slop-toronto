import { CubeCamera, WebGLCubeRenderTarget as CubeRenderTarget, Vector3 } from 'three';
import { TempNode, Node } from 'three/webgpu';
import { CloudsContext } from '../CloudsContext.js';
import { LayerUniforms } from '../layerUniforms.js';
import { MarchUniforms } from '../marchUniforms.js';
import { ParameterUniforms } from '../parameterUniforms.js';
import { MarchGraphHost } from '../pass/marchGraph.js';
export interface CloudEnvironmentSettings {
    readonly size: number;
    readonly updateInterval: number;
    readonly maxIterationCount: number;
    readonly maxIterationCountToSun: number;
    readonly distanceThreshold: number;
    readonly angularThreshold: number;
}
export declare const DEFAULT_CLOUD_ENVIRONMENT: CloudEnvironmentSettings;
export type CloudEnvironmentReason = 'initial' | 'graph' | 'camera' | 'sun' | 'schedule' | 'forced';
export interface CloudEnvironmentDueInput {
    framesSinceBake: number;
    updateInterval: number;
    graphChanged: boolean;
    cameraMoved: number;
    distanceThreshold: number;
    sunMoved: number;
    angularThreshold: number;
    baked: boolean;
    forced: boolean;
}
export declare function cloudEnvironmentRefreshDue(input: CloudEnvironmentDueInput): CloudEnvironmentReason | null;
export interface CloudEnvironmentBakeInput {
    renderer: Parameters<CubeCamera['update']>[0];
    cameraPositionECEF: Vector3;
    sunDirectionECEF: Vector3;
}
export declare class CloudEnvironmentNode extends TempNode {
    static get type(): string;
    readonly settings: CloudEnvironmentSettings;
    private cubeTarget;
    private cubeCamera;
    private skyNode;
    private readonly material;
    private readonly mesh;
    private readonly bakedCameraPosition;
    private readonly bakedSunDirection;
    private baked;
    private staleGraph;
    private framesSinceBake;
    private forced;
    private bakes;
    private lastReason;
    constructor();
    get size(): number;
    get updateInterval(): number;
    get cubeTexture(): CubeRenderTarget['texture'] | null;
    get hasBaked(): boolean;
    get bakeCount(): number;
    get lastBakeReason(): CloudEnvironmentReason | null;
    refresh(): void;
    setup(): Node | null;
    buildGraph(ctx: CloudsContext, marchU: MarchUniforms, layerU: LayerUniforms, paramU: ParameterUniforms, host: MarchGraphHost): void;
    clear(): void;
    bakeIfDue(input: CloudEnvironmentBakeInput): CloudEnvironmentReason | null;
    dispose(): void;
}
export declare function environmentTexelFootprint(size: number, maxRayDistance: number): number;
