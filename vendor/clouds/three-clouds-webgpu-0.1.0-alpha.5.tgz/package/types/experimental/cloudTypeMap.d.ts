import { DataTexture, Vector4 } from 'three';
import { Node, UniformNode } from 'three/webgpu';
export interface CloudTypeArchetype {
    shapeAmount?: [number, number, number, number];
    shapeDetailAmount?: [number, number, number, number];
    shapeAlteringBias?: [number, number, number, number];
    densityScale?: [number, number, number, number];
    expTerm?: [number, number, number, number];
    exponent?: [number, number, number, number];
    linearTerm?: [number, number, number, number];
    constantTerm?: [number, number, number, number];
}
export interface CloudTypeAnchor {
    name: string;
    at: number;
    archetype: CloudTypeArchetype;
}
export declare const CLOUD_TYPE_PARAMS: readonly ["shapeAmount", "shapeDetailAmount", "shapeAlteringBias", "densityScale", "expTerm", "exponent", "linearTerm", "constantTerm"];
export type CloudTypeParam = (typeof CLOUD_TYPE_PARAMS)[number];
export declare const cloudTypeAnchors: readonly [
    CloudTypeAnchor,
    CloudTypeAnchor,
    CloudTypeAnchor
];
export type CloudTypeAnchorDeltas = [
    UniformNode<'vec4', Vector4>,
    UniformNode<'vec4', Vector4>,
    UniformNode<'vec4', Vector4>
];
export type CloudTypeDeltas = Record<CloudTypeParam, CloudTypeAnchorDeltas>;
export interface CloudTypeBlendNodes {
    sampleMorph: (globeUv: Node<'vec2'>) => Node<'float'>;
    deltas: CloudTypeDeltas;
}
export declare const CLOUD_TYPE_TENT_SCOPES: readonly ["weather", "media"];
export type CloudTypeTentScope = (typeof CLOUD_TYPE_TENT_SCOPES)[number];
export declare function cloudTypeTentNames(scope: CloudTypeTentScope, suffix?: string | number): [string, string, string];
export declare function createCloudTypeMap(options?: {
    size?: number;
    cells?: number;
    seed?: number;
}): DataTexture;
export declare class CloudTypes {
    private _map;
    private readonly _mapNode;
    private readonly deltas;
    private _blendNodes;
    constructor(map?: DataTexture);
    get map(): DataTexture;
    setMap(map: DataTexture): this;
    packDeltas(): void;
    blendNodes(repeat: Node<'vec2'>, offset: Node<'vec2'>): CloudTypeBlendNodes;
    dispose(): void;
}
export declare function cloudTypeTentWeights(morph: Node<'float'>, scope: CloudTypeTentScope, suffix?: string | number): [Node<'float'>, Node<'float'>, Node<'float'>];
export declare function blendCloudTypeParameter(base: Node<'vec4'>, weights: [Node<'float'>, Node<'float'>, Node<'float'>], d0: Node<'vec4'>, d1: Node<'vec4'>, d2: Node<'vec4'>): Node<'vec4'>;
export declare function cpuCloudTypeTentWeights(morph: number): [number, number, number];
export declare function cpuBlendCloudTypeParameter(base: [number, number, number, number], morph: number, param: CloudTypeParam, anchors: readonly CloudTypeArchetype[]): [number, number, number, number];
export declare const cloudTypeArchetypes: readonly CloudTypeArchetype[];
