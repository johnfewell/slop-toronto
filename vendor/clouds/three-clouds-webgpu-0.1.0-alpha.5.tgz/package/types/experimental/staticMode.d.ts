import { Camera } from 'three';
import { CloudsContext } from '../CloudsContext.js';
export declare const STATIC_CONVERGENCE_TOLERANCE = 0.001;
export interface ConvergenceInputs {
    temporalUpscale: boolean;
    cloudAlpha: number;
    shadowAlpha: number | null;
    shadowInterval: number;
}
export declare function staticConvergenceFrames(input: ConvergenceInputs, tolerance?: number): number;
export declare function contextConvergenceFrames(ctx: CloudsContext): number;
export interface FrameDimensions {
    fullW: number;
    fullH: number;
}
export declare class StaticModeTracker {
    private _renderedFrames;
    private _lastFrameSeen;
    private _hasSnapshot;
    private readonly _lastCameraWorld;
    private readonly _lastCameraProjection;
    private _lastSunX;
    private _lastSunY;
    private _lastSunZ;
    private _lastTime;
    private _lastFullW;
    private _lastFullH;
    private _lastGraphVersion;
    private readonly _lastKnobs;
    private readonly _currentKnobs;
    private _lastTextures;
    private _lastTextureVersions;
    get renderedFrames(): number;
    reset(): void;
    private matchesBasic;
    private matchesCamera;
    private matchesKnobsAndTextures;
    private matchesSnapshot;
    isStatic(ctx: CloudsContext, camera: Camera, size: FrameDimensions, historyReady: boolean): boolean;
    recordRender(ctx: CloudsContext, camera: Camera, size: FrameDimensions): void;
    private saveSnapshot;
}
