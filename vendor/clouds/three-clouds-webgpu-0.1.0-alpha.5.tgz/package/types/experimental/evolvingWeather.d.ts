import { TextureNode } from 'three/webgpu';
import { CloudsContext } from '../CloudsContext.js';
import { WeatherSampler } from '../density/sampleWeather.js';
export declare const FLOW_MAX_STRETCH = 0.15;
export declare const EVOLVING_WEATHER_FIELD_SIZE = 128;
export interface EvolvingWeatherParams {
    windSpeed: number;
    windPatternSize: number;
    cellLifetime: number;
    lifeStrength: number;
}
export declare const evolvingWeatherDefaults: Readonly<EvolvingWeatherParams>;
type Mode = readonly [number, number, number, number];
export declare function waveField(size: number, modes: readonly Mode[]): Float32Array;
export declare function curlWind(size: number, potential: Float32Array): {
    x: Float32Array;
    y: Float32Array;
};
export declare function maxFieldGradient(size: number, fields: readonly Float32Array[]): number;
export interface EvolvingWeatherField {
    data: Uint8Array;
    size: number;
    windGradient: number;
    seedGradient: number;
}
export declare function buildEvolvingWeatherField(size?: number): EvolvingWeatherField;
export declare function metresPerWeatherUnit(bottomRadius: number, localWeatherRepeat: number): number;
export interface EvolvingWeatherFrame {
    fieldScale: number;
    flowPeriod: number;
    flowPhase: number;
    flowReach: number;
    time: number;
    cellLifetime: number;
    lifeStrength: number;
}
export declare function evolvingWeatherFrame(params: EvolvingWeatherParams, time: number, metresPerUnit: number, windGradient: number): EvolvingWeatherFrame;
export interface EvolvingWeatherSample {
    offsets: [[number, number], [number, number]];
    weights: [number, number];
    growth: number;
}
export declare function cpuEvolvingWeather(wind: readonly [number, number], lifeSeed: number, periodSeed: number, frame: EvolvingWeatherFrame): EvolvingWeatherSample;
export declare class EvolvingWeather {
    private _field;
    private _texture;
    private _uniforms;
    private _frame;
    get frame(): Readonly<EvolvingWeatherFrame> | null;
    build(ctx: CloudsContext, weather: TextureNode): WeatherSampler | null;
    private createSampler;
    update(ctx: CloudsContext): void;
    private ensureField;
    private ensureTexture;
    private createTexture;
    dispose(): void;
}
export {};
