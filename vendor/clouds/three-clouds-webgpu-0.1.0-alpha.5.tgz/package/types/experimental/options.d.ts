export interface ExperimentalCloudOptions {
    cloudFrontRefinement: boolean;
    computeResolve: boolean;
    windReprojection: boolean;
    distantCloudShadows: boolean;
    directionalSkylight: boolean;
    distantShapeDetailFade: boolean;
    cloudTypeMap: boolean;
    convectiveProfile: boolean;
    proceduralWeather: boolean;
    evolvingWeather: boolean;
    rainShafts: boolean;
    moonlight: boolean;
    lightning: boolean;
    cloudEnvironment: boolean;
    staticMode: boolean;
    cirrusDeck: boolean;
    shadowRoundRobin: boolean;
}
export declare const experimentalDefaults: Readonly<ExperimentalCloudOptions>;
export declare const SECONDARY_GRAPH_EXPERIMENTAL: ReadonlySet<keyof ExperimentalCloudOptions>;
export interface ExperimentalWarningInput {
    experimental: Readonly<ExperimentalCloudOptions>;
    debug: string;
    castsShadow: boolean;
    localWeatherVelocity: {
        lengthSq(): number;
    };
    lightShafts: boolean;
}
export interface ExperimentalWarning {
    id: string;
    message: string;
}
export declare function experimentalWarnings(input: ExperimentalWarningInput): ExperimentalWarning[];
