import { CloudLayerLike } from '../CloudLayer.js';
import { CloudLayers } from '../CloudLayers.js';
import { DensityProfileLike } from '../DensityProfile.js';
export type CloudTypeLayers = readonly [
    CloudLayerLike,
    CloudLayerLike,
    CloudLayerLike,
    CloudLayerLike
];
export interface CloudTypePreset {
    readonly coverage: number;
    readonly layers: CloudTypeLayers;
}
export declare const cloudTypePresetNames: readonly ["fairWeatherCumulus", "stratocumulusDeck", "overcastSheet", "highCirrus", "groundFog", "mixedSky"];
export type CloudTypePresetName = (typeof cloudTypePresetNames)[number];
export declare const cloudTypePresets: Record<CloudTypePresetName, CloudTypePreset>;
export interface CloudTypePresetTarget {
    readonly cloudLayers: CloudLayers;
    coverage: number;
}
export declare function isCloudTypePresetName(value: unknown): value is CloudTypePresetName;
export declare function cloudTypeProfileAt(profile: DensityProfileLike, heightFraction: number): number;
export declare function applyCloudTypePreset(target: CloudTypePresetTarget, name: CloudTypePresetName): CloudTypePreset;
