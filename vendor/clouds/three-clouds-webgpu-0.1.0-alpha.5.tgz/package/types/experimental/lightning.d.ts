import { Vector3 } from 'three';
import { Node, UniformNode } from 'three/webgpu';
export interface LightningState {
    position: Vector3;
    intensity: number;
    colour: Vector3;
}
export interface LightningParams {
    softening: number;
    depthIterationCount: number;
    phaseAttenuation: number;
}
export declare const lightningParamsDefault: Readonly<LightningParams>;
export interface LightningUniforms {
    position: UniformNode<'vec3', Vector3>;
    intensity: UniformNode<'float', number>;
    colour: UniformNode<'vec3', Vector3>;
    active: UniformNode<'float', number>;
}
export declare function createLightningUniforms(state: LightningState | null): LightningUniforms;
export declare function updateLightningUniforms(uniforms: LightningUniforms, state: LightningState | null): void;
export interface LightningDeps {
    inScatter: (position: Node<'vec3'>, mipLevel: Node<'float'>, jitter: Node<'float'>) => Node<'vec3'>;
}
export interface LightningBuildDeps {
    marchOpticalDepth: (rayOrigin: Node<'vec3'>, rayDirection: Node<'vec3'>, maxIterationCount: Node<'float'>, mipLevel: Node<'float'>, jitter: Node<'float'>) => Node<'vec2'>;
    cameraPosition: Node<'vec3'>;
    accuratePhaseFunction: boolean;
    scatterAnisotropy1: number;
    scatterAnisotropy2: number;
    scatterAnisotropyMix: number;
    uniforms: LightningUniforms;
    params: LightningParams;
}
export declare function buildLightningDeps(deps: LightningBuildDeps): LightningDeps;
export declare function lightningInScatterCPU(colour: [number, number, number], intensity: number, distanceSq: number, opticalDepth: number, phaseValue: number): [number, number, number];
export declare function lightningDistanceSqCPU(distanceSq: number, softening: number): number;
export interface FlashScheduleOptions {
    interval: number;
    duration: number;
    peak: number;
    restrikeRatio: number;
}
export declare const flashScheduleDefaults: Readonly<FlashScheduleOptions>;
export interface FlashSample {
    intensity: number;
    timeInGroup: number;
}
export declare function flashEnvelopeCPU(time: number, seed: number, options?: Readonly<FlashScheduleOptions>): FlashSample;
export declare function seededUnit(index: number, seed: number): number;
export declare function flashPositionCPU(index: number, seed: number, bottomRadius: number, altitude: number): Vector3;
