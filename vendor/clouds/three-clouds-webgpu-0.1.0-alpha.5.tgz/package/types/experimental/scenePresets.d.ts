import { CirrusDeckParams } from './cirrusDeck.js';
import { CloudShapeParams } from './cloudShape.js';
import { CloudTypeLayers, CloudTypePresetName, CloudTypePresetTarget } from './cloudTypePresets.js';
import { ConvectiveProfileParams } from './convectiveProfile.js';
import { ExperimentalCloudOptions } from './options.js';
import { CelestialDirections, CelestialSink, TimeOfDayRequest } from './timeOfDay.js';
export declare const scenePresetNames: readonly ["partlyCloudy", "fluffy", "pixar", "stunningSunset", "moonlitNight", "hazy", "thunderstorm", "stormyEvening"];
export type ScenePresetName = (typeof scenePresetNames)[number];
/**
 * A sky, assembled from existing knobs. `timeOfDay` is local solar time as a
 * fraction of a day, so 0.5 is local noon for every longitude, and what the sun
 * does with it depends on the observer's latitude and the date: 0.75 is sunset
 * at any latitude on an equinox, and earlier or later by up to an hour either
 * side of it.
 */
export interface ScenePreset {
    readonly cloudType: CloudTypePresetName;
    readonly timeOfDay: number;
    /** `context.coverage`, the global cloud fraction in [0, 1] */
    readonly coverage: number;
    /** Relative tone-mapping exposure multiplier where 1 is the story baseline */
    readonly exposure: number;
    /** Whether the haze layer is marched alongside the clouds */
    readonly haze: boolean;
    /** Optional per-lane overrides applied on top of `cloudType` */
    readonly layers?: CloudTypeLayers;
    /** Optional `context.cloudShape` overrides */
    readonly cloudShape?: Partial<CloudShapeParams>;
    /** Optional `context.convectiveProfile` overrides */
    readonly convectiveProfile?: Partial<ConvectiveProfileParams>;
    /** Optional `context.cirrusDeck` scalar overrides */
    readonly cirrusDeck?: Partial<Pick<CirrusDeckParams, 'altitude' | 'strength' | 'scale' | 'velocityU' | 'velocityV'>>;
    /** Optional `context.localWeatherOffset` UV shift */
    readonly localWeatherOffset?: readonly [number, number];
    /** Optional `context.moonGain` for moonlit skies */
    readonly moonGain?: number;
    /** Optional `context.moonColor` RGB tint for moonlit skies */
    readonly moonColor?: readonly [number, number, number];
    /** Optional `context.skyLightScale` override */
    readonly skyLightScale?: number;
    /** Optional `context.groundBounceScale` override */
    readonly groundBounceScale?: number;
    /** Optional `context.powderScale` override */
    readonly powderScale?: number;
    /** Optional `context.clouds.hazeDensityScale` override */
    readonly hazeDensityScale?: number;
    /**
     * Experimental options the preset needs, written through the context's setter
     * so a preset pays the graph rebuild that option costs.
     * `applyReferenceMode` afterwards pins them back off
     */
    readonly experimental?: Partial<ExperimentalCloudOptions>;
}
export declare const scenePresets: Record<ScenePresetName, ScenePreset>;
export declare function isScenePresetName(value: unknown): value is ScenePresetName;
/**
 * What a preset writes on the clouds side. `CloudsContext` satisfies it, and
 * so does a plain object, because every field is a property the preset already
 * knows how to set. Experimental options merge rather than replace, so a preset
 * that wants one option does not silently clear the caller's other choices.
 */
export interface ScenePresetTarget extends CloudTypePresetTarget {
    haze: boolean;
    experimental: ExperimentalCloudOptions;
    cloudShape?: CloudShapeParams;
    convectiveProfile?: ConvectiveProfileParams;
    cirrusDeck?: CirrusDeckParams;
    localWeatherOffset?: {
        set: (x: number, y: number) => unknown;
    };
    moonGain?: number;
    moonColor?: {
        set: (r: number, g: number, b: number) => unknown;
    };
    skyLightScale?: number;
    groundBounceScale?: number;
    powderScale?: number;
    clouds?: {
        hazeDensityScale: number;
    };
}
/** The instant and the place, plus where the sun and moon go */
export interface ScenePresetRequest extends TimeOfDayRequest {
    readonly sinks: CelestialSink | readonly CelestialSink[];
}
/** What a preset left behind, so a caller can light from it without recomputing */
export interface AppliedScenePreset {
    readonly preset: ScenePreset;
    /** The instant the preset's time of day resolved to */
    readonly date: Date;
    readonly directions: CelestialDirections;
}
/**
 * Write a whole scene: cloud type, coverage, haze, the experimental options it
 * needs, then the sun and moon for its time of day at the caller's place. One
 * call because a preset applied halfway is a different sky, and the half that
 * is missing is the half nobody looks at.
 *
 * The cloud-type preset is applied first, so its lanes and coverage are in
 * place before this preset's layers and coverage overwrite them.
 */
export declare function applyScenePreset(target: ScenePresetTarget, name: ScenePresetName, request: ScenePresetRequest): AppliedScenePreset;
