import { Camera, Object3D, Texture } from 'three';
import { QuadMesh, Node } from 'three/webgpu';
import { CloudEnvironmentNode } from './cloudEnvironment.js';
export type WaterProSkyRenderer = Parameters<QuadMesh['render']>[0];
/**
 * The seam Water Pro's `WaterSystem.setSky` binds a sky provider to, at 3.5.1.
 *
 * Its optional `getBrightnessNode`, `getSun` and `setActive` are deliberately
 * absent, so Water Pro falls back to a brightness of one, keeps its own sun
 * authoritative, and never asks the provider to gate a render.
 */
export interface WaterProSkyProvider {
    createFogSampler(): (direction: Node) => Node;
    createReflectionSampler(): (direction: Node, roughness: Node) => Node;
    dispose(): void;
    followCamera(camera: Camera): void;
    getEnvironmentTexture(): Texture;
    getMeshes(): Object3D[];
}
export interface WaterProCloudSkyOptions {
    /**
     * Equirectangular width in texels, and half that in height. The default is
     * four times the cube's face size, so a 64 texel cube becomes 256 by 128.
     */
    readonly width: number;
    /**
     * Base microfacet roughness added to what the water surface derives from its
     * own waves, in `[0, 1]`, live. Water Pro's own `Sky` defaults to 0.15 and
     * the floor is kept here: the cube this sharpens is 64 texels a side, so a
     * mirror reflection reads its blocks rather than a sky.
     */
    readonly reflectionRoughness: number;
}
export declare const DEFAULT_WATER_PRO_CLOUD_SKY: WaterProCloudSkyOptions;
export type WaterProSkySyncReason = 'initial' | 'bake' | 'cube';
export interface WaterProSkySyncInput {
    bakeCount: number;
    cube: Texture | null;
    baked: boolean;
    syncedBakeCount: number;
    syncedCube: Texture | null;
}
/**
 * Whether this frame should convert the environment cube into the equirect
 * Water Pro samples, and why. Tested in order, as
 * `cloudEnvironmentRefreshDue` is, so the reason a caller reads is the one that
 * fired. `null` is the common answer: there is no image to convert before the
 * first bake, and a frame between bakes has nothing new.
 */
export declare function waterProSkySyncDue(input: WaterProSkySyncInput): WaterProSkySyncReason | null;
/**
 * The equirectangular settings Water Pro's custom-sky guide requires, applied
 * to the texture a bake renders into. Repeat wrapping closes the atan2 seam at
 * the back of the map, no mip chain keeps a one sample per texel bake from
 * being read at a level it was never filtered for, and linear filtering is what
 * a 256 by 128 bake can afford.
 */
export declare function applyEquirectSkySettings(target: Texture): void;
/**
 * Water Pro's sky, backed by `cloudsPass.environment`.
 *
 * Water Pro samples an equirectangular image, which is `Sky`'s `equirect`
 * parameter, so the environment cube cannot be handed to it as it stands. Each
 * bake is converted into a 2:1 equirect render target that Water Pro then
 * samples for its fog tint and its water reflections, with the clouds in both.
 *
 * ```ts
 * const cloudsPass = clouds({ sceneDepth })
 * cloudsPass.cloudsContext.experimental = { cloudEnvironment: true }
 * const sky = new WaterProCloudSky(cloudsPass.environment)
 * water.setSky(sky)
 * // once per frame, after the renderer has run the clouds pass
 * sky.update(renderer)
 * ```
 *
 * The equirect texture is one object for the provider's life, because Water
 * Pro compares `getEnvironmentTexture()` by reference every frame and reruns
 * its whole `setSky` rebind when it changes. The image behind it is
 * re-rendered and `pmremVersion` bumped instead, which is the signal three's
 * own PMREM reads.
 */
export declare class WaterProCloudSky implements WaterProSkyProvider {
    private readonly environment;
    private readonly settings;
    private readonly material;
    private readonly quad;
    private readonly roughnessUniform;
    private equirect;
    private cube;
    private reflectionNode;
    private fogNode;
    private syncedBakeCount;
    private bakes;
    private lastReason;
    private disposed;
    constructor(environment: CloudEnvironmentNode, options?: Partial<WaterProCloudSkyOptions>);
    /** The equirect Water Pro samples. One reference for the provider's life */
    get environmentTexture(): Texture;
    getEnvironmentTexture(): Texture;
    get width(): number;
    get height(): number;
    get bakeCount(): number;
    get lastSyncReason(): WaterProSkySyncReason | null;
    /** False until the first conversion, which needs a cube bake to read */
    get synced(): boolean;
    get reflectionRoughness(): number;
    set reflectionRoughness(value: number);
    private allocateEquirect;
    /**
     * Convert the environment cube if this frame has a new bake, and return why,
     * or null when the frame had nothing new. Call it once per frame, after the
     * renderer has run the pass that bakes the cube: the frame just drawn shows
     * the previous equirect, the same one frame lag any reflection map has.
     */
    update(renderer: WaterProSkyRenderer): WaterProSkySyncReason | null;
    createFogSampler(): (direction: Node) => Node;
    createReflectionSampler(): (direction: Node, roughness: Node) => Node;
    /**
     * Nothing. The backdrop is the scene's own sky, and this provider only
     * supplies what Water Pro samples. Water Pro adds these to the scene and
     * excludes them from its capture pass, so an empty list leaves both alone.
     */
    getMeshes(): Object3D[];
    /** Nothing to re-centre, since `getMeshes` is empty. Kept for the interface */
    followCamera(_camera: Camera): void;
    dispose(): void;
}
