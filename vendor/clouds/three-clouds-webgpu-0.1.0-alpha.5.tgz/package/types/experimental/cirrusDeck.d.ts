import { Vector2, Camera, Texture } from 'three';
import { Node, StructNode, TextureNode, UniformNode } from 'three/webgpu';
export interface CirrusDeckParams {
    altitude: number;
    strength: number;
    scale: number;
    velocityU: number;
    velocityV: number;
    texture: Texture | null;
}
export declare const cirrusDeckDefaults: Readonly<CirrusDeckParams>;
export declare const CIRRUS_DECK_MIN_COSINE = 0.02;
export declare function cirrusDeckDistanceCPU(origin: readonly [number, number, number], direction: readonly [number, number, number], deckRadius: number, bottomRadius: number, sceneRayDistance: number): number;
export declare function cirrusDeckLodCPU(distance: number, cosine: number, lodScale: number): number;
export declare function overCPU(front: readonly [number, number, number, number], back: readonly [number, number, number, number]): [number, number, number, number];
export interface CirrusDeckUniforms {
    altitude: UniformNode<'float', number>;
    strength: UniformNode<'float', number>;
    repeat: UniformNode<'float', number>;
    offset: UniformNode<'vec2', Vector2>;
    lodScale: UniformNode<'float', number>;
    map: TextureNode;
}
export declare function createCirrusDeckUniforms(defaultTexture: Texture): CirrusDeckUniforms;
export interface CirrusDeckFrame {
    bottomRadius: number;
    time: number;
    height: number;
    camera: Camera;
}
export declare function updateCirrusDeckUniforms(uniforms: CirrusDeckUniforms, params: CirrusDeckParams, frame: CirrusDeckFrame, defaultTexture: Texture): void;
export declare function pixelAngle(camera: Camera, height: number): number;
export interface CirrusDeckDeps {
    uniforms: CirrusDeckUniforms;
    bottomRadius: Node<'float'>;
    sunDirection: Node<'vec3'>;
    getSunSkyIrradiance: (position: Node<'vec3'>) => StructNode;
    applyAerialPerspective: (cameraPosition: Node<'vec3'>, frontPosition: Node<'vec3'>, shadowLength: Node<'float'>, color: Node<'vec4'>) => Node<'vec4'>;
    scatterAnisotropy1: number;
    scatterAnisotropy2: number;
    scatterAnisotropyMix: number;
}
export declare function createCirrusDeckComposite(deps: CirrusDeckDeps): import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, import('three').Vector4 | Node<"vec4">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"vec4">>;
