import { Node } from 'three/webgpu';
export declare const directionalSkyFactor: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"vec3">>;
export declare function createDirectionalSkylight(cameraPosition: Node<'vec3'>, sunDirection: Node<'vec3'>, bottomRadius: Node<'float'>, height: Node<'float'>): {
    prepare: (direction: Node<"vec3">) => void;
    evaluate: () => Node<"vec3">;
};
export declare function directionalSkyFactorCPU(toward: number, away: number, muToward: number, muAway: number): number;
