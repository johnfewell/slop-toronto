import { Node, UniformNode } from 'three/webgpu';
export interface RainShaftParams {
    strength: number;
    density: number;
    slant: number;
}
export declare const rainShaftDefaults: Readonly<RainShaftParams>;
export declare const RAIN_SHAFT_GROUND_FADE = 0.35;
export declare const RAIN_SHAFT_TOP_SOFTNESS = 0.15;
export declare const RAIN_SHAFT_RAGGEDNESS = 0.55;
export declare const RAIN_SHAFT_ALBEDO = 0.12;
export declare const RAIN_SHAFT_SUN_EXTINCTION = 0.01;
export declare const RAIN_SHAFT_STEP_COUNT = 4;
export declare const RAIN_SHAFT_LEAN: readonly [number, number];
export declare const rainShaftDensity: import('three/src/nodes/TSL.js').FnNode<[import('three').Vector2 | Node<"vec2">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
export declare function rainShaftCellCPU(noise: number, threshold: number, softness: number): number;
export declare function rainShaftDensityFromNoiseCPU(noise: number, threshold: number, softness: number, heightFraction: number, strength: number, density: number): number;
export declare function rainShaftDensityCPU(u: number, v: number, cellScale: number, threshold: number, softness: number, heightFraction: number, strength: number, density: number): number;
export declare function rainShaftNoiseCPU(u: number, v: number, cellScale: number): number;
export interface RainShaftUniforms {
    strength: UniformNode<'float', number>;
    density: UniformNode<'float', number>;
    slant: UniformNode<'float', number>;
}
export declare function createRainShaftUniforms(params: RainShaftParams): RainShaftUniforms;
export declare function updateRainShaftUniforms(uniforms: RainShaftUniforms, params: RainShaftParams): void;
export interface RainShaftDeps {
    density: (height: Node<'float'>, uv: Node<'vec2'>) => Node<'float'>;
    uniforms: RainShaftUniforms;
}
export declare function buildRainShaftDeps(uniforms: RainShaftUniforms, localWeatherRepeat: Node<'vec2'>, baseHeight: Node<'float'>, cell: {
    cellsPerWeatherTile: number;
    cellThreshold: number;
    cellSoftness: number;
}): RainShaftDeps;
