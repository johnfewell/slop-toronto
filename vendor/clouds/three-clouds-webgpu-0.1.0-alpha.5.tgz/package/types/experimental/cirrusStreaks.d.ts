import { DataTexture } from 'three';
export declare const CIRRUS_STREAKS_SIZE = 512;
export declare function periodicValueNoise(x: number, y: number, periodX: number, periodY: number, seed: number): number;
export declare function cirrusStreakValue(u: number, v: number, seed: number): number;
export declare function generateCirrusStreaks(size?: number, seed?: number): Uint8Array;
export declare function cirrusStreakMips(level0: Uint8Array, size: number): Array<{
    data: Uint8Array;
    width: number;
    height: number;
}>;
export declare function createCirrusStreaksTexture(size?: number, seed?: number): DataTexture;
