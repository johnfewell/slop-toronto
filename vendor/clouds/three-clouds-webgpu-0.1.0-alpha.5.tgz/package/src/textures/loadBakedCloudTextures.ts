// Ported from @takram/three-clouds (MIT, Copyright (c) 2024 Shota Matsuda)
// https://github.com/takram-design-engineering/three-geospatial

import {
  Data3DTexture,
  LinearFilter,
  LinearMipMapLinearFilter,
  NearestFilter,
  NoColorSpace,
  RedFormat,
  RepeatWrapping,
  TextureLoader,
  UnsignedByteType,
  type Texture
} from 'three'

import {
  CLOUD_SHAPE_DETAIL_TEXTURE_SIZE,
  CLOUD_SHAPE_TEXTURE_SIZE
} from '../constants'
import { BLUE_NOISE_RANK_MAP_BASE64 } from './blueNoiseRankMap'

/** The four textures a {@link CloudsContext} marches against */
export interface BakedCloudTextures {
  localWeatherTexture: Texture
  turbulenceTexture: Texture
  shapeTexture: Data3DTexture
  shapeDetailTexture: Data3DTexture
}

/**
 * Where to fetch each of the four. The shapes are raw 3D payloads sized by
 * {@link CLOUD_SHAPE_TEXTURE_SIZE} and {@link CLOUD_SHAPE_DETAIL_TEXTURE_SIZE}
 * rather than images, so they cannot go through a `TextureLoader`.
 *
 * The defaults for all four are exported from the package root.
 */
export interface BakedCloudTextureUrls {
  localWeather: string
  turbulence: string
  shape: string
  shapeDetail: string
}

function load2D(loader: TextureLoader, url: string): Promise<Texture> {
  return new Promise((resolve, reject) => {
    loader.load(
      url,
      texture => {
        texture.minFilter = LinearMipMapLinearFilter
        texture.magFilter = LinearFilter
        texture.wrapS = RepeatWrapping
        texture.wrapT = RepeatWrapping
        texture.colorSpace = NoColorSpace
        texture.needsUpdate = true
        resolve(texture)
      },
      undefined,
      reject
    )
  })
}

async function load3D(url: string, size: number): Promise<Data3DTexture> {
  const response = await fetch(url)
  if (!response.ok) {
    throw new Error(`Failed to load 3D texture: ${url}`)
  }
  const buffer = await response.arrayBuffer()
  const texture = new Data3DTexture(new Uint8Array(buffer), size, size, size)
  texture.format = RedFormat
  texture.minFilter = LinearFilter
  texture.magFilter = LinearFilter
  texture.wrapS = RepeatWrapping
  texture.wrapT = RepeatWrapping
  texture.wrapR = RepeatWrapping
  texture.colorSpace = NoColorSpace
  texture.needsUpdate = true
  return texture
}

/**
 * Load the four baked assets the original ships, with the same filters and
 * wrapping it applies. Assign the result to the matching context properties:
 *
 * ```ts
 * const cloudsContext = cloudsPass.cloudsContext
 * const baked = await loadBakedCloudTextures({
 *   localWeather: DEFAULT_LOCAL_WEATHER_URL,
 *   turbulence: DEFAULT_TURBULENCE_URL,
 *   shape: DEFAULT_SHAPE_URL,
 *   shapeDetail: DEFAULT_SHAPE_DETAIL_URL
 * })
 * cloudsContext.localWeatherTexture = baked.localWeatherTexture
 * cloudsContext.shapeTexture = baked.shapeTexture
 * cloudsContext.shapeDetailTexture = baked.shapeDetailTexture
 * cloudsContext.turbulenceTexture = baked.turbulenceTexture
 * ```
 *
 * The 3D loads use `fetch`, so a cross-origin file:// page needs the assets
 * served over http. All four resolve or reject together.
 */
export async function loadBakedCloudTextures(
  urls: BakedCloudTextureUrls
): Promise<BakedCloudTextures> {
  const loader = new TextureLoader()
  const [
    localWeatherTexture,
    turbulenceTexture,
    shapeTexture,
    shapeDetailTexture
  ] = await Promise.all([
    load2D(loader, urls.localWeather),
    load2D(loader, urls.turbulence),
    load3D(urls.shape, CLOUD_SHAPE_TEXTURE_SIZE),
    load3D(urls.shapeDetail, CLOUD_SHAPE_DETAIL_TEXTURE_SIZE)
  ])
  return {
    localWeatherTexture,
    turbulenceTexture,
    shapeTexture,
    shapeDetailTexture
  }
}

const JITTER_WIDTH = 128
const JITTER_HEIGHT = 128
const JITTER_DEPTH = 64
const GOLDEN_RATIO_CONJUGATE = 0.6180339887498949

function lowbias32(x: number): number {
  x = (x + 0x9e3779b9) | 0
  x ^= x >>> 16
  x = Math.imul(x, 0x21f0aaad)
  x ^= x >>> 15
  x = Math.imul(x, 0x735a2d97)
  x ^= x >>> 15
  return x >>> 0
}

function jitterVolume(data: Uint8Array): Data3DTexture {
  const texture = new Data3DTexture(
    data,
    JITTER_WIDTH,
    JITTER_HEIGHT,
    JITTER_DEPTH
  )
  texture.format = RedFormat
  texture.type = UnsignedByteType
  texture.minFilter = NearestFilter
  texture.magFilter = NearestFilter
  texture.wrapS = RepeatWrapping
  texture.wrapT = RepeatWrapping
  texture.wrapR = RepeatWrapping
  texture.colorSpace = NoColorSpace
  texture.needsUpdate = true
  return texture
}

/**
 * The white-noise hash volume the jitter defaulted to before blue noise. It is
 * still exported because the parity harness samples it, and its bytes are part
 * of the ladder's committed evidence, so replacing the default with it would
 * move every captured metric.
 */
export function createHashJitterTexture(): Data3DTexture {
  const size = JITTER_WIDTH * JITTER_HEIGHT * JITTER_DEPTH
  const data = new Uint8Array(size)
  for (let i = 0; i < size; i++) {
    data[i] = lowbias32(i) & 0xff
  }
  return jitterVolume(data)
}

/**
 * The 128x128x64 blue-noise jitter volume the context uses when you do not
 * assign one, built offline by `scripts/generate-blue-noise.mjs` and embedded
 * as a rank map. Slice k is that map shifted by k times the golden ratio
 * conjugate, so consecutive slices decorrelate. Generated per call and cached
 * by {@link CloudsContext.stbnTexture}.
 *
 * To sample NVIDIA's STBN exactly as the original does instead, load it from
 * upstream and assign it (see ADR-009).
 */
export function createJitterTexture(): Data3DTexture {
  const map = Uint8Array.from(atob(BLUE_NOISE_RANK_MAP_BASE64), c =>
    c.charCodeAt(0)
  )
  const area = JITTER_WIDTH * JITTER_HEIGHT
  const data = new Uint8Array(area * JITTER_DEPTH)
  for (let k = 0; k < JITTER_DEPTH; k++) {
    const offset = Math.floor(0.5 + ((k * GOLDEN_RATIO_CONJUGATE) % 1) * 256)
    for (let p = 0; p < area; p++) {
      data[k * area + p] = (map[p]! + offset) & 0xff
    }
  }
  return jitterVolume(data)
}
