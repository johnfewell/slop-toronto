// Ported from @takram/three-clouds (MIT, Copyright (c) 2024 Shota Matsuda)
// https://github.com/takram-design-engineering/three-geospatial
// Cite: ADR-007 (two shadow consumers: 3.2a aerial, 3.2b light-node)

import type { Node, TextureNode } from 'three/webgpu'

import { AerialPerspectiveNode } from '@takram/three-atmosphere/webgpu'

import { CloudShadowedAerialPerspectiveNode } from './CloudShadowedAerialPerspectiveNode'

// The node types are three/webgpu's, and AerialPerspectiveNode's constructor
// declares @takram/three-geospatial/webgpu's structurally distinct Node, so the
// four arguments cross a package boundary on the way in
export function aerialPerspectiveWithCloudShadow(
  colorNode: Node<'vec4'>,
  // The depth TextureNode, not a float read from it: AerialPerspectiveNode
  // samples it itself, as `scenePass.getTextureNode('depth')` on the plain path,
  // and a caller-side `.r` would sample at the wrong uv
  depthNode: Node<'float'> | TextureNode,
  shadowLengthNode: Node<'vec2'> | null,
  shadowNode: Node<'float'> | null,
  // Same as depthNode: the node samples the normal target itself
  normalNode?: Node<'vec3'> | TextureNode,
  lightingMaskNode: Node<'float'> | null = null
): AerialPerspectiveNode {
  const node = new AerialPerspectiveNode(
    colorNode,
    depthNode,
    normalNode,
    shadowLengthNode
  )

  if (shadowNode == null && lightingMaskNode == null) {
    return node
  }

  // Feature-detect: if upstream AerialPerspectiveNode already has shadowNode,
  // use it directly (avoids the interim subclass copy)
  if (
    'shadowNode' in node &&
    (lightingMaskNode == null || 'lightingMaskNode' in node)
  ) {
    ;(node as unknown as { shadowNode: Node<'float'> | null }).shadowNode =
      shadowNode
    if (lightingMaskNode != null) {
      ;(
        node as unknown as { lightingMaskNode: Node<'float'> }
      ).lightingMaskNode = lightingMaskNode
    }
    return node
  }

  // Interim path: use the subclass that overrides setup() with the shadow
  // multiplication baked in
  const shadowed = new CloudShadowedAerialPerspectiveNode(
    colorNode,
    depthNode,
    normalNode,
    shadowLengthNode
  )
  shadowed.shadowNode = shadowNode
  shadowed.lightingMaskNode = lightingMaskNode
  return shadowed
}
