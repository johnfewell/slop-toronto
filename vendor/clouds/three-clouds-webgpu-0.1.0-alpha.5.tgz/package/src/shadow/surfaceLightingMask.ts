// Ported from @takram/three-clouds (MIT, Copyright (c) 2024 Shota Matsuda)
// https://github.com/takram-design-engineering/three-geospatial
// Cite: ADR-007 (surface lighting is distinct from atmospheric transfer)

import { Fn, mix } from 'three/tsl'
import type { Node } from 'three/webgpu'

// Both inputs already carry the same transmittance. Inscatter is added after
// this selection, so excluding a self-lit receiver cannot exclude its fog
export const applySurfaceLightingMask = /*#__PURE__*/ Fn(
  ([selfLit, postLit, mask]: [Node<'vec3'>, Node<'vec3'>, Node<'float'>]) =>
    mix(selfLit, postLit, mask.clamp(0, 1))
)

export function cpuSurfaceLightingMask(
  selfLit: readonly number[],
  postLit: readonly number[],
  mask: number
): number[] {
  const amount = Math.min(1, Math.max(0, mask))
  return selfLit.map(
    (value, channel) => value * (1 - amount) + postLit[channel]! * amount
  )
}
