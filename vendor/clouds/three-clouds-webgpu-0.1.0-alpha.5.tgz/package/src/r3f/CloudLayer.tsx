// Ported from @takram/three-clouds (MIT, Copyright (c) 2024 Shota Matsuda)
// Cite: r3f/CloudLayer.tsx:1-96

import {
  useContext,
  useEffect,
  useLayoutEffect,
  useState,
  type FC,
  type Ref
} from 'react'

import type { ExpandNestedProps } from '@takram/three-geospatial/r3f'

import {
  CloudLayer as CloudLayerImpl,
  type CloudLayerLike
} from '../CloudLayer'
import { CloudLayers } from '../CloudLayers'
import { CloudLayersContext } from './CloudLayers'

export interface CloudLayerProps
  extends CloudLayerLike, ExpandNestedProps<CloudLayerLike, 'densityProfile'> {
  ref?: Ref<CloudLayerImpl>
  index?: number
}

export const CloudLayer: FC<CloudLayerProps> = ({
  ref: forwardedRef,
  index: indexProp,
  ...props
}) => {
  const context = useContext(CloudLayersContext)
  if (context == null) {
    throw new Error('CloudLayer can only be used within the Clouds component!')
  }

  const { layers, indexPool, disableDefault } = context
  const [index, setIndex] = useState<number>()

  // Claim a slot, and give it back on unmount. A requested index is honoured
  // only if it is still free, otherwise this layer takes the lowest available
  useLayoutEffect(() => {
    if (indexProp != null) {
      const poolIndex = indexPool.indexOf(indexProp)
      if (poolIndex !== -1) {
        indexPool.splice(poolIndex, 1)
        setIndex(indexProp)
        return () => {
          indexPool.push(indexProp)
          setIndex(undefined)
        }
      }
      return
    }
    // Sorting is for predictability only, layer order is not defined
    const claimed = indexPool.sort((a, b) => a - b).shift()
    if (claimed != null) {
      setIndex(claimed)
      return () => {
        indexPool.push(claimed)
        setIndex(undefined)
      }
    }
  }, [indexProp, layers, indexPool])

  // Restore the slot's default on unmount, so a removed <CloudLayer> leaves no
  // trace in the shared CloudLayers instance
  useLayoutEffect(() => {
    if (index == null) {
      return
    }
    const layer = layers[index]!
    return () => {
      layer.copy(
        disableDefault ? CloudLayerImpl.DEFAULT : CloudLayers.DEFAULT[index]!
      )
    }
  }, [layers, index, disableDefault])

  useEffect(() => {
    if (index == null) {
      return
    }
    if (typeof forwardedRef === 'function') {
      forwardedRef(layers[index]!)
    } else if (forwardedRef != null) {
      forwardedRef.current = layers[index]!
    }
  }, [forwardedRef, layers, index])

  // Applied during render so a prop change reaches the next frame. Props are
  // the source of truth, so writes through the forwarded ref are reset on the
  // next render, as in the reference
  if (index != null) {
    const layer = layers[index]!
    layer.copy(
      disableDefault ? CloudLayerImpl.DEFAULT : CloudLayers.DEFAULT[index]!
    )
    layer.set(props)
  }

  return null
}
