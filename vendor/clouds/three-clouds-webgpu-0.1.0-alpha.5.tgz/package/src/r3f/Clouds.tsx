// Ported from @takram/three-clouds (MIT, Copyright (c) 2024 Shota Matsuda)
// Cite: r3f/Clouds.tsx:42-252

import { useThree } from '@react-three/fiber'
import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  type FC,
  type ReactNode,
  type Ref
} from 'react'
import {
  Data3DTexture,
  LinearFilter,
  LinearMipMapLinearFilter,
  NoColorSpace,
  RedFormat,
  RepeatWrapping,
  TextureLoader,
  type Matrix4,
  type Texture,
  type Vector3
} from 'three'
import type { Storage3DTexture, TextureNode } from 'three/webgpu'

import {
  DataTextureLoader,
  parseUint8Array,
  STBNLoader
} from '@takram/three-geospatial'

import type { CloudsContext, DebugView } from '../CloudsContext'
import {
  clouds as createCloudsPass,
  type CloudsPassNode
} from '../CloudsPassNode'
import {
  CLOUD_SHAPE_DETAIL_TEXTURE_SIZE,
  CLOUD_SHAPE_TEXTURE_SIZE,
  DEFAULT_LOCAL_WEATHER_URL,
  DEFAULT_SHAPE_DETAIL_URL,
  DEFAULT_SHAPE_URL,
  DEFAULT_TURBULENCE_URL
} from '../constants'
import type { ExperimentalCloudOptions } from '../experimental/options'
import type { QualityPreset } from '../qualityPresets'
import { createJitterTexture } from '../textures/loadBakedCloudTextures'
import type { ProceduralTextureLike } from '../textures/ProceduralTexture'
import { CloudLayers } from './CloudLayers'

// The original's <Clouds> is a CloudsEffect primitive that takes its camera
// from EffectComposerContext. Neither exists for a WebGPU/TSL post chain, and
// @takram/three-atmosphere has no `webgpu/r3f` pattern to copy

// So <Clouds> owns state and lifecycle only: it builds the pass, syncs props,
// hosts <CloudLayer> children and publishes the pass. The app composes it with
// `pass.composite(dst)`, as the reference leaves composing to EffectComposer
export interface CloudsPassContextValue {
  pass: CloudsPassNode
  context: CloudsContext
}

export const CloudsPassContext =
  /*#__PURE__*/ createContext<CloudsPassContextValue | null>(null)

// Returns the pass created by the enclosing <Clouds>, for composing it into a
// PostProcessing chain via `pass.composite(dst)`
export function useClouds(): CloudsPassContextValue {
  const value = useContext(CloudsPassContext)
  if (value == null) {
    throw new Error('useClouds can only be used within the Clouds component!')
  }
  return value
}

function useLoadTexture(
  input: string | Texture | ProceduralTextureLike
): Texture | ProceduralTextureLike | null {
  const loadedTexture = useMemo(
    () =>
      typeof input === 'string'
        ? new TextureLoader().load(input, texture => {
            texture.minFilter = LinearMipMapLinearFilter
            texture.magFilter = LinearFilter
            texture.wrapS = RepeatWrapping
            texture.wrapT = RepeatWrapping
            texture.colorSpace = NoColorSpace
            texture.needsUpdate = true
          })
        : undefined,
    [input]
  )
  useEffect(() => {
    if (loadedTexture != null) {
      return () => {
        loadedTexture.dispose()
      }
    }
  }, [loadedTexture])
  return (typeof input === 'string' ? loadedTexture : input) ?? null
}

// The generic argument is load-bearing: a 3D procedural generator produces a
// Storage3DTexture, and the bare `ProceduralTextureLike` defaults to Texture,
// which the context's 3D slots correctly reject
function useLoad3DTexture(
  input: string | Data3DTexture | ProceduralTextureLike<Storage3DTexture>,
  size: number
): Data3DTexture | ProceduralTextureLike<Storage3DTexture> | null {
  const loadedTexture = useMemo(
    () =>
      typeof input === 'string'
        ? new DataTextureLoader(Data3DTexture, parseUint8Array, {
            width: size,
            height: size,
            depth: size,
            format: RedFormat,
            minFilter: LinearFilter,
            magFilter: LinearFilter,
            wrapS: RepeatWrapping,
            wrapT: RepeatWrapping,
            wrapR: RepeatWrapping,
            colorSpace: NoColorSpace
          }).load(input)
        : undefined,
    [input, size]
  )
  useEffect(() => {
    if (loadedTexture != null) {
      return () => {
        loadedTexture.dispose()
      }
    }
  }, [loadedTexture])
  return (typeof input === 'string' ? loadedTexture : input) ?? null
}

// No prop means the library's blue-noise volume, built synchronously
function useLoadSTBNTexture(
  input: string | Data3DTexture | undefined
): Data3DTexture | null {
  const loadedTexture = useMemo(
    () =>
      typeof input === 'string'
        ? new STBNLoader().load(input)
        : input == null
          ? createJitterTexture()
          : undefined,
    [input]
  )
  useEffect(() => {
    if (loadedTexture != null) {
      return () => {
        loadedTexture.dispose()
      }
    }
  }, [loadedTexture])
  return (input instanceof Data3DTexture ? input : loadedTexture) ?? null
}

// The scalar context properties this component forwards, listed explicitly:
// the context also carries derived and readonly state, and a blanket assign
// would let a typo land silently
const SCALAR_KEYS = [
  'coverage',
  'scatteringCoefficient',
  'absorptionCoefficient',
  'turbulenceDisplacement',
  'skyLightScale',
  'groundBounceScale',
  'powderScale',
  'powderExponent',
  'scatterAnisotropyMix',
  'resolutionScale',
  'sunAngularRadius',
  'bottomRadius',
  'correctAltitude',
  'cameraHeight',
  'time',
  'frame',
  'enabled',
  'warnings'
] as const satisfies ReadonlyArray<keyof CloudsContext>

type ScalarProps = Partial<Pick<CloudsContext, (typeof SCALAR_KEYS)[number]>>

export interface CloudsProps extends ScalarProps {
  ref?: Ref<CloudsPassNode>

  // The scene depth the march reads. Required: the pass cannot be built without
  // it, and defaulting it to null would silently produce a pass that never
  // occludes against geometry
  sceneDepth: TextureNode | null

  debug?: DebugView
  disableDefaultLayers?: boolean

  // Renderer experiments, as one object rather than five props: the context
  // takes a partial and validates it, and a per-prop surface could not tell
  // "absent" from "explicitly false" without restating every default
  experimental?: Partial<ExperimentalCloudOptions>

  // The quality presets already on the context. Applies before the explicit
  // knobs above, so a `resolutionScale` prop still wins over the preset's
  qualityPreset?: QualityPreset

  // Copied, not assigned: both are readonly on the context
  sunDirection?: Vector3
  worldToECEFMatrix?: Matrix4

  localWeatherTexture?: Texture | ProceduralTextureLike | string
  shapeTexture?:
    Data3DTexture | ProceduralTextureLike<Storage3DTexture> | string
  shapeDetailTexture?:
    Data3DTexture | ProceduralTextureLike<Storage3DTexture> | string
  turbulenceTexture?: Texture | ProceduralTextureLike | string
  stbnTexture?: Data3DTexture | string

  children?: ReactNode
}

export const Clouds: FC<CloudsProps> = ({
  ref: forwardedRef,
  sceneDepth,
  debug,
  disableDefaultLayers = false,
  experimental,
  qualityPreset,
  sunDirection,
  worldToECEFMatrix,
  localWeatherTexture: localWeatherTextureProp = DEFAULT_LOCAL_WEATHER_URL,
  shapeTexture: shapeTextureProp = DEFAULT_SHAPE_URL,
  shapeDetailTexture: shapeDetailTextureProp = DEFAULT_SHAPE_DETAIL_URL,
  turbulenceTexture: turbulenceTextureProp = DEFAULT_TURBULENCE_URL,
  stbnTexture: stbnTextureProp,
  children,
  ...scalars
}) => {
  // The pass is built once, and `sceneDepth` is deliberately not a dependency:
  // rebuilding for every fresh node a caller passes would discard temporal
  // history each frame, which shows up as flicker
  const pass = useMemo(() => createCloudsPass({ sceneDepth }), [])
  useEffect(() => {
    return () => {
      pass.dispose()
    }
  }, [pass])

  const context = pass.cloudsContext

  const camera = useThree(state => state.camera)
  pass.camera = camera

  const localWeatherTexture = useLoadTexture(localWeatherTextureProp)
  const shapeTexture = useLoad3DTexture(
    shapeTextureProp,
    CLOUD_SHAPE_TEXTURE_SIZE
  )
  const shapeDetailTexture = useLoad3DTexture(
    shapeDetailTextureProp,
    CLOUD_SHAPE_DETAIL_TEXTURE_SIZE
  )
  const turbulenceTexture = useLoadTexture(turbulenceTextureProp)
  const stbnTexture = useLoadSTBNTexture(stbnTextureProp)

  // Applied during render so a prop change reaches the next frame, as in
  // <CloudLayer>

  // The preset first, so the explicit scalar props below override it. Both
  // reach the same fields (resolutionScale is in both), and last write wins
  if (qualityPreset !== undefined) {
    context.qualityPreset = qualityPreset
  }

  // The context setter validates the keys and the boolean-ness, and bumps
  // graphVersion only on a real change, so a re-render with an equal object is
  // free
  if (experimental !== undefined) {
    context.experimental = experimental
  }

  // `time` and `frame` are plain props (ADR-003): any pair renders the same
  // pixels. Advancing them from useFrame would bring back the accumulator and
  // break seeking, so a consumer sets both from its own clock
  for (const key of SCALAR_KEYS) {
    const value = scalars[key]
    if (value !== undefined) {
      // Each key is its own property type, the lookup is homogeneous only from
      // the outside
      ;(context as unknown as Record<string, unknown>)[key] = value
    }
  }
  if (debug !== undefined) {
    context.debug = debug
  }
  if (sunDirection != null) {
    context.sunDirection.copy(sunDirection)
  }
  if (worldToECEFMatrix != null) {
    context.worldToECEFMatrix.copy(worldToECEFMatrix)
  }

  context.localWeatherTexture = localWeatherTexture
  context.shapeTexture = shapeTexture
  context.shapeDetailTexture = shapeDetailTexture
  context.turbulenceTexture = turbulenceTexture
  context.stbnTexture = stbnTexture

  useEffect(() => {
    if (typeof forwardedRef === 'function') {
      forwardedRef(pass)
    } else if (forwardedRef != null) {
      forwardedRef.current = pass
    }
  }, [forwardedRef, pass])

  const value = useMemo(() => ({ pass, context }), [pass, context])

  return (
    <CloudsPassContext.Provider value={value}>
      <CloudLayers
        layers={context.cloudLayers}
        disableDefault={disableDefaultLayers}
      >
        {children}
      </CloudLayers>
    </CloudsPassContext.Provider>
  )
}
