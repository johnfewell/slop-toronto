// Ported from @takram/three-clouds (MIT, Copyright (c) 2024 Shota Matsuda)
// Cite: r3f/CloudLayers.tsx:1-54

import {
  createContext,
  useLayoutEffect,
  useState,
  type FC,
  type ReactNode
} from 'react'

import { CloudLayer } from '../CloudLayer'
import { CloudLayers as CloudLayersImpl } from '../CloudLayers'

export interface CloudLayersContextValue {
  layers: CloudLayersImpl
  // Which of the four slots are unclaimed. <CloudLayer> takes one on mount and
  // returns it on unmount, so declaration order does not have to match slot
  // order and a layer can be removed without renumbering its siblings
  indexPool: number[]
  disableDefault: boolean
}

export const CloudLayersContext =
  /*#__PURE__*/ createContext<CloudLayersContextValue | null>(null)

export interface CloudLayersProps {
  layers: CloudLayersImpl
  // With `disableDefault`, every slot starts from CloudLayer.DEFAULT (a
  // zero-thickness layer), so only the layers a consumer actually declares
  // contribute. Without it the four slots start from the library's default set.
  disableDefault?: boolean
  children?: ReactNode
}

export const CloudLayers: FC<CloudLayersProps> = ({
  layers,
  disableDefault = false,
  children
}) => {
  const [context, setContext] = useState<CloudLayersContextValue>()

  useLayoutEffect(() => {
    layers.set(
      disableDefault
        ? new Array<CloudLayer>(4).fill(CloudLayer.DEFAULT)
        : CloudLayersImpl.DEFAULT
    )
    setContext({ layers, indexPool: [0, 1, 2, 3], disableDefault })
  }, [layers, disableDefault])

  // Children are withheld until the context exists, so a child can assume a
  // slot pool rather than guarding for one
  return context != null ? (
    <CloudLayersContext.Provider value={context}>
      {children}
    </CloudLayersContext.Provider>
  ) : null
}
