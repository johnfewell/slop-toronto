import { Vector2 } from 'three';
/**
 * The four bundled presets. A preset is a whole set of fields, not a rank:
 * setting one overwrites every field it names, so mix presets by applying two
 * and then setting the fields you care about.
 */
export type QualityPreset = 'low' | 'medium' | 'high' | 'ultra';
/** The march-side fields a preset sets, grouped as the reference groups them */
export interface CloudsPresetFields {
    multiScatteringOctaves: number;
    accurateSunSkyLight: boolean;
    accuratePhaseFunction: boolean;
    maxIterationCount: number;
    minStepSize: number;
    maxStepSize: number;
    maxRayDistance: number;
    perspectiveStepScale: number;
    minDensity: number;
    minExtinction: number;
    minTransmittance: number;
    maxIterationCountToGround: number;
    maxIterationCountToSun: number;
    minSecondaryStepSize: number;
    secondaryStepScale: number;
    maxShadowFilterRadius: number;
    maxShadowLengthIterationCount: number;
    minShadowLengthStepSize: number;
    maxShadowLengthRayDistance: number;
    hazeDensityScale: number;
    hazeExponent: number;
    hazeScatteringCoefficient: number;
    hazeAbsorptionCoefficient: number;
}
/** The shadow-map fields a preset sets */
export interface ShadowPresetFields {
    cascadeCount: number;
    mapSize: Vector2;
    maxFar: number | null;
    farScale: number;
    splitMode: number;
    splitLambda: number;
    temporalPass: boolean;
    temporalJitter: boolean;
    maxIterationCount: number;
    minStepSize: number;
    maxStepSize: number;
    minDensity: number;
    minExtinction: number;
    minTransmittance: number;
    opticalDepthTailScale: number;
    updateInterval: number;
}
/**
 * What a preset needs to write into, which `CloudsContext` implements. A plain
 * object with these members works too.
 */
export interface QualityPresetTarget {
    resolutionScale: number;
    lightShafts: boolean;
    shapeDetail: boolean;
    turbulence: boolean;
    haze: boolean;
    clouds: CloudsPresetFields;
    shadow: ShadowPresetFields;
}
export declare function getAppliedQualityPreset(target: QualityPresetTarget): QualityPreset | undefined;
/** One complete set of preset values */
export interface QualityPresetValues {
    resolutionScale: number;
    lightShafts: boolean;
    shapeDetail: boolean;
    turbulence: boolean;
    haze: boolean;
    clouds: CloudsPresetFields;
    shadow: ShadowPresetFields;
}
/**
 * The four key lists partition `CloudsContext.clouds` and
 * `CloudsContext.shadow` by which uniform block each field reaches, which is
 * what decides whether a change is a plain uniform write or a graph rebuild.
 * They are exported so a caller can drive a preset field it does not know by
 * name, and the parity harness enumerates the same partition.
 */
/** `clouds` fields that are march uniforms, rewritten every frame */
export declare const cloudsUniformKeys: readonly ["maxIterationCount", "minStepSize", "maxStepSize", "maxRayDistance", "perspectiveStepScale", "minDensity", "minExtinction", "minTransmittance", "maxIterationCountToSun", "maxIterationCountToGround", "minSecondaryStepSize", "secondaryStepScale", "maxShadowFilterRadius", "maxShadowLengthIterationCount", "minShadowLengthStepSize", "maxShadowLengthRayDistance", "hazeDensityScale", "hazeExponent", "hazeScatteringCoefficient", "hazeAbsorptionCoefficient"];
/**
 * `clouds` fields that are compile-time material parameters, so a change
 * rebuilds the graph
 */
export declare const cloudsMaterialParameterKeys: readonly ["multiScatteringOctaves", "accurateSunSkyLight", "accuratePhaseFunction"];
/** `shadow` fields that are per-frame shadow-march uniforms */
export declare const shadowUniformKeys: readonly ["maxIterationCount", "minStepSize", "maxStepSize", "minDensity", "minExtinction", "minTransmittance", "opticalDepthTailScale"];
/** `shadow` field that is a compile-time material parameter */
export declare const shadowMaterialParameterKeys: readonly ["temporalJitter"];
/** `shadow` field that configures the resolve pass rather than the march */
export declare const shadowPassParameterKeys: readonly ["temporalPass"];
/** `shadow` fields owned by the cascaded shadow maps rather than the pass */
export declare const shadowMapsParameterKeys: readonly ["cascadeCount", "mapSize", "maxFar", "farScale", "splitMode", "splitLambda"];
/**
 * The values `high` is. Every `CloudsContext` starts from these, and a
 * preset spreads them, so this object is the single place a default is written.
 */
export declare const defaults: QualityPresetValues;
/**
 * Every bundled preset. `high` is {@link defaults} itself, so the object is
 * shared and must not be mutated by a caller.
 *
 * Use {@link applyQualityPreset}, or set `CloudsContext.qualityPreset`, rather
 * than assigning a preset onto the context: the graph-shape fields
 * (`multiScatteringOctaves`, `accurateSunSkyLight`, `accuratePhaseFunction`)
 * use forwarding setters on `CloudsContext.clouds` to bump `graphVersion`.
 */
export declare const qualityPresets: Record<QualityPreset, QualityPresetValues>;
/**
 * Write every field of one preset onto a target, in place. The top-level
 * props go to the target itself, `clouds` and `shadow` into its two shorthand
 * objects. Copies map dimensions into the target's own vector.
 *
 * On a `CloudsContext`, this also records the last applied preset. Later
 * overrides leave that name unchanged. An unknown name throws `RangeError`
 * listing the supported presets before any configuration changes.
 *
 * @remarks
 * Domain: the keys of qualityPresets, applied before local overrides
 * Mutation: uses context setters, changed graph fields invalidate history
 * Ownership: copies mapSize values without sharing the preset's mutable vector
 */
export declare function applyQualityPreset(target: QualityPresetTarget, name: QualityPreset): void;
