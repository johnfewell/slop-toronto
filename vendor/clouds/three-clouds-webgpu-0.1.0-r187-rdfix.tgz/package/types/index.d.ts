/**
 * The vanilla WebGPU surface. Start at {@link clouds}, configure
 * {@link CloudsContext}, composite through {@link CloudsPassNode.composite},
 * and read the outputs for shadow consumers.
 *
 * Three more entry points sit alongside this one. `three-clouds-webgpu/webgpu`
 * re-exports exactly these, the React bindings are at
 * `three-clouds-webgpu/r3f`, and the procedurally generated textures stand in
 * for the four baked assets when you do not ship them.
 *
 * The complete 1:1 mapping from the WebGL `CloudsEffect` is in
 * `docs/MIGRATION.md`, and the opt-in experiments are in
 * `docs/EXPERIMENTAL.md`.
 */
export { CameraUniforms } from './CameraUniforms.js';
export { createCloudsIntegration, type CloudsIntegration, type CloudsIntegrationOptions, type CloudsIntegrationTextures, type CloudsIntegrationUpdate } from './integration.js';
export { inspectCloudsSetup, type CloudSetupDiagnostic, type CloudsSetupInspection, type InspectCloudsSetupOptions } from './diagnostics.js';
export { CloudsContext, getCloudsContext, type DebugView } from './CloudsContext.js';
export { assertWebGPUSupported, CloudsPassNode, clouds, type CloudsOptions, type CloudShadowDescriptor } from './CloudsPassNode.js';
export { CloudLayer, type CloudLayerLike, type TextureChannel } from './CloudLayer.js';
export { CloudLayers } from './CloudLayers.js';
export { DensityProfile, type DensityProfileLike } from './DensityProfile.js';
export type { CloudShapeDeps, CloudShapeParams } from './experimental/cloudShape.js';
export { cloudShapeDefaults } from './experimental/cloudShape.js';
export type { ConvectiveProfileParams, ConvectiveUniforms } from './experimental/convectiveProfile.js';
export { CONVECTIVE_TOWER_MIN_HEIGHT, CONVECTIVE_TOWER_RAMP, convectiveProfileDefaults } from './experimental/convectiveProfile.js';
export type { CloudEnvironmentSettings } from './experimental/cloudEnvironment.js';
export { DEFAULT_WATER_PRO_CLOUD_SKY, WaterProCloudSky, type WaterProCloudSkyOptions, type WaterProSkyProvider } from './experimental/waterProSky.js';
export { experimentalDefaults } from './experimental/options.js';
export { FULL_MOON_IRRADIANCE_RATIO, illuminatedFractionCPU, moonlightCPU, twilightBlendCPU, TWILIGHT_SIN_ELEVATION, type MoonlightNodes } from './experimental/moonlight.js';
export { flashEnvelopeCPU, flashPositionCPU, flashScheduleDefaults, lightningParamsDefault } from './experimental/lightning.js';
export type { FlashSample, FlashScheduleOptions, LightningParams, LightningState } from './experimental/lightning.js';
export type { EvolvingWeatherParams } from './experimental/evolvingWeather.js';
export { evolvingWeatherDefaults } from './experimental/evolvingWeather.js';
export type { RainShaftParams, RainShaftUniforms } from './experimental/rainShafts.js';
export { rainShaftDefaults } from './experimental/rainShafts.js';
export type { CirrusDeckParams } from './experimental/cirrusDeck.js';
export { cirrusDeckDefaults } from './experimental/cirrusDeck.js';
export { createCirrusStreaksTexture, generateCirrusStreaks } from './experimental/cirrusStreaks.js';
export type { ExperimentalCloudOptions } from './experimental/options.js';
export { applyCloudTypePreset, cloudTypePresetNames, cloudTypePresets, cloudTypeProfileAt, isCloudTypePresetName, type CloudTypeLayers, type CloudTypePreset, type CloudTypePresetName, type CloudTypePresetTarget } from './experimental/cloudTypePresets.js';
export { applyPortDefaults, applyReferenceMode, PORT_DEFAULT_LIGHT_SHAFTS_HALF_RESOLUTION, REFERENCE_MODE, REFERENCE_MODE_PORT_ONLY_PATHS, REFERENCE_SHADOW_UPDATE_INTERVAL, referenceModePins, type ReferenceModePins } from './referenceMode.js';
export { createLayerUniforms, updateLayerUniforms, type LayerUniforms } from './layerUniforms.js';
export { applyQualityPreset, cloudsMaterialParameterKeys, cloudsUniformKeys, defaults, qualityPresets, shadowMapsParameterKeys, shadowMaterialParameterKeys, shadowPassParameterKeys, shadowUniformKeys, type CloudsPresetFields, type QualityPreset, type QualityPresetTarget, type QualityPresetValues, type ShadowPresetFields } from './qualityPresets.js';
export { CLOUD_SHAPE_DETAIL_TEXTURE_SIZE, CLOUD_SHAPE_TEXTURE_SIZE, DEFAULT_LOCAL_WEATHER_URL, DEFAULT_SHAPE_DETAIL_URL, DEFAULT_SHAPE_URL, DEFAULT_TURBULENCE_URL } from './constants.js';
export { cloudShadowAtlasResolution, createCloudShadowNode, cpuCloudShadowTransmittance, type CloudShadowAtOptions, type CloudShadowNodeDeps, type CloudShadowNodeOptions } from './shadow/cloudShadowNode.js';
export { createSampleCloudShadowOpticalDepth, createCloudShadowTransmittance, type GroundShadowExtraDeps } from './shadow/sampleCloudShadowOpticalDepth.js';
export { createGetShadowRadius, DEFAULT_SHADOW_RADIUS, shadowRadiusFromFootprintCPU, type ShadowRadiusDeps } from './shadow/shadowRadius.js';
export { getSTBN } from './march/jitter.js';
export { CloudShadowedAtmosphereLightNode } from './shadow/CloudShadowedAtmosphereLightNode.js';
export { CloudShadowedAerialPerspectiveNode } from './shadow/CloudShadowedAerialPerspectiveNode.js';
export { aerialPerspectiveWithCloudShadow } from './shadow/aerialShadowAdapter.js';
export { createHashJitterTexture, createJitterTexture, CloudTextureLoadError, loadBakedCloudTextures, type BakedCloudTextures, type BakedCloudTextureUrls, type CloudTextureAsset, type LoadBakedCloudTexturesOptions } from './textures/loadBakedCloudTextures.js';
export { CloudShape, CloudShapeDetail, LocalWeather, Turbulence, LOCAL_WEATHER_SIZE, TURBULENCE_SIZE } from './textures/generators.js';
export { Procedural3DTexture, ProceduralTexture2D, type ProceduralTextureLike } from './textures/ProceduralTexture.js';
export { blendCloudTypeParameter, CLOUD_TYPE_PARAMS, CLOUD_TYPE_TENT_SCOPES, cloudTypeAnchors, cloudTypeArchetypes, cloudTypeTentNames, cloudTypeTentWeights, CloudTypes, cpuBlendCloudTypeParameter, cpuCloudTypeTentWeights, createCloudTypeMap, type CloudTypeAnchor, type CloudTypeAnchorDeltas, type CloudTypeArchetype, type CloudTypeBlendNodes, type CloudTypeDeltas, type CloudTypeParam, type CloudTypeTentScope } from './experimental/cloudTypeMap.js';
export { createProceduralWeather, ProceduralWeather, type ProceduralWeatherParameters, type ProceduralWeatherGenerator, type WeatherChannel, type WeatherChannelNodes, type WeatherChannelParameters, type WeatherPattern } from './experimental/proceduralWeather.js';
export { celestialVector, computeCelestialDirections, resolveTimeOfDay, syncCelestialDirections, type CelestialDirections, type CelestialSink, type CelestialVector, type TimeOfDayLocation, type TimeOfDayRequest } from './experimental/timeOfDay.js';
export { applyScenePreset, isScenePresetName, scenePresetNames, scenePresets, type AppliedScenePreset, type ScenePreset, type ScenePresetName, type ScenePresetRequest, type ScenePresetTarget } from './experimental/scenePresets.js';
