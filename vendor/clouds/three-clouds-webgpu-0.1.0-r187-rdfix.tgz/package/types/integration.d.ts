import { Data3DTexture, Matrix4, PerspectiveCamera, Vector3 } from 'three';
import { PassNode, WebGPURenderer } from 'three/webgpu';
import { AerialPerspectiveNode, AtmosphereContext } from '@takram/three-atmosphere/webgpu';
import { CloudsContext } from './CloudsContext.js';
import { CloudsPassNode } from './CloudsPassNode.js';
import { CloudsSetupInspection } from './diagnostics.js';
import { CloudsCompositeNode } from './pass/compositeNodes.js';
/** Borrowed resources, including procedural generators, never disposed here */
export type CloudsIntegrationTextures = Pick<CloudsContext, 'localWeatherTexture' | 'shapeTexture' | 'shapeDetailTexture' | 'turbulenceTexture'> & {
    stbnTexture?: Data3DTexture | null;
};
/** Explicit composition inputs, with no renderer or scene policy defaults */
export interface CloudsIntegrationOptions {
    renderer: WebGPURenderer;
    /** Perspective camera only, mutate in place or rebuild to replace it */
    camera: PerspectiveCamera;
    atmosphere: AtmosphereContext;
    /** Fixed depth-node identity, with output and view-normal MRT for post mode */
    scenePass: PassNode;
    lighting: 'post' | 'lights';
    textures: CloudsIntegrationTextures;
    cloudsPass?: CloudsPassNode;
    /** Required for a new pass, otherwise defaults to the borrowed context */
    sunDirection?: Vector3;
    /** Copied into the context, identity means world positions are ECEF metres */
    worldToECEFMatrix?: Matrix4;
}
/** Caller-owned seconds and sample index, with optional authoritative inputs */
export interface CloudsIntegrationUpdate {
    time: number;
    frame: number;
    sunDirection?: Vector3;
    moonDirection?: Vector3;
    worldToECEFMatrix?: Matrix4;
}
/** A composition lease, not a renderer, clock or asset owner */
export interface CloudsIntegration {
    readonly pass: CloudsPassNode;
    readonly context: CloudsContext;
    readonly aerial: AerialPerspectiveNode;
    /** Assign to the caller's pipeline, stop rendering it before disposal */
    readonly output: CloudsCompositeNode;
    /** Inspect current CPU inputs, never infer graph compilation or frame completion */
    diagnostics(): CloudsSetupInspection;
    /** Call before rendering, sync context-owned sun/world/moon to the atmosphere */
    update(inputs: CloudsIntegrationUpdate): void;
    /** Explicit temporal reset for seeks, camera jumps and other discontinuities */
    resetHistory(): void;
    /** Release owned composition/pass resources, never borrowed inputs */
    dispose(): void;
}
/**
 * Compose an initialized renderer's scene, atmosphere and clouds
 * Borrows renderer, camera, atmosphere, scene pass and supplied textures
 * Owns its composition and optional new pass, never disposes a supplied pass
 * Camera/depth identities stay fixed, their transforms and context values stay live
 * Call update with your own time/frame before rendering, then dispose on teardown
 */
export declare function createCloudsIntegration(options: CloudsIntegrationOptions): CloudsIntegration;
