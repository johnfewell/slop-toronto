import { Data3DTexture, MagnificationTextureFilter, Texture } from 'three';
/**
 * The four baked textures a {@link CloudsContext} marches against
 * Ownership transfers to the caller after a successful load, without jitter
 */
export interface BakedCloudTextures {
    localWeatherTexture: Texture;
    turbulenceTexture: Texture;
    shapeTexture: Data3DTexture;
    shapeDetailTexture: Data3DTexture;
}
/**
 * Where to fetch each of the four. The shapes are raw 3D payloads sized by
 * {@link CLOUD_SHAPE_TEXTURE_SIZE} and {@link CLOUD_SHAPE_DETAIL_TEXTURE_SIZE}
 * rather than images, so they cannot go through a `TextureLoader`.
 *
 * The defaults for all four are exported from the package root.
 */
export interface BakedCloudTextureUrls {
    localWeather: string;
    turbulence: string;
    shape: string;
    shapeDetail: string;
}
/** Optional cancellation while the loader still owns its pending resources */
export interface LoadBakedCloudTexturesOptions {
    /** Abort pending loads, not textures already returned to the caller */
    signal?: AbortSignal;
}
/** Logical asset identity, independent of its URL or transport */
export type CloudTextureAsset = keyof BakedCloudTextureUrls | 'stbn';
interface TextureLoadDetails {
    asset: CloudTextureAsset;
    url: string;
    status?: number;
    expectedBytes?: number;
    actualBytes?: number;
}
/**
 * Identifies a failed asset without requiring callers to parse its message
 * Cancellation instead rejects with a DOMException named AbortError
 */
export declare class CloudTextureLoadError extends Error {
    /** The failed logical asset, even when several assets share a URL */
    readonly asset: CloudTextureAsset;
    /** The caller-supplied URL, not a resolved cache key */
    readonly url: string;
    /** HTTP status when a volume response was received, absent for images */
    readonly status?: number;
    /** Required raw volume byte count when a payload-size mismatch was found */
    readonly expectedBytes?: number;
    /** Received raw volume byte count when a payload-size mismatch was found */
    readonly actualBytes?: number;
    constructor(details: TextureLoadDetails, message: string, cause?: unknown);
}
export declare function loadCloudTexture(asset: CloudTextureAsset, url: string, { signal }?: LoadBakedCloudTexturesOptions): Promise<Texture>;
export declare function loadCloudVolume(asset: CloudTextureAsset, url: string, dimensions: readonly [number, number, number], filter?: MagnificationTextureFilter, { signal }?: LoadBakedCloudTexturesOptions): Promise<Data3DTexture>;
/**
 * Load the four baked assets the original ships, with the same filters and
 * wrapping it applies. Assign the result to the matching context properties:
 *
 * ```ts
 * const cloudsContext = cloudsPass.cloudsContext
 * const baked = await loadBakedCloudTextures({
 *   localWeather: DEFAULT_LOCAL_WEATHER_URL,
 *   turbulence: DEFAULT_TURBULENCE_URL,
 *   shape: DEFAULT_SHAPE_URL,
 *   shapeDetail: DEFAULT_SHAPE_DETAIL_URL
 * })
 * cloudsContext.localWeatherTexture = baked.localWeatherTexture
 * cloudsContext.shapeTexture = baked.shapeTexture
 * cloudsContext.shapeDetailTexture = baked.shapeDetailTexture
 * cloudsContext.turbulenceTexture = baked.turbulenceTexture
 * ```
 *
 * The 3D loads use `fetch`, so a cross-origin file:// page needs the assets
 * served over http. Success transfers all four textures to the caller.
 * Failure or abort disposes all loader-owned textures, including late images.
 * Abort cancels fetches, not image transport, and has no effect after success.
 *
 * @remarks
 * Requires: all four URLs, with successful HTTP responses and exact volume sizes
 * Readiness: resolved textures are CPU-loaded, not proof of a rendered frame
 * Ownership: dispose returned textures once, or transfer them to one owner
 * Failure: CloudTextureLoadError identifies the asset, AbortError is cancellation
 */
export declare function loadBakedCloudTextures(urls: BakedCloudTextureUrls, { signal }?: LoadBakedCloudTexturesOptions): Promise<BakedCloudTextures>;
/**
 * The white-noise hash volume the jitter defaulted to before blue noise. It is
 * still exported because the parity harness samples it, and its bytes are part
 * of the ladder's committed evidence, so replacing the default with it would
 * move every captured metric.
 */
export declare function createHashJitterTexture(): Data3DTexture;
/**
 * The 128x128x64 blue-noise jitter volume the context uses when you do not
 * assign one, built offline by `scripts/generate-blue-noise.mjs` and embedded
 * as a rank map. Slice k is that map shifted by k times the golden ratio
 * conjugate, so consecutive slices decorrelate. Generated per call and cached
 * by {@link CloudsContext.stbnTexture}.
 *
 * To sample NVIDIA's STBN exactly as the original does instead, load it from
 * upstream and assign it (see ADR-009).
 */
export declare function createJitterTexture(): Data3DTexture;
export {};
