import { Vector2, Camera, DataArrayTexture } from 'three';
import { TempNode, Node, NodeBuilder, NodeFrame, RenderTarget, TextureNode, UniformNode } from 'three/webgpu';
import { AerialPerspectiveNode } from '@takram/three-atmosphere/webgpu';
import { CloudsContext } from './CloudsContext.js';
import { CloudEnvironmentNode } from './experimental/cloudEnvironment.js';
import { EvolvingWeather } from './experimental/evolvingWeather.js';
import { StaticModeTracker } from './experimental/staticMode.js';
import { CloudsCompositeNode, CloudsTextureNode } from './pass/compositeNodes.js';
import { hashGraphFlags, supportsQuadOperations } from './pass/graphKey.js';
import { shadowTemporalAlpha } from './pass/shadowUniforms.js';
import { CloudShadowAtOptions } from './shadow/cloudShadowNode.js';
export { hashGraphFlags, shadowTemporalAlpha, supportsQuadOperations };
/**
 * The only argument {@link clouds} takes. Every knob lives on
 * `cloudsPass.cloudsContext` instead. A null depth node disables scene
 * occlusion, and replacing the node rebuilds the graph
 */
export interface CloudsOptions {
    /**
     * The scene's depth texture node, which the march uses to stop at solid
     * geometry. `null` is valid but disables scene occlusion, so clouds may
     * appear in front of terrain that should hide them
     */
    sceneDepth: TextureNode | null;
}
/**
 * The surface `uniformArray()` exposes to a shader. three does not export a
 * `UniformArrayNode` type from its .d.ts, so the seam is declared structurally:
 * indexing is all the cascade code does with these.
 */
export interface UniformArrayLike<T extends string> {
    element: (index: Node<'int'> | number) => Node<T>;
    /** The backing JS array the CPU side writes each frame */
    readonly array: unknown[];
}
export interface CloudShadowDescriptor {
    /**
     * The atlas the CPU side points at each update. Read this for identity
     * checks; shaders must bind {@link CloudShadowDescriptor.mapNode} instead.
     */
    map: DataArrayTexture;
    /**
     * The atlas as the shader sees it. `map` is reassigned every update
     * (ShadowPass.ts:164-171: history when temporalPass, raw otherwise), and a
     * shader that captured the raw `Texture` would keep the 1x1 placeholder.
     *
     * A TextureNode whose `.value` follows the swap. A captured Texture made the
     * shafts and the BSM hook read zeros from a full atlas
     */
    mapNode: TextureNode;
    /** The atlas's resolution in texels, shared with `ctx.shadow.mapSize` */
    readonly mapSize: Vector2;
    /**
     * Follows `ctx.shadow.cascadeCount`. NOT readonly and NOT fixed at mint: the
     * descriptor object outlives any cascade-count change, because consumers hold
     * its nodes
     */
    cascadeCount: number;
    /**
     * The same count as a node, so consumers can guard the cascade loop at RUNTIME
     * instead of unrolling `cascadeCount` when they build. A consumer built once
     * (every external one, `createCloudShadowTransmittance` in particular) is
     * otherwise frozen at whatever count was current then
     */
    readonly cascadeCountNode: UniformNode<'int', number>;
    /** Each cascade's near and far distance, for depth-range selection */
    readonly intervals: UniformArrayLike<'vec2'>;
    /** Each cascade's light view-projection matrix */
    readonly matrices: UniformArrayLike<'mat4'>;
    /** Each cascade's inverse of {@link matrices} */
    readonly inverseMatrices: UniformArrayLike<'mat4'>;
    /** The far plane of the cascade set */
    readonly far: UniformNode<'float', number>;
    /** Height of the top of the shadow-mapped volume, in metres */
    readonly topHeight: UniformNode<'float', number>;
    /** One over the atlas resolution, for converting between the two */
    readonly texelSize: UniformNode<'vec2', Vector2>;
}
/**
 * Refuses an uninitialized, unknown or non-native WebGPU backend from the
 * caller's own stack
 *
 * Call this once after `await renderer.init()` and before constructing the
 * pass:
 *
 * ```ts
 * const renderer = new WebGPURenderer({ forceWebGL: true })
 * await renderer.init()
 * assertWebGPUSupported(renderer) // throws here, where you can catch it
 * ```
 *
 * WHY THIS EXISTS SEPARATELY FROM THE setup() CHECK. CloudsPassNode.setup()
 * also throws on a WebGL backend, and that throw CANNOT refuse construction:
 * setup() runs inside three's node-build try/catch, which catches the error,
 * re-emits it as a `THREE.TSL: Error: ...` console message, and finishes the
 * build without the pass. Measured on a WebGL2 run:
 * the message appears as a console error with a ContextNode.setup stack, the
 * page produces ZERO pageerror events, the renderer reports itself as booted,
 * and the observable result is a silently black frame. A caller relying on the
 * documented "setup() throws" got a black render instead of an exception.
 *
 * Call only after initialization, when `renderer.initialized` is true. A
 * backend object can exist before `init()` and does not establish readiness
 */
export declare function assertWebGPUSupported(renderer: unknown): void;
/**
 * The cloud pass owns its march and resolve targets. The scene MRT contains
 * scene color and normals, not the cloud outputs:
 *
 * ```ts
 * scenePass.setMRT(mrt({ output, normal: normalView }))
 * const cloudsPass = clouds({ sceneDepth: scenePass.getTextureNode('depth') })
 * cloudsPass.camera = camera
 * pipeline.outputNode = cloudsPass.composite(aerial)
 * ```
 *
 * The graph order is scene MRT, cloud march, aerial perspective with sky,
 * then cloud composite. WEBGPU.md shows the complete context and aerial
 * wiring. The output nodes exist before the first build and stay live
 *
 * @remarks
 * Requires: initialized native WebGPU, scene camera, cloud and atmosphere providers
 * Mutation: replacing camera or depth rebuilds the graph and resets history
 * Ownership: dispose() releases pass resources, not assigned context textures
 * The renderer, scene, camera and atmosphere remain caller-owned
 */
export declare class CloudsPassNode extends TempNode {
    static get type(): string;
    /** Every knob. This is the object an application configures */
    readonly cloudsContext: CloudsContext;
    /**
     * The sky plus a low-resolution cloud march, as a cube map node. Assign it to
     * `scene.environmentNode` (or sample it) to have reflections carry clouds.
     * Reads back null until `experimental.cloudEnvironment` is on and the graph
     * has been built.
     */
    readonly environment: CloudEnvironmentNode;
    /**
     * The march render target, shared with the pass. Treat it as read-only: its
     * attachment count follows `lightShafts`, so it is reallocated when that
     * changes.
     */
    layerRT: RenderTarget;
    /** The shaded cloud colour the composite reads */
    readonly layerNode: CloudsTextureNode;
    /**
     * The march's second attachment: front distance times `worldToUnit` in `.x`
     * and UV velocity in `.yz`. Divide distance by the cloud scale to recover
     * metres, not by the atmosphere's kilometre scale
     */
    readonly depthVelocityNode: CloudsTextureNode;
    private _lastLayerLightShafts;
    private _sceneDepth;
    private _camera;
    private _inputVersion;
    private _assetsReady;
    private lastBuiltInputVersion;
    /** @internal Input revision for composition invalidation */
    get inputVersion(): number;
    /** @internal Asset readiness never overwrites the caller's enabled intent */
    setAssetsReady(ready: boolean): void;
    /** @internal Effective rendering state for the pass and its consumers */
    get renderingEnabled(): boolean;
    /** The scene depth this pass marches against. Same option as the factory */
    get sceneDepth(): TextureNode | null;
    set sceneDepth(value: TextureNode | null);
    private readonly material;
    private readonly mesh;
    private rendererState?;
    private lastBuiltVersion;
    private preparedShadowFrame;
    private preparedShadowTime;
    private preparedShadowVersion;
    private preparedShadowCamera;
    private readonly preparedShadowWorld;
    private readonly preparedShadowProjection;
    private readonly preparedShadowSize;
    private _historyInvalid;
    private readonly _windHistory;
    private readonly _staticTracker;
    private _convectiveUniforms;
    private _rainShaftUniforms;
    private _cirrusDeckUniforms;
    private _cirrusStreaks;
    private _lightningUniforms;
    readonly weatherEvolution: EvolvingWeather;
    private _computeResolve;
    private _resolveUsesCompute;
    private _shadowResolveUsesCompute;
    private _computeShadowResolve;
    private _computeShadowDeps;
    private _lastResolveW;
    private _lastResolveH;
    private _lastSeenFrame;
    private _staleFrameCount;
    private _warnedStaleFrame;
    private readonly _warnedExperimental;
    /**
     * The scene camera, which drives the ray directions, the shadow cascades and
     * the altitude correction. Set it before the first render: left null the pass
     * uses a default perspective camera, which is wrong for any other projection.
     */
    get camera(): Camera | null;
    set camera(value: Camera | null);
    private _marchUniforms;
    private _layerUniforms;
    private _parameterUniforms;
    private readonly shadowMaterial;
    private readonly shadowMesh;
    private shadowRT;
    private _shadowUniforms;
    private _cloudShadow;
    private _litShadowAtlas;
    private readonly _shadowFromECEF;
    private readonly _viewZFromECEF;
    private readonly _ecefToWorldCorrected;
    private readonly _altitudeTranslation;
    private readonly _viewFromECEF;
    private _cloudShadowLength;
    private readonly _cloudShadowAtFns;
    private readonly shadowResolveMaterial;
    private readonly shadowResolveMesh;
    private shadowResolveRT;
    private shadowHistoryRT;
    private _shadowResolveHistoryTexNode;
    private _shadowOdTexNode;
    private _shadowVelocityTexNode;
    private _shadowVarianceGamma;
    private _shadowTemporalAlpha;
    private _shadowFramesSinceUpdate;
    private _shadowHistoryInvalid;
    private _prevShadowMatrices;
    private _shadowGraphTemporal;
    private readonly _shadowRoundRobin;
    private readonly _shadowLayerBox;
    private readonly _shadowLayerOrigin;
    get cloudShadow(): CloudShadowDescriptor;
    get cloudShadowLength(): Node<'vec2'>;
    /**
     * Cloud shadow at a world position, as the sun transmittance in 0..1: 1 is
     * fully lit, 0 is fully shadowed. Multiply a material's sun-facing term by it
     * and water, vegetation, particles and custom lit surfaces take the shadow
     * the aerial perspective already puts on the ground below them.
     *
     * ```ts
     * material.colorNode = albedo.mul(pass.cloudShadowAt(positionWorld))
     * ```
     *
     * Nothing is built until this is called, so an unused call site cannot change
     * a pixel. The sample is the ground consumer's own transmittance, cascade
     * selection and all. The radius defaults to {@link DEFAULT_SHADOW_RADIUS},
     * not the per-pixel adaptive radius the aerial consumer computes, which
     * `options.radius` takes.
     */
    cloudShadowAt(worldPosition: Node<'vec3'>, options?: CloudShadowAtOptions): Node<'float'>;
    private cloudShadowTransmittanceFn;
    /**
     * The resolve and history targets, swapped each frame. `historyRT` holds the
     * image the composite reads. Both are null until the first resolve, so read
     * {@link outputTextureNode} instead of reaching in here.
     */
    resolveRT: RenderTarget | null;
    historyRT: RenderTarget | null;
    private _outputTexNode;
    private readonly resolveMaterial;
    private readonly resolveMesh;
    private _resolveWidth;
    private _resolveHeight;
    private _varianceGamma;
    private _temporalAlpha;
    /**
     * The resolved cloud image, as the composite sees it: the history texture
     * after a resolve, the raw march otherwise. One node whose value follows the
     * history swap, so a consumer built early keeps reading the live image.
     */
    get outputTextureNode(): TextureNode;
    private _historyTexNode;
    private _shadowLengthHistoryTexNode;
    private readonly shadowLengthPlaceholder;
    private _resolveLightShafts;
    constructor(options: CloudsOptions);
    customCacheKey(): number;
    private graphNeedsRebuild;
    updateBefore(frame: NodeFrame): boolean | undefined;
    /**
     * Prepare the current sample's shadow atlas before forward-lit scene captures.
     * Set time/frame/camera first and hold those inputs through the main render.
     * This does not march clouds or advance their colour history, and the following
     * updateBefore reuses the atlas. resetHistory invalidates that reuse.
     */
    prepareShadow(renderer: NonNullable<NodeFrame['renderer']>, camera?: Camera | null): void;
    private shadowPrepared;
    private rememberShadow;
    private isStaticFrame;
    private skipStaticFrame;
    private handleEarlyShadow;
    private renderMarchAndResolve;
    private renderFrame;
    private frameDimensions;
    private syncFrameUniforms;
    private lightningUniforms;
    private updateWindHistory;
    private assertWebGPUBackend;
    setup(builder: NodeBuilder): Node | null | undefined;
    private buildGraph;
    private marchGraphHost;
    private buildCloudEnvironment;
    private shadowGraphHost;
    private buildShadowGraph;
    private convectiveDeps;
    private cloudShapeDeps;
    private rainShaftDeps;
    private cirrusDeckUniforms;
    private ensureLayerRT;
    private updateParameterUniformsForFrame;
    private buildShadowResolveGraph;
    private isShadowUpdateDue;
    private fitShadowMapsIfDue;
    private shadowPassForFrame;
    private refreshShadowComposition;
    private renderShadowPass;
    private planShadowRoundRobin;
    private renderShadowResolve;
    private showLitShadowAtlas;
    private updateCloudShadowDescriptor;
    private composeShadowFromECEF;
    private shadowTemporalBuilt;
    private ensureShadowRT;
    private ensureShadowResolveTargets;
    private updateShadowResolveBackend;
    private swapShadowBuffers;
    private copyShadowHistoryLayer;
    private storeShadowReprojection;
    private ensureResolveTargets;
    private buildResolveInputs;
    private buildComputeResolveGraph;
    private buildResolveGraph;
    private renderResolvePass;
    private reArmHistoriesForRebuild;
    private swapResolveBuffers;
    private buildShadowLengthNode;
    private _resetHistoryImpl;
    private checkStaleFrame;
    /**
     * Warn once per experimental option that is on but cannot do anything.
     *
     * These are documented limitations, not defects, so they are surfaced rather
     * than fixed: without this, an option reads as enabled and silently does
     * nothing (docs/EXPERIMENTAL.md). Gated on `warnings`, like the stale-frame
     * warning above, and warned once per id so a per-frame check cannot flood.
     */
    private checkExperimentalWarnings;
    private warnExperimentalOnce;
    private readonly compositeNodes;
    /** Whether the pass retains any undisposed composite destinations */
    get hasComposite(): boolean;
    /**
     * Build the node that mixes the resolved clouds into `dst`. The same
     * destination reuses its node until disposed, distinct destinations get
     * independent composites. Assign the result to the composer's output.
     *
     * `AerialPerspectiveNode` is accepted because ADR-001 wires the takram aerial
     * node into this call, and that class extends an untyped `TempNode`, so it is
     * assignable to NEITHER `Node<'vec4'>` nor `Node`: its `setup()` return is
     * incompatible with Three.js Node declarations. Every consumer had to cast
     * at the call site to pass the node the docs tell them to pass.
     *
     * Ownership: dispose a composite to release its destination, or dispose the pass
     */
    composite(dst: Node<'vec4'> | AerialPerspectiveNode): CloudsCompositeNode;
    /** Clear the temporal accumulation. Same as `cloudsContext.resetHistory()` */
    resetHistory(): void;
    get staticTracker(): StaticModeTracker;
    /**
     * Release pass-owned targets, materials and effects, not the context's textures
     * Ownership: dispose the context separately after detaching borrowed textures
     */
    dispose(): void;
}
/**
 * Create the cloud pass. The one factory of the package, so
 * `instanceof CloudsPassNode` holds for every cloud graph.
 *
 * ```ts
 * const cloudsPass = clouds({ sceneDepth })
 * cloudsPass.cloudsContext.time = elapsed
 * cloudsPass.cloudsContext.frame = frameIndex
 * ```
 *
 * Nothing is uploaded until the first render: the pass initializes itself, so
 * there is no `initialize()` to call and no size to pass.
 *
 * @remarks
 * Requires: register this pass's context with the renderer before rendering
 * Ownership: the caller must release the pass and its context separately
 */
export declare const clouds: (options: CloudsOptions) => CloudsPassNode;
