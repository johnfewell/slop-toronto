import { Vector3, Vector4 } from 'three';
import { CloudLayer, CloudLayerLike } from './CloudLayer.js';
import { DensityProfileLike } from './DensityProfile.js';
type NumericKey = keyof {
    [P in keyof CloudLayer as number extends CloudLayer[P] ? P : never]: unknown;
};
/** See {@link CloudLayers.structure} */
export interface LayerStructure {
    active: [boolean, boolean, boolean, boolean];
    weatherExponentOne: boolean;
    expTermZero: boolean;
}
/** The unspecialised shape: every lane live, both terms kept */
export declare const GENERIC_LAYER_STRUCTURE: LayerStructure;
/** A stable string for the cache key and the change poll */
export declare function layerStructureKey(s: LayerStructure): string;
/**
 * The four {@link CloudLayer} slots, as an array you index by position. The
 * count is fixed at four because the shader packs them into one `vec4` per
 * field, so a fifth layer would need a different graph.
 *
 * Which channel each layer reads is what makes them independent: the default
 * set takes `r`, `g`, `b` and `a` of the weather map.
 */
export declare class CloudLayers extends Array<CloudLayer> {
    /**
     * The three authored layers the original ships (two weather-driven bands and
     * one high cirrus) plus a fourth empty slot. Every `CloudsContext` starts
     * from a clone of this, so mutating it is safe.
     */
    static readonly DEFAULT: CloudLayers;
    /** Build the four slots, each patched over {@link CloudLayer}'s defaults */
    constructor(options?: readonly CloudLayerLike[]);
    /** Patch each slot from a partial-per-layer object */
    set(options?: readonly CloudLayerLike[]): this;
    /** Return every slot to {@link CloudLayer}'s own defaults */
    reset(): this;
    /** A new set with the same four layers, each copied */
    clone(): CloudLayers;
    copy(other: CloudLayers): this;
    /**
     * The four channels as one string such as `'rgba'`. Polled by
     * `CloudsContext.checkLocalWeatherChannels` because the swizzle is compiled
     * in, so changing a layer's channel rebuilds the march.
     */
    get localWeatherChannels(): string;
    /**
     * Whether ANY layer casts a cloud shadow.
     *
     * This exact predicate gates a graph-time variant (CloudsPassNode compiles
     * the Beer-shadow-map branch into shadeSample only when it holds), so it is
     * what CloudsContext.checkShadowStructure tracks
     *
     * Deliberately not per-layer: WHICH layers cast reaches the shader through the
     * packed `shadowLayerMask` uniform, so a change there needs no rebuild. Only
     * the existence of a caster changes the compiled shape.
     */
    get castsShadow(): boolean;
    /**
     * The graph-time shape of the layer set: which of the four lanes
     * hold a layer, and whether two terms of the per-layer maths are identities
     * on every active lane. CloudsPassNode compiles these facts into the march
     * as literals. The magnitudes stay uniforms, so only a change here rebuilds.
     *
     * - A lane with `height <= 0` is empty: its weather density is 0 for every
     *   height but the layer's own altitude, so it is compiled as a literal 0.
     * - `weatherExponent === 1` on every active lane drops `pow(weather, e)`.
     * - `densityProfile.expTerm === 0` on every active lane drops
     *   `expTerm * exp(exponent * h)` from the density profile.
     */
    get structure(): LayerStructure;
    /**
     * Write one numeric field from all four layers into a `vec4`. This is how the
     * per-layer values reach the shader.
     */
    packValues<K extends NumericKey>(key: K, result: Vector4): Vector4;
    /**
     * Write `a + b` from all four layers into a `vec4`, for the band tops, which
     * are stored as an altitude plus a height
     */
    packSums<A extends NumericKey, B extends NumericKey>(a: A, b: B, result: Vector4): Vector4;
    /** One {@link DensityProfile} field from all four layers, into a `vec4` */
    packDensityProfiles<K extends keyof DensityProfileLike>(key: K, result: Vector4): Vector4;
    /**
     * The three height ranges the march steps through, from the eight band
     * endpoints sorted and interval-coded. Bands may overlap and be out of order;
     * this returns the merged ranges, at most three of them
     */
    packIntervalHeights(minIntervals: Vector3, maxIntervals: Vector3): void;
}
export {};
