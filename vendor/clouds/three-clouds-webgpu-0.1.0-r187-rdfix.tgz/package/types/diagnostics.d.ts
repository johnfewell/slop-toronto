import { AtmosphereContext } from '@takram/three-atmosphere/webgpu';
import { CloudsPassNode } from './CloudsPassNode.js';
/** One observable setup problem, with a stable code and input path */
export interface CloudSetupDiagnostic {
    /** Stable problem category for branching without parsing prose */
    code: 'backend.webgl' | 'backend.not-initialized' | 'backend.unknown' | 'provider.missing' | 'provider.threw' | 'provider.duplicate-clouds' | 'provider.clouds-mismatch' | 'provider.atmosphere-invalid' | 'provider.atmosphere-mismatch' | 'direction.invalid' | 'asset.missing' | 'asset.wrong-dimension' | 'asset.not-loaded' | 'layers.invalid-slots' | 'layers.invalid-channel' | 'camera.missing' | 'camera.atmosphere-mismatch' | 'depth.mode-invalid' | 'depth.missing' | `feature.${string}`;
    /** Errors invalidate configuration, warnings retain their separate remedies */
    severity: 'error' | 'warning';
    /** Input path to inspect or correct */
    path: string;
    /** Plain observed value, not a retained texture, renderer or context */
    observed: string | number | boolean | null | readonly number[];
    /** Human-readable explanation, not a stable machine identifier */
    message: string;
    /** Suggested correction, never applied by this inspection */
    remedy: string;
}
/** Existing objects to inspect, never a second configuration store */
export interface InspectCloudsSetupOptions {
    /** Inspect after renderer.init(), earlier calls report not-initialized */
    renderer: unknown;
    /** The actual pass whose context must match the renderer's provider */
    pass: CloudsPassNode;
    /** Optional expected identity in addition to inspecting the active provider */
    atmosphere?: AtmosphereContext;
    /** Scene mode requires depth, sky-only explicitly permits missing depth */
    depthMode: 'scene' | 'sky-only';
}
/** CPU observations only, not shader compilation or GPU completion evidence */
export interface CloudsSetupInspection {
    /** Observed errors and warnings, including experimental feature warnings */
    diagnostics: CloudSetupDiagnostic[];
    /** Assets describe CPU observations, graph and frame are always unobserved */
    readiness: {
        configuration: 'valid' | 'invalid';
        assets: 'ready' | 'not-ready';
        graph: 'unobserved';
        frame: 'unobserved';
    };
}
export declare function inspectCloudsBackend(renderer: unknown, requireInitialized?: boolean): CloudSetupDiagnostic | null;
/**
 * Inspect setup without loading textures, creating GPU resources or rendering
 *
 * @remarks
 * Requires: the actual pass and renderer, with an explicit depth policy
 * Mutation: none by the inspector, registered context providers are called
 * Readiness: graph and frame stay unobserved even when assets are ready
 * Ownership: all inputs are borrowed, no lazy jitter texture is allocated
 */
export declare function inspectCloudsSetup({ renderer, pass, atmosphere: expectedAtmosphere, depthMode }: InspectCloudsSetupOptions): CloudsSetupInspection;
