import { FC, ReactNode, Ref } from 'react';
import { Data3DTexture, Matrix4, Texture, Vector3 } from 'three';
import { Storage3DTexture, TextureNode } from 'three/webgpu';
import { CloudsContext, DebugView } from '../CloudsContext.js';
import { CloudsPassNode } from '../CloudsPassNode.js';
import { ExperimentalCloudOptions } from '../experimental/options.js';
import { QualityPreset } from '../qualityPresets.js';
import { ProceduralTextureLike } from '../textures/ProceduralTexture.js';
/** Mounted resources borrowed from the enclosing Clouds component */
export interface CloudsPassContextValue {
    /** Compose this pass, but do not dispose it independently of the component */
    pass: CloudsPassNode;
    /** Configuration state, with caller-driven time and frame values */
    context: CloudsContext;
    /** Asset lifecycle only, not shader compilation or visible-frame evidence */
    assets: CloudsAssetState;
}
/**
 * URL assets load before ready, objects and lazy default jitter are ready inputs
 * An error disables the pass until inputs change and all assets become ready
 * This does not validate borrowed textures or prove a GPU frame rendered
 */
export type CloudsAssetState = {
    status: 'loading' | 'ready';
    error: null;
} | {
    status: 'error';
    error: Error;
};
/** Advanced provider access, prefer useClouds inside the component tree */
export declare const CloudsPassContext: import('react').Context<CloudsPassContextValue | null>;
/**
 * Read the enclosing Clouds pass, context and loading/ready/error asset state
 * Requires: call inside a mounted Clouds descendant, otherwise it throws
 * Ownership: returned resources are borrowed and become invalid on unmount
 * The app still wires providers, atmosphere and its render pipeline
 */
export declare function useClouds(): CloudsPassContextValue;
declare const SCALAR_KEYS: readonly ["coverage", "scatteringCoefficient", "absorptionCoefficient", "turbulenceDisplacement", "skyLightScale", "groundBounceScale", "powderScale", "powderExponent", "scatterAnisotropyMix", "resolutionScale", "sunAngularRadius", "bottomRadius", "correctAltitude", "cameraHeight", "time", "frame", "enabled", "warnings"];
type ScalarProps = Partial<Pick<CloudsContext, (typeof SCALAR_KEYS)[number]>>;
/**
 * Declarative context inputs, with the same units and graph effects as the context
 * A preset applies before explicit scalar overrides on each React render
 * Omitted scalar props preserve current values, time and frame never auto-advance
 */
export interface CloudsProps extends ScalarProps {
    /** The mounted pass, cleared on unmount, never independently disposed */
    ref?: Ref<CloudsPassNode>;
    /**
     * Required depth policy: a scene depth node, or explicit null for sky-only
     * Keep node identity stable between intentional replacements
     * Replacing node identity keeps the pass but rebuilds its graph and history
     */
    sceneDepth: TextureNode | null;
    /** Debug output selection, omitted preserves the current selection */
    debug?: DebugView;
    /** Default false, true leaves undeclared layer slots empty */
    disableDefaultLayers?: boolean;
    /** A validated partial patch, absent experiment keys keep their current values */
    experimental?: Partial<ExperimentalCloudOptions>;
    /** Reapplied before scalar props, so explicit resolutionScale wins */
    qualityPreset?: QualityPreset;
    /** Normalized ECEF direction copied into the context, no automatic sun clock */
    sunDirection?: Vector3;
    /** World metres to ECEF metres, copied rather than retaining this matrix */
    worldToECEFMatrix?: Matrix4;
    /** Borrow an object or load an owned URL texture, defaults to the baked URL */
    localWeatherTexture?: Texture | ProceduralTextureLike | string;
    /** Borrow a volume/generator or load its raw bytes, defaults to the baked URL */
    shapeTexture?: Data3DTexture | ProceduralTextureLike<Storage3DTexture> | string;
    /** Borrow a detail volume/generator or load bytes, defaults to the baked URL */
    shapeDetailTexture?: Data3DTexture | ProceduralTextureLike<Storage3DTexture> | string;
    /** Borrow an object or load an owned URL texture, defaults to the baked URL */
    turbulenceTexture?: Texture | ProceduralTextureLike | string;
    /** Borrow a volume or load a URL, omission generates owned jitter without fetch */
    stbnTexture?: Data3DTexture | string;
    /** CloudLayer declarations and consumers of useClouds */
    children?: ReactNode;
}
/**
 * Own a pass and asset-loading lifecycle, not a complete render pipeline
 * Requires: a Fiber canvas with native WebGPU, app-owned composition and providers
 * Ownership: URL textures are disposed on replacement or unmount
 * The owned pass, context and generated default jitter are disposed on unmount
 * Passed texture and generator objects remain borrowed and are never disposed
 * Loading or failed assets gate rendering without changing context.enabled
 */
export declare const Clouds: FC<CloudsProps>;
export {};
