import { FC, Ref } from 'react';
import { ExpandNestedProps } from '@takram/three-geospatial/r3f';
import { CloudLayer as CloudLayerImpl, CloudLayerLike } from '../CloudLayer.js';
/**
 * One declarative layer, rebuilt from its slot default and props on each render
 * Removed props return to that slot's default rather than keeping old values
 * Altitude and height are metres, as on the underlying CloudLayer
 * Nested densityProfile applies first, explicit dashed coefficients win
 */
export interface CloudLayerProps extends CloudLayerLike, ExpandNestedProps<CloudLayerLike, 'densityProfile'> {
    /** The current slot object, updated when explicit requests move an automatic layer */
    ref?: Ref<CloudLayerImpl>;
    /**
     * A unique slot from 0 through 3. Invalid or occupied slots throw.
     * Explicit requests take priority, including later mounts and index changes
     * Omit for a free slot, retained unless an explicit request moves it
     * A fifth layer throws
     */
    index?: 0 | 1 | 2 | 3;
}
/**
 * Declare one of four cloud slots inside Clouds or CloudLayers
 * Changing index releases the old slot, unmount restores its default and frees it
 * With disableDefaultLayers, released slots return to zero height instead
 */
export declare const CloudLayer: FC<CloudLayerProps>;
