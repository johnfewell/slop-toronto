import { FC, ReactNode } from 'react';
import { CloudLayers as CloudLayersImpl } from '../CloudLayers.js';
/** Advanced allocation state, normally managed through CloudLayer children */
export interface CloudLayersContextValue {
    /** The borrowed four-slot collection */
    layers: CloudLayersImpl;
    /** Unclaimed indices, maintained by child mounts and unmounts */
    indexPool: number[];
    /** Whether unclaimed slots reset to the empty standalone layer */
    disableDefault: boolean;
}
/** Advanced provider access, normally installed by Clouds */
export declare const CloudLayersContext: import('react').Context<CloudLayersContextValue | null>;
interface LayerAllocation {
    index: number | null;
}
export declare function useCloudLayerAllocation(context: CloudLayersContextValue, requested?: number): LayerAllocation;
/** Bind declarative children to an existing four-slot collection */
export interface CloudLayersProps {
    /** Borrowed collection, this component does not own GPU resources */
    layers: CloudLayersImpl;
    /** Default false, true resets unclaimed slots to zero-height CloudLayer.DEFAULT */
    disableDefault?: boolean;
    /** At most four simultaneously claimed CloudLayer slots */
    children?: ReactNode;
}
/**
 * Provide fixed-slot allocation for advanced composition with an existing context
 * Normal Clouds usage installs this provider automatically
 */
export declare const CloudLayers: FC<CloudLayersProps>;
export {};
