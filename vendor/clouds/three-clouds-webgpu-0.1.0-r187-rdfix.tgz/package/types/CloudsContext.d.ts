import { Matrix4, Texture, Vector2, Vector3, Camera, Data3DTexture } from 'three';
import { Renderer, Storage3DTexture } from 'three/webgpu';
import { Ellipsoid } from '@takram/three-geospatial';
import { CameraUniforms } from './CameraUniforms.js';
import { CloudLayers } from './CloudLayers.js';
import { CirrusDeckParams } from './experimental/cirrusDeck.js';
import { CloudShapeParams } from './experimental/cloudShape.js';
import { CloudTypes } from './experimental/cloudTypeMap.js';
import { ConvectiveProfileParams } from './experimental/convectiveProfile.js';
import { EvolvingWeatherParams } from './experimental/evolvingWeather.js';
import { LightningState } from './experimental/lightning.js';
import { ExperimentalCloudOptions } from './experimental/options.js';
import { ProceduralWeather } from './experimental/proceduralWeather.js';
import { RainShaftParams } from './experimental/rainShafts.js';
import { CloudsPresetFields, QualityPreset, QualityPresetTarget, ShadowPresetFields } from './qualityPresets.js';
import { CascadedShadowMaps } from './shadow/CascadedShadowMaps.js';
import { ProceduralTextureLike } from './textures/ProceduralTexture.js';
/**
 * Which diagnostic view the resolve pass writes, or `'none'` for the shaded
 * image. A change rebuilds the graph.
 */
export type DebugView = 'none' | 'cascades' | 'shadowMap' | 'uv' | 'sampleCount' | 'frontDepth' | 'shadowLength' | 'velocity' | 'marchIntervals';
/**
 * Every knob of the WebGL `CloudsEffect` under its original name, plus this
 * port's additions. One context belongs to one pass: read it as
 * `cloudsPass.cloudsContext`.
 *
 * Most properties are plain numbers you may assign per frame. Graph setters
 * ignore unchanged values, but reapplying a preset restores its overrides
 * A property whose documentation says it rebuilds the graph additionally bumps
 * `graphVersion` and clears temporal history, which is why the graph-shape
 * fields have real setters instead of being plain public fields.
 *
 * @remarks
 * Units: world distances are metres and time is seconds, not an internal clock
 * Requires: register this pass's context as the renderer's getClouds provider
 * Ownership: dispose() releases assigned textures, including borrowed ones
 * Detach borrowed slots before disposal and release the pass separately
 */
export declare class CloudsContext implements QualityPresetTarget {
    /** Creation order, for telling two contexts apart in a log */
    readonly id: number;
    /**
     * The camera uniforms the pass binds itself. Fullscreen passes never use the
     * TSL camera builtins, so the scene camera is bound here by
     * {@link updateCamera}.
     */
    readonly cameraUniforms: CameraUniforms;
    /**
     * The four cloud layers, as a fixed four-element array, with heights in
     * metres. Structural changes, such as activating an empty layer, rebuild the
     * graph through {@link checkLayerStructure}. Numeric magnitudes are uniforms
     */
    readonly cloudLayers: CloudLayers;
    /**
     * How often each texture tiles across the sky, per unit of its offset space.
     * Larger numbers mean finer detail. A change mid-flight is a domain change,
     * which is one of the things `windReprojection` rejects history for.
     */
    readonly localWeatherRepeat: Vector2;
    readonly shapeRepeat: Vector3;
    readonly shapeDetailRepeat: Vector3;
    readonly turbulenceRepeat: Vector2;
    /**
     * The base sampling offset of each texture. Combined with its velocity and
     * `time` into the `derived*` offsets, which is what the shader reads.
     */
    readonly localWeatherOffset: Vector2;
    readonly shapeOffset: Vector3;
    readonly shapeDetailOffset: Vector3;
    /**
     * Wind, in offset units per second. This is the advection the clouds move by,
     * so it is also what `windReprojection` reprojects against.
     */
    readonly localWeatherVelocity: Vector2;
    readonly shapeVelocity: Vector3;
    readonly shapeDetailVelocity: Vector3;
    /** What the shader reads: the base offset plus velocity times `time` */
    readonly derivedLocalWeatherOffset: Vector2;
    readonly derivedShapeOffset: Vector3;
    readonly derivedShapeDetailOffset: Vector3;
    private _localWeatherTexture;
    private _shapeTexture;
    private _shapeDetailTexture;
    private _turbulenceTexture;
    private _proceduralLocalWeather;
    private _proceduralShape;
    private _proceduralShapeDetail;
    private _proceduralTurbulence;
    /**
     * The local weather map, or the generator that draws it. The getter returns
     * whichever was set, so a procedural texture has to be driven each frame
     * through {@link renderProceduralTextures}. The `resolved*` getters are what
     * the uniforms bind.
     */
    get localWeatherTexture(): Texture | ProceduralTextureLike | null;
    set localWeatherTexture(value: Texture | ProceduralTextureLike | null);
    /**
     * The base 3D shape volume, or its generator. Same pairing as
     * {@link localWeatherTexture}.
     */
    get shapeTexture(): Data3DTexture | Storage3DTexture | ProceduralTextureLike<Storage3DTexture> | null;
    set shapeTexture(value: Data3DTexture | Storage3DTexture | ProceduralTextureLike<Storage3DTexture> | null);
    /**
     * The high-frequency 3D detail volume, or its generator. Only sampled when
     * {@link shapeDetail} is on.
     */
    get shapeDetailTexture(): Data3DTexture | Storage3DTexture | ProceduralTextureLike<Storage3DTexture> | null;
    set shapeDetailTexture(value: Data3DTexture | Storage3DTexture | ProceduralTextureLike<Storage3DTexture> | null);
    /**
     * The 2D curl noise the shape noise is displaced by, or its generator. Only
     * sampled when {@link turbulence} is on.
     */
    get turbulenceTexture(): Texture | ProceduralTextureLike | null;
    set turbulenceTexture(value: Texture | ProceduralTextureLike | null);
    /** The plain texture behind {@link localWeatherTexture}, generator or not */
    get resolvedLocalWeatherTexture(): Texture | null;
    /** The plain texture behind {@link shapeTexture}, generator or not */
    get resolvedShapeTexture(): Data3DTexture | Storage3DTexture | null;
    /** The plain texture behind {@link shapeDetailTexture}, generator or not */
    get resolvedShapeDetailTexture(): Data3DTexture | Storage3DTexture | null;
    /** The plain texture behind {@link turbulenceTexture}, generator or not */
    get resolvedTurbulenceTexture(): Texture | null;
    /**
     * Fill any procedural texture that still needs it. Each generator clears its
     * own needsRender, so calling this every frame is cheap, as the reference
     * does (CloudsEffect.ts:473-476). Returns whether any generator re-filled
     */
    renderProceduralTextures(renderer: Renderer): boolean;
    private _stbnTexture;
    private readonly generatedStbnTextures;
    /**
     * The spatial-temporal blue-noise volume the march jitters with, built on
     * first read. Assign your own to sample NVIDIA's STBN as the original does.
     */
    get stbnTexture(): Data3DTexture;
    /** The cached jitter volume, without triggering its lazy generation */
    get resolvedStbnTexture(): Data3DTexture | null;
    /** Assign `null` to fall back to the generated volume again */
    set stbnTexture(value: Data3DTexture | null);
    /**
     * How much of the weather map becomes cloud. 0 is clear sky, 1 overcast
     * Domain: normally [0, 1], assignment is not validated or clamped
     * Mutation: a per-frame uniform, with no graph rebuild
     */
    coverage: number;
    /** Scattering coefficient of the participating medium */
    scatteringCoefficient: number;
    /** Absorption coefficient of the participating medium */
    absorptionCoefficient: number;
    /** How far the turbulence noise displaces the shape noise, in metres */
    turbulenceDisplacement: number;
    /** Multiplier on the sky's contribution to cloud lighting */
    skyLightScale: number;
    /**
     * Multiplier on light bounced off the ground into cloud bases. 0 turns ground
     * bounce off, which also removes the ground march.
     */
    groundBounceScale: number;
    /** Strength of the powder darkening in dense, shadowed cloud */
    powderScale: number;
    /** Height falloff of that powder darkening */
    powderExponent: number;
    private _scatterAnisotropy1;
    get scatterAnisotropy1(): number;
    set scatterAnisotropy1(v: number);
    private _scatterAnisotropy2;
    get scatterAnisotropy2(): number;
    set scatterAnisotropy2(v: number);
    private _scatterAnisotropyMix;
    get scatterAnisotropyMix(): number;
    set scatterAnisotropyMix(v: number);
    /** March resolution as a fraction of the frame. Below 1 costs quality */
    resolutionScale: number;
    convectiveProfile: ConvectiveProfileParams;
    rainShafts: RainShaftParams;
    cirrusDeck: CirrusDeckParams;
    evolvingWeather: EvolvingWeatherParams;
    /**
     * The opt-in shape controls: a darker base, a horizon coverage bank, a wind
     * shear and one rounded-to-wispy edge knob. A plain field, like
     * {@link convectiveProfile}, because every magnitude is a graph-time literal
     * (src/experimental/cloudShape.ts). Neutral is all zeros, so an untouched
     * context reads as the reference.
     *
     * `checkCloudShape` polls it, which the pass calls each frame itself
     */
    cloudShape: CloudShapeParams;
    /**
     * The lightning flash lighting the cloud from inside, or `null` for none. A
     * plain field, not a setter: its parts feed uniforms written every frame, so a
     * flash costs no graph rebuild. Read it only when experimental.lightning is on.
     *
     * `position` is ECEF metres and belongs inside the cloud volume. `intensity`
     * is 0 whenever no flash is lit. Never reads a clock: the consumer decides
     * when a flash is, and when its envelope has decayed.
     */
    lightning: LightningState | null;
    private _experimental;
    /** Regional cloud-type controls, used when `experimental.cloudTypeMap` is on */
    readonly cloudTypes: CloudTypes;
    /**
     * Renderer experiments. `cloudFrontRefinement` and `distantShapeDetailFade`
     * default to true, all others to false. See docs/EXPERIMENTAL.md
     *
     * Assign a partial object to preserve other options. Unknown keys and
     * non-boolean values throw. Changes rebuild the graph and reset history
     */
    get experimental(): Readonly<ExperimentalCloudOptions>;
    set experimental(options: Partial<ExperimentalCloudOptions>);
    private _proceduralWeather;
    private syncProceduralWeather;
    /**
     * The generator the flag installed, or null. Read-only on purpose: the
     * pattern and octave counts are graph time, so changing them means building
     * your own and assigning it to `localWeatherTexture`
     */
    get proceduralWeather(): ProceduralWeather | null;
    private _lightShafts;
    /** Whether cloud shadow length is marched and read by the aerial consumers */
    get lightShafts(): boolean;
    set lightShafts(v: boolean);
    private _lightShaftsHalfResolution;
    /**
     * Whether the shaft march runs once per 2x2 quad rather than per fragment.
     * Needs the `subgroups` feature, on by default. Measured, not identical: dE P95
     * 0.056-0.071 (2-3x the inert floor, ~8% of the case's A-vs-B mean), not
     * visible at DPR 1, and 7.2-20.0 ms per frame at 1280x720 on the shaft cases.
     */
    get lightShaftsHalfResolution(): boolean;
    set lightShaftsHalfResolution(v: boolean);
    private _haze;
    /** Whether the haze layer is marched alongside the clouds */
    get haze(): boolean;
    set haze(v: boolean);
    private _temporalUpscale;
    /**
     * Whether the resolve runs at the march resolution and upscales (Bayer,
     * `true`) or at the frame resolution (full-resolution TAA, `false`). The
     * temporal accumulation runs either way. `true` is cheaper and softer,
     * `false` is sharper and costs more.
     */
    get temporalUpscale(): boolean;
    set temporalUpscale(v: boolean);
    private _shapeDetail;
    /**
     * Whether the high-frequency detail volume contributes at all. Off is
     * cheaper and smoother at distance, and every layer's `shapeDetailAmount`
     * stops mattering.
     */
    get shapeDetail(): boolean;
    set shapeDetail(v: boolean);
    private _turbulence;
    /** Whether the curl noise displaces the shape noise */
    get turbulence(): boolean;
    set turbulence(v: boolean);
    private _debug;
    /**
     * The diagnostic view the resolve writes, or `'none'` for the shaded image
     */
    get debug(): DebugView;
    set debug(v: DebugView);
    /**
     * The march-side preset fields. Writing here configures this instance;
     * material parameters use the same setters as their top-level counterparts.
     */
    readonly clouds: CloudsPresetFields;
    /** The shadow-side preset fields, flattened the same way */
    readonly shadow: ShadowPresetFields;
    /**
     * The cascaded shadow maps, created by the pass. A caller may replace or
     * dispose it, but {@link syncShadowMaps} writes the split settings back into
     * whatever is here every frame, so `shadow.*` stays the only place to set
     * them.
     */
    shadowMaps: CascadedShadowMaps | null;
    /** World space to ECEF. Set this once for your scene's coordinate frame */
    readonly worldToECEFMatrix: Matrix4;
    /** Inverse of {@link worldToECEFMatrix}, from {@link updateCamera} */
    readonly ecefToWorldMatrix: Matrix4;
    /** The offset that puts the camera on the ellipsoid, from updateCamera */
    readonly altitudeCorrection: Vector3;
    /**
     * Normalized ECEF sun direction. The zero default is not a usable sun
     * Requires: synchronize atmosphere and shadow consumers with the same sun
     * Mutation: copy components into this vector before rendering
     */
    readonly sunDirection: Vector3;
    /** The ellipsoid the projection and altitude correction assume */
    ellipsoid: Ellipsoid;
    /** Sun angular radius in radians, which the sun disc and penumbra use */
    sunAngularRadius: number;
    /** Normalized ECEF moon direction, required when experimental.moonlight is on */
    readonly moonDirection: Vector3;
    /**
     * Artistry over the physical moon-to-sun irradiance ratio, which is 2.5e-6
     * at full moon and far below what a fixed exposure shows
     */
    moonGain: number;
    /** The colour the moonlight carries, usually cooler than the sun's */
    readonly moonColor: Vector3;
    /**
     * The march's light direction: the sun's, or the moon's once twilight has
     * faded the sun out. Written by {@link updateMoonlight}
     */
    readonly lightDirection: Vector3;
    /**
     * The moon's irradiance as a fraction of the sun's, in {@link moonColor}.
     * Written by {@link updateMoonlight}
     */
    readonly moonIrradianceRatio: Vector3;
    /** Radius at which a ray is treated as hitting the surface, in metres */
    bottomRadius: number;
    /** Whether {@link updateCamera} applies the altitude correction offset */
    correctAltitude: boolean;
    /** Camera height above the ellipsoid, in metres, from {@link updateCamera} */
    cameraHeight: number;
    /**
     * Seconds of cloud motion to show. This is a pure function input, not a
     * clock: set it from your own and never let the library advance it. Wind is
     * derived from it as base offset plus velocity times `time`.
     */
    time: number;
    /**
     * Which frame this is. Must advance every frame while `temporalUpscale` is
     * on, or the resolve reprojects against stale history. See the `time` and
     * `frame` contract in WEBGPU.md.
     * Domain: an integer sample index supplied once per rendered frame
     */
    frame: number;
    /** Whether the context may warn on the console, a stale frame for example */
    warnings: boolean;
    private _enabled;
    /**
     * Whether the pass marches at all. `false` compiles the composite to a
     * pass-through, so it rebuilds the graph and, when turned back on, clears
     * history. The supported switch, where the dropped `skipRendering` is not.
     */
    get enabled(): boolean;
    set enabled(v: boolean);
    private _logarithmicDepthBuffer;
    /**
     * Whether `sceneDepth` is a logarithmic depth buffer, which the scene ray
     * distance must undo. Set it to match the renderer.
     */
    get logarithmicDepthBuffer(): boolean;
    set logarithmicDepthBuffer(v: boolean);
    private _graphVersion;
    private _lastLocalWeatherChannels;
    /**
     * How many times the graph shape has changed. The pass folds this into its
     * cache key, so a rebuilt node is a different program. Watch it to know when
     * a rebuild happened.
     */
    get graphVersion(): number;
    private _prevLayerStructure;
    /**
     * Poll the layer set's graph-time shape and rebuild if it moved. Returns
     * whether it did. The pass calls this itself each frame, so an application
     * only needs it when it changes a layer outside its own render loop.
     */
    checkLayerStructure(): boolean;
    private _prevCloudShape;
    /**
     * Poll the four shape controls and rebuild if any moved. Every magnitude is a
     * graph-time literal, so this covers a value changing while its feature is
     * already on, not only the zero crossing.
     */
    checkCloudShape(): boolean;
    /**
     * Poll which weather channels the four layers read and rebuild if that
     * changed, since the channel swizzle is compiled in
     */
    checkLocalWeatherChannels(): boolean;
    private _prevCastsShadow;
    private _prevShadowCascadeCount;
    private _prevShadowTemporalJitter;
    private _prevShadowTemporalPass;
    /**
     * Poll the shadow fields that are compiled rather than uniform, and clear
     * history if any moved. {@link syncShadowMaps} covers the rest of
     * `shadow.*`.
     */
    checkShadowStructure(): boolean;
    /**
     * Copy `shadow.splitLambda`, `shadow.splitMode`, `shadow.maxFar`,
     * `shadow.farScale`, `shadow.cascadeCount` and `shadow.mapSize` into
     * {@link shadowMaps}. The pass calls this once per shadow pass, so the
     * `shadow.*` fields are the only place those values need to be set.
     */
    syncShadowMaps(): void;
    /**
     * Weather is a pure function of `time`. Set `time` from your own clock.
     * Computes derived offsets: base + velocity × time. Call once per frame
     * before the march pass reads the offset uniforms.
     */
    updateOffsets(): void;
    /**
     * Per-frame camera update: ECEF transform, altitude correction, cameraHeight.
     * Call once per frame before the march pass. Mirrors
     * CloudsEffect.updateSharedUniforms() and CloudsMaterial.copyCameraSettings()
     * from the reference.
     */
    updateCamera(camera: Camera): void;
    /**
     * Retargets {@link lightDirection} and {@link moonIrradianceRatio} for the
     * frame. Idempotent and cheap, so every per-frame caller may run it: with
     * the option off it copies the sun's direction and leaves the ratio zero,
     * which is the reference's light
     */
    updateMoonlight(): void;
    updateShadowMaps(camera: Camera): void;
    private _prevGroundBounce;
    /**
     * Whether the ground-bounce march runs, which needs
     * {@link groundBounceScale} positive and `clouds.maxIterationCountToGround`
     * above zero. Polled by {@link checkGroundBounce}.
     */
    get groundBounce(): boolean;
    /** Rebuild if {@link groundBounce} flipped, since it changes the march */
    checkGroundBounce(): boolean;
    /**
     * Every graph-shape fact as one plain object, which is what
     * {@link CloudsPassNode.customCacheKey} hashes. Useful to a caller that wants
     * to know whether a change is a uniform write or a rebuild.
     */
    graphFlags(): {
        shapeDetail: boolean;
        turbulence: boolean;
        lightShafts: boolean;
        lightShaftsHalfResolution: boolean;
        haze: boolean;
        temporalUpscale: boolean;
        accurateSunSkyLight: boolean;
        accuratePhaseFunction: boolean;
        multiScatteringOctaves: number;
        scatterAnisotropy1: number;
        scatterAnisotropy2: number;
        scatterAnisotropyMix: number;
        localWeatherChannels: string;
        layerStructure: string;
        shadowCascadeCount: number;
        shadowTemporalJitter: boolean;
        shadowTemporalPass: boolean;
        castsShadow: boolean;
        groundBounce: boolean;
        logarithmicDepthBuffer: boolean;
        debug: DebugView;
        experimentalFlags: number;
        cloudShape: string;
    };
    /**
     * The last preset applied. The setter writes every field that preset names,
     * so assigning a preset is the way to switch quality rather than copying
     * fields yourself. Explicit overrides leave this name unchanged, and applying
     * the same preset again restores its values. Unknown names throw `RangeError`.
     * Mutation: changed graph fields rebuild, equal values preserve graph/history
     */
    get qualityPreset(): QualityPreset;
    set qualityPreset(name: QualityPreset);
    private _multiScatteringOctaves;
    /** How many octaves of multiple scattering are summed. 0 is single */
    get multiScatteringOctaves(): number;
    set multiScatteringOctaves(v: number);
    private _accurateSunSkyLight;
    /**
     * Whether the ground-bounce irradiance reads the atmosphere LUT per sample
     * (`true`) or a once-per-frame interpolation (`false`). Accurate costs more
     * and changes little.
     */
    get accurateSunSkyLight(): boolean;
    set accurateSunSkyLight(v: boolean);
    private _accuratePhaseFunction;
    /**
     * Whether the phase function uses the accurate approximation (`true`) or the
     * cheaper dual-lobe one (`false`)
     */
    get accuratePhaseFunction(): boolean;
    set accuratePhaseFunction(v: boolean);
    private _resetHistoryCallback;
    /** Register the pass's history-clearing callback. Called by the pass */
    registerResetHistory(callback: () => void): void;
    /**
     * Drop the temporal accumulation, so the next frame reads no history. Call
     * it after anything that invalidates the previous frame's image: a jump in
     * position, a swap of the weather textures, or a change to a graph-shape
     * property, which already calls it for you.
     */
    resetHistory(): void;
    /**
     * Release generated jitter volumes and any texture still assigned here
     * Assigned textures are disposed even when borrowed, so transfer ownership
     * deliberately or detach borrowed slots before calling
     */
    dispose(): void;
}
export declare function isForeignCloudsContext(value: unknown): boolean;
/**
 * Read the {@link CloudsContext} out of a TSL context, for a node that needs
 * the knobs without holding the pass. Throws when the pass is not in the graph,
 * and when two copies of this package are loaded, which is the usual cause of
 * the second message.
 */
export declare function getCloudsContext(ctx: Record<string, unknown>): CloudsContext;
