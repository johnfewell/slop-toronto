import { createHash } from 'node:crypto'
import { copyFileSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

import { prepareThreeR187, THREE_R187 } from './prepare-three-r187.mjs'

export function threeR187RecipeFiles(manifestSource, workspaceSource) {
  if (
    /^(?:overrides|patchedDependencies|peerDependencyRules):/m.test(
      workspaceSource
    )
  )
    throw new Error(
      'The r187 profile requires an unmodified bundled recipe workspace'
    )
  const manifest = JSON.parse(manifestSource)
  if (manifest.dependencies?.three !== '0.184.0')
    throw new Error(
      'The r187 profile requires the bundled r184 recipe manifest'
    )
  manifest.dependencies.three = 'file:.compat/three-r187.tgz'
  manifest.devDependencies['@types/three'] = THREE_R187.types
  return {
    'package.json': `${JSON.stringify(manifest, null, 2)}\n`,
    'pnpm-workspace.yaml': `${workspaceSource.trimEnd()}\noverrides:\n  three: file:.compat/three-r187.tgz\n  '@types/three': ${THREE_R187.types}\npatchedDependencies:\n  three: .compat/three-r187.patch\npeerDependencyRules:\n  allowedVersions:\n    three: '${THREE_R187.version}'\n`
  }
}

export function applyThreeR187(root, packageRoot, options = {}) {
  const sources = threeR187RecipeFiles(
    readFileSync(join(root, 'package.json'), 'utf8'),
    readFileSync(join(root, 'pnpm-workspace.yaml'), 'utf8')
  )
  const target = join(root, '.compat/three-r187.tgz')
  mkdirSync(dirname(target), { recursive: true })
  if (options.threeArchive == null) prepareThreeR187(target)
  else {
    const digest = createHash('sha256')
      .update(readFileSync(options.threeArchive))
      .digest('hex')
    if (digest !== THREE_R187.archiveSha256)
      throw new Error(
        'The prepared Three.js archive differs from the pinned profile'
      )
    copyFileSync(options.threeArchive, target)
  }
  copyFileSync(
    join(packageRoot, 'compat/three-r187.patch'),
    join(root, '.compat/three-r187.patch')
  )
  for (const [name, source] of Object.entries(sources))
    writeFileSync(join(root, name), source)
  return { profile: 'r187', ...THREE_R187 }
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
) {
  if (process.argv.length !== 3) {
    console.error('Usage: node compat/apply-three-r187.mjs RECIPE_DIRECTORY')
    process.exitCode = 1
  } else {
    try {
      const packageRoot = dirname(dirname(fileURLToPath(import.meta.url)))
      console.log(
        JSON.stringify(
          applyThreeR187(resolve(process.argv[2]), packageRoot),
          null,
          2
        )
      )
    } catch (error) {
      console.error(error.message)
      process.exitCode = 1
    }
  }
}
