import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  mkdirSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  writeFileSync
} from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { gzipSync } from 'node:zlib'

export const THREE_R187 = JSON.parse(
  readFileSync(new URL('./three-r187.json', import.meta.url), 'utf8')
)

export function archiveThreeR187(git) {
  return gzipSync(
    git([
      'archive',
      '--worktree-attributes',
      '--format=tar',
      '--prefix=package/',
      THREE_R187.commit,
      ...THREE_R187.paths
    ]),
    { level: 9 }
  )
}

export function prepareThreeR187(destination, options = {}) {
  const temporary =
    options.sourceRoot == null
      ? mkdtempSync(join(tmpdir(), 'clouds-three-r187-'))
      : null
  const root = options.sourceRoot ?? temporary
  const git = args =>
    execFileSync('git', ['-C', root, ...args], {
      maxBuffer: 64 * 1024 * 1024,
      timeout: 120_000,
      stdio: ['ignore', 'pipe', 'pipe']
    })
  try {
    if (temporary != null) {
      git(['init', '-q'])
      git(['remote', 'add', 'origin', THREE_R187.repository])
      git(['config', 'remote.origin.promisor', 'true'])
      git(['config', 'remote.origin.partialclonefilter', 'blob:none'])
      git(['sparse-checkout', 'init', '--cone'])
      git(['sparse-checkout', 'set', 'build', 'src', 'examples/jsm'])
      git([
        '-c',
        'protocol.version=2',
        'fetch',
        '--filter=blob:none',
        '--depth=1',
        'origin',
        THREE_R187.commit
      ])
      git(['checkout', '--detach', THREE_R187.commit])
    }
    const tree = git(['rev-parse', `${THREE_R187.commit}^{tree}`])
      .toString()
      .trim()
    if (tree !== THREE_R187.tree)
      throw new Error('Three.js source tree differs from the pinned profile')
    const manifest = JSON.parse(
      git(['show', `${THREE_R187.commit}:package.json`])
    )
    if (manifest.name !== 'three' || manifest.version !== THREE_R187.version)
      throw new Error('Three.js manifest differs from the pinned profile')
    for (const path of ['src/constants.js', 'build/three.core.js']) {
      const source = git(['show', `${THREE_R187.commit}:${path}`]).toString()
      if (!source.includes(`REVISION = '${THREE_R187.revision}'`))
        throw new Error(`Three.js revision differs in ${path}`)
    }
    const archive = archiveThreeR187(git)
    const archiveSha256 = createHash('sha256').update(archive).digest('hex')
    if (archiveSha256 !== THREE_R187.archiveSha256)
      throw new Error('Prepared archive differs from the pinned digest')
    const output = resolve(destination)
    mkdirSync(dirname(output), { recursive: true })
    writeFileSync(output, archive)
    const receipt = {
      ...THREE_R187,
      archiveSha256,
      bytes: archive.length
    }
    writeFileSync(`${output}.json`, `${JSON.stringify(receipt, null, 2)}\n`)
    return receipt
  } finally {
    if (temporary != null) rmSync(temporary, { recursive: true, force: true })
  }
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
) {
  const args = process.argv.slice(2)
  const sourceFlag = args.indexOf('--source')
  const sourceRoot = sourceFlag === -1 ? undefined : args[sourceFlag + 1]
  if (sourceFlag !== -1) args.splice(sourceFlag, 2)
  if (args.length > 1 || (sourceFlag !== -1 && !sourceRoot)) {
    console.error(
      'Usage: node compat/prepare-three-r187.mjs [archive.tgz] [--source git-checkout]'
    )
    process.exitCode = 1
  } else {
    try {
      const destination = args[0] ?? '.compat/three-r187.tgz'
      console.log(
        JSON.stringify(prepareThreeR187(destination, { sourceRoot }), null, 2)
      )
    } catch (error) {
      console.error(error.message)
      process.exitCode = 1
    }
  }
}
