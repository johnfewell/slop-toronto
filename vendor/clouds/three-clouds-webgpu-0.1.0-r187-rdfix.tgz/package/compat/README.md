# Experimental Three.js r187 profile

The ordinary consumer recipes use unpatched Three.js **0.184.0**. This opt-in
profile uses development commit
`e27dfa95ae7f453b5d7a9a36ffdb563f7c9b529b`, whose runtime reports **187dev**.
It is not a published `three@0.187.0` release. Upstream still labels this
snapshot's manifest `0.186.0`; use the commit, runtime revision and hashes to
identify it. The available TypeScript declarations are pinned to `0.186.0`.

## Use a bundled recipe

Extract the cloud package archive, copy either `recipes/vanilla` or `recipes/r3f`
to its own application directory, and copy the cloud tarball to that recipe's
`vendor/three-clouds-webgpu.tgz`, as the recipe README describes. Before the
recipe's first install, run this from the extracted package:

```sh
node compat/apply-three-r187.mjs /path/to/copied-recipe
cd /path/to/copied-recipe
pnpm install
pnpm build
pnpm dev
```

The command requires Git, network access to the public Three.js repository and
Node 24. It requires the bundled recipe's r184 pin and no existing dependency
overrides, patches or peer-rule configuration.
It prepares `.compat/three-r187.tgz`, copies the compatibility patch and updates
the two dependency configuration files. Application sources remain the shipped
recipe sources. Commit the resulting lockfile and retain the generated peer
archive for reproducible installs.

The workspace override forces every peer onto the same prepared Three.js copy.
Its explicit peer-rule exception acknowledges the experimental snapshot's
`0.186.0` manifest; it does not widen the cloud package's ordinary peer range or
qualify stock r186. The shader and constructor identities must remain shared.

## What the shim changes

The patch restores `.layout`, `.isStruct` and the `in` operator's legacy layout
check on the struct constructor, preserving the modern proxy properties and
`StructTypeNode` identity. Takram's published atmosphere/geospatial packages
need this during module initialization. The active r187 TSL implementation is
`build/three.tsl.js`; its source counterpart is patched too.

No `ContextNode` engine patch is applied. This pinned upstream snapshot already
contains the conditional-scope correction. The library binds fullscreen quad
materials explicitly. Regression tests guard procedural indexing, compute tiles
and quad iteration caps against floating-point promotion.

The React recipe explicitly keeps ordinary mesh shadows disabled with
`shadows: { enabled: false, type: PCFShadowMap }`, at startup and on resize.
Fiber 9.7 otherwise selects the removed `PCFSoftShadowMap` even when shadows are
disabled. Pass the same object to `Canvas` when using that entrypoint. This does
not disable the library's own cloud-shadow passes.

## Build this repository

Before the first repository install:

```sh
node compat/prepare-three-r187.mjs
pnpm install --frozen-lockfile
pnpm check
```

The preparation script fetches the exact commit with a sparse checkout, verifies
the Git tree and both source/built revision markers, then creates a compact
dependency archive. The expected archive SHA-256 is recorded in
[`three-r187.json`](three-r187.json); a mismatch refuses installation preparation.
The archive includes upstream's license, built modules, sources and addons,
without the repository's unrelated example assets. The generated archive stays
outside the cloud tarball.

Archiving uses the sparse worktree's attributes. Otherwise Git can lazily fetch
unselected repository blobs during `git archive`, causing avoidable timeouts.
The resulting archive must still match the same pinned SHA-256.

## Qualification

Packing retains the ordinary r184 recipes. Run either matrix explicitly:

```sh
pnpm pack:qualify ./three-clouds-webgpu-0.1.0.tgz --keep-projects
pnpm pack:qualify ./three-clouds-webgpu-0.1.0.tgz --three-profile r187 --receipt ./test-results/r187-consumer.json --keep-projects
node examples/parity/scripts/consumer-native/run.mjs ./test-results/r187-consumer.json ./test-results/r187-native
```

The r187 qualifier applies the profile from the actual archive, reproduces the
unpatched Takram import failure in a separate control, and qualifies the patched
standalone vanilla and React builds. Receipts identify the prepared Three.js
archive, installed peer bytes and actual runtime revision. Native verification
checks the recipe configuration against the archived sources and declared
profile, and rechecks installed peer bytes before and after rendering.

Native WebGPU and perspective cameras remain required. This profile targets the
specified development snapshot; other r187 commits and the eventual release
require fresh qualification. PMREM and numeric type-promotion changes mean old
shader hashes and pixel evidence cannot be inherited automatically.
