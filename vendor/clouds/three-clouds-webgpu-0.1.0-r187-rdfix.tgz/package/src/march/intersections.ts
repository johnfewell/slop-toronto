// Ported from @takram/three-clouds (MIT, Copyright (c) 2024 Shota Matsuda)
// Source: clouds.frag:718–810

import { dot, Fn, If, sqrt, struct, vec2, vec3, vec4 } from 'three/tsl'
import type { Node } from 'three/webgpu'

// Reference: https://github.com/GameTechDev/OutdoorLightScattering/blob/master/fx/Common.fxh#L148

// The core raySpheresIntersections masks only .x/.y, right for the atmosphere,
// wrong for four cloud shells. Same math with a vec4 mask, upstream report
// pending (cw-bug-shadow-pass-build-errors-4p2)
export const raySpheresIntersections4Struct = /*#__PURE__*/ struct(
  { near: 'vec4', far: 'vec4' },
  'RaySpheresIntersections4'
)

export const raySpheresIntersections4 = /*#__PURE__*/ Fn(
  ([rayOrigin, rayDirection, center, radii]: [
    Node<'vec3'>,
    Node<'vec3'>,
    Node<'vec3'>,
    Node<'vec4'>
  ]) => {
    const a = rayOrigin.sub(center)
    const b = dot(rayDirection, a)
    const c = dot(a, a).sub(radii.mul(radii))
    const discriminant = b.mul(b).sub(c).toVar()
    const mask = vec4(discriminant.greaterThanEqual(0)).toVar()
    const inverseMask = mask.oneMinus()
    const Q = sqrt(discriminant.max(0))
    const near = mask.mul(b.negate().sub(Q)).sub(inverseMask)
    const far = mask.mul(b.negate().add(Q)).sub(inverseMask)
    return raySpheresIntersections4Struct(near, far)
  }
)

// clouds.frag:718–722
export const rayIntersectsGround = /*#__PURE__*/ Fn(
  ([cameraPosition, rayDirection, bottomRadius]: [
    Node<'vec3'>,
    Node<'vec3'>,
    Node<'float'>
  ]) => {
    const r = cameraPosition.length()
    const mu = cameraPosition.dot(rayDirection).div(r)
    return mu
      .lessThan(0)
      .and(
        r
          .mul(r)
          .mul(mu.mul(mu).sub(1))
          .add(bottomRadius.mul(bottomRadius))
          .greaterThanEqual(0)
      )
  }
)

// A TSL Fn returns exactly one node, so the three outputs travel as a struct
// and are read with .get('ground' | 'first' | 'second')
export const intersectionsStruct = /*#__PURE__*/ struct(
  { ground: 'bool', first: 'vec4', second: 'vec4' },
  'CloudIntersections'
)

// clouds.frag:730–741
// Reference: https://github.com/GameTechDev/OutdoorLightScattering/blob/master/fx/Common.fxh#L148
export const getIntersections = /*#__PURE__*/ Fn(
  ([
    cameraPosition,
    rayDirection,
    bottomRadius,
    minHeight,
    maxHeight,
    shadowTopHeight
  ]: [
    Node<'vec3'>,
    Node<'vec3'>,
    Node<'float'>,
    Node<'float'>,
    Node<'float'>,
    Node<'float'>
  ]) => {
    const ground = rayIntersectsGround(
      cameraPosition,
      rayDirection,
      bottomRadius
    )
    const radii = bottomRadius.add(
      vec4(0, minHeight, maxHeight, shadowTopHeight)
    )
    const result = raySpheresIntersections4(
      cameraPosition,
      rayDirection,
      vec3(0),
      radii
    )
    const first = result.get('near')
    const second = result.get('far')
    return intersectionsStruct(ground, first, second)
  }
)

// clouds.frag:743–769
export const getRayNearFar = /*#__PURE__*/ Fn(
  ([
    ground,
    first,
    second,
    cameraHeight,
    cameraNear,
    minHeight,
    maxHeight,
    maxRayDistance
  ]: [
    Node<'bool'>,
    Node<'vec4'>,
    Node<'vec4'>,
    Node<'float'>,
    Node<'float'>,
    Node<'float'>,
    Node<'float'>,
    Node<'float'>
  ]) => {
    const nearFar = vec2(-1).toVar()

    If(cameraHeight.lessThan(minHeight), () => {
      If(ground, () => {
        nearFar.assign(vec2(-1))
      }).Else(() => {
        nearFar.assign(vec2(second.y, second.z.min(maxRayDistance)))
      })
    })
      .ElseIf(cameraHeight.lessThan(maxHeight), () => {
        If(ground, () => {
          nearFar.assign(vec2(cameraNear, first.y))
        }).Else(() => {
          nearFar.assign(vec2(cameraNear, second.z))
        })
      })
      .Else(() => {
        nearFar.assign(vec2(first.z, second.z))
        If(ground, () => {
          nearFar.y.assign(first.y)
        })
      })

    return nearFar
  }
)

// clouds.frag:772–789
export const getShadowRayNearFar = /*#__PURE__*/ Fn(
  ([
    ground,
    first,
    second,
    cameraHeight,
    cameraNear,
    shadowTopHeight,
    maxShadowLengthRayDistance
  ]: [
    Node<'bool'>,
    Node<'vec4'>,
    Node<'vec4'>,
    Node<'float'>,
    Node<'float'>,
    Node<'float'>,
    Node<'float'>
  ]) => {
    const nearFar = vec2(-1).toVar()

    If(cameraHeight.lessThan(shadowTopHeight), () => {
      If(ground, () => {
        nearFar.assign(vec2(cameraNear, first.x))
      }).Else(() => {
        nearFar.assign(vec2(cameraNear, second.w))
      })
    }).Else(() => {
      nearFar.assign(vec2(first.w, second.w))
      If(ground, () => {
        nearFar.y.assign(first.x)
      })
    })

    nearFar.y.assign(nearFar.y.min(maxShadowLengthRayDistance))
    return nearFar
  }
)

// clouds.frag:793–810
export const getHazeRayNearFar = /*#__PURE__*/ Fn(
  ([ground, first, second, cameraHeight, cameraNear, maxHeight]: [
    Node<'bool'>,
    Node<'vec4'>,
    Node<'vec4'>,
    Node<'float'>,
    Node<'float'>,
    Node<'float'>
  ]) => {
    const nearFar = vec2(-1).toVar()

    If(cameraHeight.lessThan(maxHeight), () => {
      If(ground, () => {
        nearFar.assign(vec2(cameraNear, first.x))
      }).Else(() => {
        nearFar.assign(vec2(cameraNear, second.z))
      })
    }).Else(() => {
      nearFar.assign(vec2(cameraNear, second.z))
      If(ground, () => {
        nearFar.y.assign(first.x)
      })
    })

    return nearFar
  }
)
