// Ported from @takram/three-clouds (MIT, Copyright (c) 2024 Shota Matsuda)
// https://github.com/takram-design-engineering/three-geospatial
// Cite: ADR-007 (two shadow consumers: 3.2a aerial, 3.2b light-node)

// INTERIM SUBCLASS pinned to @takram/three-atmosphere 0.19.1: setup() copies
// AerialPerspectiveNode.setup() with cloud-shadowed solar illuminance and an
// optional lighting mask

// Self-lit pixels keep atmospheric transfer but skip surface illumination. The
// adapter uses upstream only when it supports every requested input

import type { Camera } from 'three'
import {
  add,
  float,
  Fn,
  If,
  mix,
  positionGeometry,
  remapClamp,
  struct,
  uv,
  vec2,
  vec3,
  vec4
} from 'three/tsl'
import type { Node, NodeBuilder } from 'three/webgpu'

import {
  AerialPerspectiveNode,
  getAtmosphereContext,
  getIndirectLuminanceToPoint,
  getSplitIlluminance
} from '@takram/three-atmosphere/webgpu'
import type { Ellipsoid } from '@takram/three-geospatial'
import {
  depthToViewZ,
  inverseProjectionMatrix,
  inverseViewMatrix,
  projectionMatrix,
  rayEllipsoidIntersection,
  screenToPositionView
} from '@takram/three-geospatial/webgpu'

import { applySurfaceLightingMask } from './surfaceLightingMask'

const luminanceTransferStruct = /*#__PURE__*/ struct(
  { transmittance: 'vec3', inscattering: 'vec3' },
  'CloudShadowedLuminanceTransfer'
)

// ARM BC (cw-pn0s), marked throwaway-branch only. surfaceIlluminance returns
// direct and indirect apart, because the closure test is a sum of separate
// contributions to the plate, with no coefficient for a units error to hide in

// The direct member is pre-shadow (READ 1, R = D): s is emitted separately (G),
// and BC1a = sum(D * (1 - s)) needs both halves

// F1: read2's B channel carries one of these on every pixel, 0.5 from the
// surface path and 0.25 off it. Exported so the runner and scorer never restate
// them (cw-32cq)

// They must stay distinct, or the channel stops saying which path wrote the
// pixel. Both are exact in float32
export const BC_SENTINEL_SURFACE = 0.5
export const BC_SENTINEL_SKY = 0.25

const splitIlluminanceStruct = /*#__PURE__*/ struct(
  { direct: 'vec3', indirect: 'vec3' },
  'CloudShadowedSplitIlluminance'
)

export class CloudShadowedAerialPerspectiveNode extends AerialPerspectiveNode {
  static override get type(): string {
    return 'CloudShadowedAerialPerspectiveNode'
  }

  shadowNode: Node<'float'> | null = null
  lightingMaskNode: Node<'float'> | null = null

  // ARM BC (cw-pn0s): when set, setup() emits the READ 1 lane pack (R = D
  // pre-shadow, G = s, B = I, A = S, luminance-weighted) instead of the plate

  // A graph-shape flag: set it before the warm-up, and re-warm 64+ frames after
  // any toggle, since a rebuild re-arms the history accumulators (#1712)
  budgetClosure: 'off' | 'read1' | 'read2' = 'off'

  // ARM BC READ 2, lane A: the raw optical depth, supplied independently. As
  // -log(shadowNode) it would make F3 (|s - e^-od| <= 1e-5) true by algebra

  // Fed from createSampleCloudShadowOpticalDepth with the transmittance's
  // inputs, so F3 catches lanes threaded to different position/radius/jitter
  opticalDepthNode: Node<'float'> | null = null

  override setup(builder: NodeBuilder): unknown {
    const atmosphereContext = getAtmosphereContext(builder)

    // The atmosphere package and three declare structurally distinct Node and
    // builder types. Every conversion below is that package boundary, not a
    // loss of type information (see sampleShadowOpticalDepth.ts)
    const camera =
      atmosphereContext.camera ??
      (builder as unknown as { camera?: Camera }).camera
    if (camera == null) {
      return
    }

    const { worldToUnit } = atmosphereContext.parametersNode as unknown as {
      worldToUnit: Node<'float'>
    }
    const {
      ellipsoid,
      matrixWorldToECEF,
      sunDirectionECEF,
      moonDirectionECEF,
      cameraPositionUnit,
      altitudeCorrectionUnit
    } = atmosphereContext as unknown as {
      ellipsoid: Ellipsoid
      matrixWorldToECEF: Node<'mat4'>
      sunDirectionECEF: Node<'vec3'>
      moonDirectionECEF: Node<'vec3'>
      cameraPositionUnit: Node<'vec3'>
      altitudeCorrectionUnit: Node<'vec3'>
    }

    const { colorNode, depthNode, normalNode } = this as unknown as {
      colorNode: Node<'vec4'>
      depthNode: Node<'vec4'>
      normalNode: Node<'vec4'> | null
    }
    const depth = depthNode.r.toConst()

    const getSurfacePositionECEF = (): Node<'vec3'> => {
      const viewZ = depthToViewZ(depth, camera)
      const positionView = screenToPositionView(
        uv(),
        depth,
        viewZ,
        projectionMatrix(camera),
        inverseProjectionMatrix(camera)
      ) as unknown as Node<'vec3'>
      const positionWorld = (
        inverseViewMatrix(camera) as unknown as Node<'mat4'>
      ).mul(vec4(positionView, 1)).xyz
      return matrixWorldToECEF.mul(vec4(positionWorld, 1)).xyz
    }

    const getRayDirectionECEF = (): Node<'vec3'> => {
      const positionView = (
        inverseProjectionMatrix(camera) as unknown as Node<'mat4'>
      ).mul(vec4(positionGeometry, 1)).xyz
      const directionWorld = (
        inverseViewMatrix(camera) as unknown as Node<'mat4'>
      ).mul(vec4(positionView, 0)).xyz
      const directionECEF = matrixWorldToECEF.mul(vec4(directionWorld, 0)).xyz
      return directionECEF.toVertexStage().normalize()
    }

    const surfaceIlluminance = Fn(
      ([positionUnit, normalCorrected, geometryCorrectionAmount]: [
        Node<'vec3'>,
        Node<'vec3'>,
        Node<'float'>
      ]) => {
        const normalECEF = positionUnit.normalize().toVar()
        if (normalNode != null) {
          const normalView = normalNode.xyz
          const normalWorld = (
            inverseViewMatrix(camera) as unknown as Node<'mat4'>
          ).mul(vec4(normalView, 0)).xyz
          normalECEF.assign(matrixWorldToECEF.mul(vec4(normalWorld, 0)).xyz)

          if (this.correctGeometricError) {
            normalECEF.assign(
              mix(normalECEF, normalCorrected, geometryCorrectionAmount)
            )
          }
        }

        const solarIlluminance = getSplitIlluminance(
          positionUnit.add(altitudeCorrectionUnit),
          normalECEF,
          sunDirectionECEF
        )
        // One change vs upstream: direct × cloudShadow + indirect. ARM BC
        // returns the pair and the caller applies the shadow and adds them, so
        // the plate value is arithmetically unchanged
        const direct = solarIlluminance.get('direct') as Node<'vec3'>
        let indirect = solarIlluminance.get('indirect')
        if (this.moonScattering) {
          const lunarIlluminance = getSplitIlluminance(
            positionUnit.add(altitudeCorrectionUnit),
            normalECEF,
            moonDirectionECEF
          )
          // Upstream adds lunar after the cloud-shadow multiply, so it goes with
          // indirect. Folding it into direct would start shadowing moonlight
          indirect = add(
            indirect,
            lunarIlluminance.get('direct'),
            lunarIlluminance.get('indirect')
          )
        }
        return splitIlluminanceStruct(direct, indirect)
      }
    )

    const surfaceLuminanceTransfer = Fn(([positionUnit]: [Node<'vec3'>]) => {
      const solarLuminanceTransfer = getIndirectLuminanceToPoint(
        cameraPositionUnit.add(altitudeCorrectionUnit),
        positionUnit.add(altitudeCorrectionUnit),
        this.shadowLengthNode ?? vec2(0),
        sunDirectionECEF
      ).toConst()
      const transmittance = solarLuminanceTransfer.get('transmittance')
      let inscattering = solarLuminanceTransfer.get('luminance')

      if (this.moonScattering) {
        const lunarLuminanceTransfer = getIndirectLuminanceToPoint(
          cameraPositionUnit.add(altitudeCorrectionUnit),
          positionUnit.add(altitudeCorrectionUnit),
          this.shadowLengthNode ?? vec2(0),
          moonDirectionECEF
        ).toConst()

        inscattering = inscattering.add(
          lunarLuminanceTransfer.get('luminance').mul(2.5e-6)
        )
      }
      return luminanceTransferStruct(transmittance, inscattering)
    })

    const budgetClosureRead2 = Fn(() => {
      // Unit space -> metres (/worldToUnit) -> km (/1000), per the bound
      // conversion. The F2 range gate (|x|,|y| <= 1000 km) is what catches a
      // conversion done in the wrong order or missed entirely
      const toKm = (v: Node<'float'>): Node<'float'> =>
        v.div(worldToUnit).div(1000)
      // Same package-boundary cast the rest of this file uses: vec2's
      // components are not exposed on the generic Node type
      const lengthPair = (this.shadowLengthNode ?? vec2(0)) as unknown as {
        x: Node<'float'>
        y: Node<'float'>
      }
      // R = shadow length (km), G = interval near (km), B = surface sentinel
      // (F1), A = raw independent od
      return vec4(
        toKm(lengthPair.x),
        toKm(lengthPair.y),
        float(BC_SENTINEL_SURFACE),
        this.opticalDepthNode ?? float(0)
      )
    })

    const maskedSurface = Fn(
      ([postLit, transmittance]: [Node<'vec3'>, Node<'vec3'>]) => {
        if (this.lightingMaskNode == null) return postLit
        const selfLit = this.transmittance
          ? colorNode.rgb.mul(transmittance)
          : colorNode.rgb
        return applySurfaceLightingMask(
          selfLit,
          postLit,
          this.lighting ? this.lightingMaskNode : float(0)
        )
      }
    )

    const surfaceLuminance = Fn(() => {
      const positionUnit = getSurfacePositionECEF().mul(worldToUnit).toVar()

      const geometryCorrectionAmount = remapClamp(
        positionUnit.distance(cameraPositionUnit),
        worldToUnit.mul(336_000),
        worldToUnit.mul(876_000)
      )

      const radiiUnit = vec3(ellipsoid.radii).mul(worldToUnit)
      const normalCorrected = positionUnit.div(radiiUnit.pow2()).normalize()

      if (this.correctGeometricError) {
        const rayDirectionECEF = getRayDirectionECEF()
        const intersection = rayEllipsoidIntersection(
          cameraPositionUnit,
          rayDirectionECEF,
          radiiUnit
        ).x

        const positionCorrected = intersection
          .greaterThanEqual(0)
          .select(
            rayDirectionECEF.mul(intersection).add(cameraPositionUnit),
            normalCorrected.mul(radiiUnit)
          )
        positionUnit.assign(
          mix(positionUnit, positionCorrected, geometryCorrectionAmount)
        )
      }

      const split = surfaceIlluminance(
        positionUnit,
        normalCorrected,
        geometryCorrectionAmount
      )
      const directIlluminance = split.get('direct') as Node<'vec3'>
      const indirectIlluminance = split.get('indirect') as Node<'vec3'>
      const shadow = this.shadowNode ?? float(1)

      // ARM BC: the diffuse assembly per term, with the summed form's albedo/pi
      // and transmittance, so D and I are contributions in plate units (READ 1)
      const diffuseDirect = this.lighting
        ? colorNode.rgb.mul(directIlluminance).mul(1 / Math.PI)
        : colorNode.rgb
      const diffuseIndirect = this.lighting
        ? colorNode.rgb.mul(indirectIlluminance).mul(1 / Math.PI)
        : colorNode.rgb.mul(0)

      const luminanceTransfer = surfaceLuminanceTransfer(positionUnit)
      // struct .get() is not generic over the member table (cloudsFragment.ts)
      const transmittance = luminanceTransfer.get(
        'transmittance'
      ) as Node<'vec3'>
      const inscattering = luminanceTransfer.get('inscattering') as Node<'vec3'>

      // D and I carry the transmittance multiply exactly as the summed diffuse
      // did, applied to each term rather than to their sum, which is the same
      // value by distributivity and is what the reproduce-the-plate gate checks
      let laneDirect = diffuseDirect
      let laneIndirect = diffuseIndirect
      if (this.transmittance) {
        laneDirect = laneDirect.mul(transmittance)
        laneIndirect = laneIndirect.mul(transmittance)
      }
      const laneInscatter = this.inscattering
        ? inscattering
        : inscattering.mul(0)

      // The plate value, reassembled: D*s + I + S. Arithmetically identical to
      // the previous `(direct*s + indirect) * transmittance + inscattering`;
      // the shadow multiply moved inside because D is emitted pre-shadow
      const postLit = laneDirect.mul(shadow).add(laneIndirect)
      const output = maskedSurface(postLit, transmittance).add(laneInscatter)

      // BC lanes, luminance-weighted per the binding (Rec.709), written only in
      // budgetClosure mode. Nothing above this line is conditional on the mode:
      // the normal path computes exactly what it always did
      if (this.budgetClosure === 'read1') {
        const lum = (v: Node<'vec3'>): Node<'float'> =>
          v.dot(vec3(0.2126, 0.7152, 0.0722))
        // R = D (pre-shadow), G = s, B = I, A = S
        return vec4(
          lum(laneDirect),
          shadow,
          lum(laneIndirect),
          lum(laneInscatter)
        )
      }
      if (this.budgetClosure === 'read2') {
        // ARM BC (cw-pn0s), read2 only: opticalDepthNode reaches the package's
        // atmosphere density structs (common.ts:611), which must be registered
        // on the fragment builder. read1 never reads them

        // The builder registered them for the vertex stage only and threw in
        // MRTNode.build. Registration follows a struct-returning call being
        // built, so .toConst() then .get() a member does it

        // Placed in read2's Fn stack and touching no lane: the emitted pack is
        // identical before and after (verified as a diff)
        const bcTransfer = (
          luminanceTransfer as unknown as {
            toConst: () => { get: (name: string) => { toConst: () => unknown } }
          }
        ).toConst()
        bcTransfer.get('transmittance').toConst()
        return budgetClosureRead2()
      }
      return output
    })()

    return Fn(() => {
      const luminance = colorNode.toVar()
      const isSky = builder.renderer.reversedDepthBuffer
        ? depth.lessThanEqual(0)
        : depth.greaterThanEqual(1)

      if (this.budgetClosure !== 'off') {
        // BC lanes are a full RGBA pack: assigning only .rgb would leave
        // colorNode's alpha in read1.A. The sky branch needs its own pack
        // because F1 requires read2's B sentinel on every pixel

        // Off-surface the transmittance is vacuous, s = 1 and od = 0, so F3
        // holds there. The receipt verifies these pinned constants:
        // read1 sky = vec4(0, 1, 0, 0), read2 sky = vec4(0, 0, BC_SENTINEL_SKY, 0)
        const skyPack =
          this.budgetClosure === 'read2'
            ? vec4(0, 0, BC_SENTINEL_SKY, 0)
            : vec4(0, 1, 0, 0)
        If(isSky, () => {
          luminance.assign(skyPack)
        }).Else(() => {
          luminance.assign(surfaceLuminance)
        })
        return luminance
      }

      // The sky goes into `luminance`, the variable this Fn returns, as
      // upstream's `x.rgb.assign(this.skyNode)` does with x = colorNode.toVar()

      // Writing the input sample instead returned the background's sky and threw
      // away the aerial's shafts (the sky-branch discards shafts ruling,
      // found by the storybook A/B)
      If(isSky, () => {
        if (this.skyNode != null) {
          luminance.rgb.assign(this.skyNode)
        }
      }).Else(() => {
        luminance.rgb.assign(surfaceLuminance)
      })
      return luminance
    })()
  }
}
