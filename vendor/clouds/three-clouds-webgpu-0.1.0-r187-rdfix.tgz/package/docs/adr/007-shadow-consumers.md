# ADR-007 — Two shadow consumers: aerial direct×shadow (unlit) and light-node subclass (lit)

## Context

Cloud shadows must reach two kinds of geometry: unlit/post-lit surfaces (e.g. photogrammetry tiles using `MeshBasicMaterial`) whose sun/sky illuminance comes from `AerialPerspectiveNode` when `lighting === true`, and lit node materials whose direct light comes from `AtmosphereLightNode`. Consumer 3.2b alone leaves unlit geometry unshadowed. The WebGPU `AerialPerspectiveNode` has no lighting mask (WebGL had `lightingMask`/`LightingMaskPass`), so a frame is either post-lit or light-node-lit, never both.

## Decision

Both consumers are required:

| ID | Geometry | Hook |
|---|---|---|
| 3.2a | Unlit / post-lit (`lighting === true`) | `AerialPerspectiveNode` gains an optional `shadowNode: Node<'float'>` (transmittance 0–1). Multiplies ONLY the `direct` solar term: `illuminance = direct × shadow + indirect`. Producer: `exp(−od)` via the ground sampler (ADR-006, no tail). |
| 3.2b | Lit node materials (`lighting === false`) | Subclass of `AtmosphereLightNode`, attenuates direct term by `exp(−od)`. Registered with `renderer.library.addLight(CloudShadowedAtmosphereLightNode, AtmosphereLight)`. |

3.2a interface shape: the aerial node's `illuminance` Fn (inside `setup()`, `AerialPerspectiveNode.ts:~195–230`) has `add(direct, indirect)` at `:216–218`. The interim `CloudShadowedAerialPerspectiveNode` copies `setup()` from the pinned 0.19.1 source (~150 lines, file header says so) and changes that one line to `add(direct.mul(shadowNode ?? 1), indirect)`. A WGSL snapshot test proves the copy has not drifted: the subclass with `shadowNode = float(1)` compiles normalised-identical to the upstream node.

Lighting modes: 3.2a on the parity scene's default `'post'` mode (cases 34/36); 3.2b on its `'lights'` mode (case 35). The two paths never share a frame.

## Consequences

- The library ships an adapter file with the subclass; upstreaming the `shadowNode` input on `AerialPerspectiveNode` is preferred long-term.
- `WEBGPU.md` documents the missing `lightingMask` and the two lighting modes.
- Parity cases 34–36 prove both consumers on pixels.
- The WGSL snapshot test on the interim subclass catches upstream drift at `pnpm test` time.

## References

- `reference/atmosphere-webgpu/AerialPerspectiveNode.ts:55, 73–80, ~186–230`
- `reference/atmosphere-webgpu/AtmosphereLightNode.ts:21, 77`
- `aerialPerspectiveEffect.frag:357` (WebGL shadow sample)
- ADR-001 (render graph, lighting modes)
- ADR-006 (atlas and ground sampler)
