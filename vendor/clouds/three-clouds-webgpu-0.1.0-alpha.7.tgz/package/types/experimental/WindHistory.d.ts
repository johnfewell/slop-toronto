import { Vector3 } from 'three';
import { Node } from 'three/webgpu';
import { CloudsContext } from '../CloudsContext.js';
export declare const previousCloudPosition: import('three/tsl').FnNode<[Vector3 | Node<"vec3">, Vector3 | Node<"vec3">], Node<"vec3">>;
export declare class WindHistory {
    readonly displacement: import('three/webgpu').UniformNode<"vec3", Vector3>;
    readonly cloudValid: import('three/webgpu').UniformNode<"bool", boolean>;
    readonly shadowValid: import('three/webgpu').UniformNode<"bool", boolean>;
    private previousTime;
    private readonly shape;
    private readonly detail;
    private readonly repeat;
    private readonly detailRepeat;
    private readonly weatherRepeat;
    private readonly worldToECEF;
    private readonly detailDisplacement;
    reset(): void;
    update(ctx: CloudsContext): void;
    private sameDomain;
    private compatibleDetail;
    private remember;
}
