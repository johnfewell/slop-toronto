import { Node } from 'three/webgpu';
export interface CloudShapeParams {
    baseShadowStrength: number;
    baseShadowHeight: number;
    horizonCoverageAmount: number;
    horizonCoverageStart: number;
    horizonCoverageRamp: number;
    windSkewEast: number;
    windSkewNorth: number;
    erosionShape: number;
}
export declare const cloudShapeDefaults: Readonly<CloudShapeParams>;
export declare function cloudShapeKey(params: Readonly<CloudShapeParams>): string;
export declare const baseShadowTransmittance: import('three/tsl').FnNode<[number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
export declare const horizonCoverageBank: import('three/tsl').FnNode<[number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
export declare const windSkewOffset: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"vec3">>;
export declare const erosionShapeAmount: import('three/tsl').FnNode<[import('three').Vector4 | Node<"vec4">, number | Node<"float"> | Node<"uint">], Node<"vec4">>;
export declare function unitVec(v: readonly number[]): [number, number, number];
export declare function cpuBaseShadowTransmittance(heightFraction: number, strength: number, heightSpan: number): number;
export declare function cpuHorizonCoverageBank(rayDistance: number, amount: number, start: number, ramp: number): number;
export declare function cpuWindSkewOffset(surfaceNormal: readonly number[], heightFraction: number, skewEast: number, skewNorth: number): number[];
export declare function cpuErosionShapeAmount(amount: number, erosion: number): number;
export interface CloudShapeDeps {
    baseShadow: ((heightFraction: Node<'float'>) => Node<'float'>) | null;
    horizonCoverage: ((rayDistance: Node<'float'>) => Node<'vec4'>) | null;
    windSkew: ((surfaceNormal: Node<'vec3'>, heightFraction: Node<'float'>) => Node<'vec3'>) | null;
    erosion: ((amounts: Node<'vec4'>) => Node<'vec4'>) | null;
}
export declare function buildCloudShapeDeps(params: Readonly<CloudShapeParams>, active?: readonly [boolean, boolean, boolean, boolean]): CloudShapeDeps;
