import { Node, UniformNode } from 'three/webgpu';
export interface ConvectiveProfileParams {
    anvilCenter: number;
    anvilWidth: number;
    anvilStrength: number;
    cellsPerWeatherTile: number;
    cellThreshold: number;
    cellSoftness: number;
    cellDensity: number;
}
export declare const convectiveProfileDefaults: Readonly<ConvectiveProfileParams>;
export declare const CONVECTIVE_TOWER_MIN_HEIGHT = 4000;
export declare const CONVECTIVE_TOWER_RAMP = 1000;
export declare const convectiveHeightProfile: import('three/tsl').FnNode<[import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, import('three').Vector4 | Node<"vec4">], Node<"vec4">>;
export declare function convectiveHeightProfileCPU(heightFraction: number, expTerm: number, exponent: number, linearTerm: number, constantTerm: number, center: number, width: number, strength: number): number;
export declare const towerWeight: import('three/tsl').FnNode<[import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">], Node<"vec4">>;
export declare function towerWeightCPU(minHeight: number, maxHeight: number): number;
export declare const cellMask: import('three/tsl').FnNode<[import('three').Vector2 | Node<"vec2">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
export declare function cellMaskCPU(u: number, v: number, scale: number, threshold: number, softness: number): number;
export interface ConvectiveUniforms {
    anvilCenter: UniformNode<'float', number>;
    anvilWidth: UniformNode<'float', number>;
    anvilStrength: UniformNode<'float', number>;
    cellsPerWeatherTile: UniformNode<'float', number>;
    cellThreshold: UniformNode<'float', number>;
    cellSoftness: UniformNode<'float', number>;
    cellDensity: UniformNode<'float', number>;
}
export declare function createConvectiveUniforms(params: ConvectiveProfileParams): ConvectiveUniforms;
export declare function updateConvectiveUniforms(uniforms: ConvectiveUniforms, params: ConvectiveProfileParams): void;
export interface ConvectiveProfileTerms {
    expTerms: Node<'vec4'>;
    exponents: Node<'vec4'>;
    linearTerms: Node<'vec4'>;
    constantTerms: Node<'vec4'>;
}
export interface ConvectiveDeps {
    heightProfile: (heightFraction: Node<'vec4'>, terms?: ConvectiveProfileTerms) => Node<'vec4'>;
    cellMask: (uv: Node<'vec2'>) => Node<'float'>;
    cellDensity: Node<'float'>;
}
export declare function buildConvectiveDeps(terms: ConvectiveProfileTerms, minLayerHeights: Node<'vec4'>, maxLayerHeights: Node<'vec4'>, localWeatherRepeat: Node<'vec2'>, uniforms: ConvectiveUniforms): ConvectiveDeps;
