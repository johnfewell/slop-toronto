import { Node, TextureNode } from 'three/webgpu';
import { LayerStructure } from '../CloudLayers.js';
import { CloudTypeBlendNodes } from '../experimental/cloudTypeMap.js';
import { ConvectiveDeps } from '../experimental/convectiveProfile.js';
export declare function zeroInactiveLanes(value: Node<'vec4'>, active: LayerStructure['active']): Node<'vec4'>;
export type WeatherSampler = (texCoord: Node<'vec2'>, mipLevel: Node<'float'>) => Node<'vec4'>;
export declare function createSampleWeather(localWeatherTexture: TextureNode, localWeatherRepeat: Node<'vec2'>, localWeatherOffset: Node<'vec2'>, minLayerHeights: Node<'vec4'>, maxLayerHeights: Node<'vec4'>, weatherExponents: Node<'vec4'>, shapeAlteringBiases: Node<'vec4'>, coverage: Node<'float'>, coverageFilterWidths: Node<'vec4'>, shadowLayerMask: Node<'vec4'>, channels: string, shadow: boolean, structure?: LayerStructure, weatherSampler?: WeatherSampler | null, convective?: ConvectiveDeps | null, cloudTypes?: CloudTypeBlendNodes): import('three/tsl').FnNode<[import('three').Vector2 | Node<"vec2">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, (import('three').Vector4 | Node<"vec4"> | undefined)?], Node<"vec4">>;
export declare function cpuSampleWeather(height: number, minLayerHeights: [number, number, number, number], maxLayerHeights: [number, number, number, number], weatherValues: [number, number, number, number], weatherExponents: [number, number, number, number], shapeAlteringBiases: [number, number, number, number], coverage: number, coverageFilterWidths: [number, number, number, number], shadowLayerMask: [number, number, number, number], shadow: boolean, structure?: LayerStructure, convective?: ConvectiveWeatherCPU | null): {
    heightFraction: [number, number, number, number];
    density: [number, number, number, number];
};
export interface ConvectiveWeatherCPU {
    cellMask: number;
    cellDensity: number;
}
