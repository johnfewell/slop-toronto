import { Texture } from 'three';
import { Node, TextureNode } from 'three/webgpu';
export declare const clipAABB: import('three/tsl').FnNode<[import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">], import('three/webgpu').VarNode<"vec4", Node<"vec4">>>;
export declare const OFFSETS_9: readonly [readonly [-1, -1], readonly [-1, 1], readonly [1, -1], readonly [1, 1], readonly [1, 0], readonly [0, -1], readonly [0, 1], readonly [-1, 0]];
export declare const OFFSETS_4: readonly [readonly [1, 0], readonly [0, -1], readonly [0, 1], readonly [-1, 0]];
export declare function clipAABBCPU(current: [number, number, number, number], history: [number, number, number, number], minColor: [number, number, number, number], maxColor: [number, number, number, number]): [number, number, number, number];
export declare function varianceClippingCPU(current: [number, number, number, number], neighbours: [number, number, number, number][], history: [number, number, number, number], gamma: number): [number, number, number, number];
export interface VarianceClippingOptions {
    samples?: 4 | 9;
    array?: boolean;
}
export declare function varianceClipping(inputBuffer: Texture | TextureNode, options?: VarianceClippingOptions): import('three/tsl').FnNode<[Node<"ivec2"> | Node<"ivec3">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec4", Node<"vec4">>>;
export declare function varianceClippingUv(inputBuffer: Texture, options?: Pick<VarianceClippingOptions, 'samples'>): import('three/tsl').FnNode<[import('three').Vector2 | Node<"vec2">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec4", Node<"vec4">>>;
