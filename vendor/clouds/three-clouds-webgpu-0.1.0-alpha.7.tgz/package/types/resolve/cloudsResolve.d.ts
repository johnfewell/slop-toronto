import { Texture } from 'three';
import { Node, TextureNode } from 'three/webgpu';
export declare const CLOUDS_TEMPORAL_ALPHA = 0.1;
export declare function getClosestFragmentCPU(buffer: {
    r: number;
    g: number;
    b: number;
    a: number;
}[], width: number, cx: number, cy: number): {
    r: number;
    g: number;
    b: number;
    a: number;
};
export declare function isCurrentFrameCPU(pixelX: number, pixelY: number, frame: number): boolean;
export interface CloudsResolveDeps {
    cloudHistoryValid?: Node<'bool'>;
    shadowHistoryValid?: Node<'bool'>;
    colorBuffer: Texture;
    depthVelocityBuffer: Texture;
    colorHistoryNode: TextureNode;
    resolveWidth: Node<'float'>;
    resolveHeight: Node<'float'>;
    frame: Node<'float'>;
    varianceGamma: Node<'float'>;
    temporalAlpha: Node<'float'>;
}
export declare function buildTemporalUpscale(deps: CloudsResolveDeps): import('three/webgpu').VarNode<"vec4", TextureNode<"vec4">>;
export declare function buildTemporalAntialiasing(deps: CloudsResolveDeps): import('three/webgpu').VarNode<"vec4", TextureNode<"vec4">>;
export declare const cloudsResolveStruct: import('three/tsl').Struct;
export interface CloudsResolveShadowLengthDeps {
    shadowLengthBuffer: Texture;
    shadowLengthHistoryNode: TextureNode;
}
export interface CloudsResolveOutputs {
    color: Node<'vec4'>;
    shadowLength: Node<'vec4'> | null;
}
export declare function buildCloudsResolve(deps: CloudsResolveDeps, shadowLength: CloudsResolveShadowLengthDeps | null, temporalUpscale: boolean): CloudsResolveOutputs;
