import { Node } from 'three/webgpu';
export declare const perlin: import('three/tsl').FnNode<[import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">], Node<"float">>;
