import { Node } from 'three/webgpu';
export declare const perlinWorley: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"float">>;
export declare const worleyFbm: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"float">>;
export declare const cloudShape: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"float">>;
export declare const cloudShapeDetail: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"float">>;
