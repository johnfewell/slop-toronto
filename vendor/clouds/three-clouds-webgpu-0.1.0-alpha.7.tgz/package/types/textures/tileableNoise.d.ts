import { Node } from 'three/webgpu';
export declare const hash: import('three/tsl').FnNode<[number | Node<"float"> | Node<"uint">], Node<"float">>;
export declare const valueNoise: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">], Node<"float">>;
export declare const worleyNoise: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], Node<"float">>;
export declare function createPerlinFbm(octaveCount: number): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">], Node<"float">>;
