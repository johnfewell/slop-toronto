import { Node } from 'three/webgpu';
export declare const localWeather: import('three/tsl').FnNode<[import('three').Vector2 | Node<"vec2">], import('three/webgpu').JoinNode<"vec4">>;
