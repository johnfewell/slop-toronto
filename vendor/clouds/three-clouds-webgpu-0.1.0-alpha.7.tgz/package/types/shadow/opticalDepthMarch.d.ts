import { Node } from 'three/webgpu';
export declare const MIP_LEVELS: readonly [0, 0.5, 1, 2];
export declare const getShadowRayNearFar: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').JoinNode<"vec2">>;
export interface CascadeSetup {
    rayOrigin: Node<'vec3'>;
    rayDirection: Node<'vec3'>;
    maxRayDistance: Node<'float'>;
}
export declare function buildCascadeSetup(clipXY: Node<'vec2'>, inverseShadowMatrix: Node<'mat4'>, worldToECEFMatrix: Node<'mat4'>, altitudeCorrection: Node<'vec3'>, sunDirection: Node<'vec3'>, bottomRadius: Node<'float'>, shadowTopHeight: Node<'float'>, shadowBottomHeight: Node<'float'>): CascadeSetup;
export interface OpticalDepthMarchDeps {
    sampleWeather: (uv: Node<'vec2'>, height: Node<'float'>, mipLevel: Node<'float'>, heightFraction?: Node<'vec4'>) => Node<'vec4'>;
    sampleMedia: (weatherDensity: Node<'vec4'>, weatherHeightFraction: Node<'vec4'>, position: Node<'vec3'>, uv: Node<'vec2'>, mipLevel: Node<'float'>, jitter: Node<'float'>) => Node<'vec4'>;
    bottomRadius: Node<'float'>;
    minIntervalHeights: Node<'vec3'>;
    maxIntervalHeights: Node<'vec3'>;
    minLayerHeights: Node<'vec4'>;
    maxLayerHeights: Node<'vec4'>;
    maxIterationCount: Node<'float'>;
    minStepSize: Node<'float'>;
    maxStepSize: Node<'float'>;
    minDensity: Node<'float'>;
    minExtinction: Node<'float'>;
    minTransmittance: Node<'float'>;
    opticalDepthTailScale: Node<'float'>;
    scatteringCoefficient: Node<'float'>;
    absorptionCoefficient: Node<'float'>;
    worldToUnit: Node<'float'>;
    temporalJitter: boolean;
}
export declare function createOpticalDepthMarch(deps: OpticalDepthMarchDeps): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').JoinNode<"vec4">>;
export interface OpticalDepthMarchCPUParams {
    maxIterationCount: number;
    minStepSize: number;
    maxStepSize: number;
    minDensity: number;
    minExtinction: number;
    minTransmittance: number;
    opticalDepthTailScale: number;
    worldToUnit: number;
    minIntervalHeights?: [number, number, number];
    maxIntervalHeights?: [number, number, number];
    heightAtDistance?: (distance: number) => number;
}
export interface OpticalDepthMarchCPUResult {
    frontDepth: number;
    meanExtinction: number;
    maxOpticalDepth: number;
    maxOpticalDepthTail: number;
}
export declare function cpuOpticalDepthMarch(maxRayDistance: number, stepSize: number, extinctionField: (distance: number) => number, params: OpticalDepthMarchCPUParams): OpticalDepthMarchCPUResult;
