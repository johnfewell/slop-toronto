import { Node } from 'three/webgpu';
import { CloudShadowDescriptor } from '../CloudsPassNode.js';
import { GroundShadowExtraDeps } from './sampleCloudShadowOpticalDepth.js';
export interface CloudShadowNodeDeps extends GroundShadowExtraDeps {
    descriptor: CloudShadowDescriptor;
    worldToECEFMatrix: Node<'mat4'>;
}
export interface CloudShadowNodeOptions {
    shadowSampleCount?: number;
}
export interface CloudShadowAtOptions extends CloudShadowNodeOptions {
    radius?: Node<'float'>;
    jitter?: Node<'float'>;
}
export declare function createCloudShadowNode(deps: CloudShadowNodeDeps, options?: CloudShadowNodeOptions): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
export declare const cloudShadowAtlasResolution: (descriptor: CloudShadowDescriptor) => Node<"vec2">;
export declare function cpuCloudShadowTransmittance(opticalDepth: number): number;
