import { Vector2, Vector3, Matrix4 } from 'three';
import { Node } from 'three/webgpu';
import { UniformArrayLike } from '../CloudsPassNode.js';
export declare const DEFAULT_SHADOW_RADIUS = 3;
export declare const MAX_FOOTPRINT_PX = 50;
export interface ShadowRadiusDeps {
    shadowMatrices: UniformArrayLike<'mat4'>;
    inverseShadowMatrices: UniformArrayLike<'mat4'>;
    shadowMapSize: Node<'vec2'>;
    projectionMatrix: Node<'mat4'>;
    viewMatrix: Node<'mat4'>;
    resolution: Node<'vec2'>;
    shadowRadius: Node<'float'>;
}
export declare function createGetShadowRadius(deps: ShadowRadiusDeps): import('three/tsl').FnNode<[Vector3 | Node<"vec3">], Node<"float">>;
export declare function remapClampedCPU(x: number, min1: number, max1: number, min2: number, max2: number): number;
export declare function shadowRadiusFromFootprintCPU(sizePx: number, shadowRadius?: number): number;
export interface ShadowRadiusFootprint {
    readonly sizePx: number;
    readonly radius: number;
    readonly worldSizeMetres: number;
}
export declare function shadowRadiusFromCascadeCPU(worldPosition: Vector3, shadowMatrix: Matrix4, inverseShadowMatrix: Matrix4, shadowMapSize: Vector2, viewProjection: Matrix4, resolution: Vector2, shadowRadius?: number): ShadowRadiusFootprint;
