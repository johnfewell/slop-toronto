import { Node } from 'three/webgpu';
export interface HazeMarchDeps {
    coverage: Node<'float'>;
    cameraHeight: Node<'float'>;
    bottomRadius: Node<'float'>;
    hazeDensityScale: Node<'float'>;
    hazeExponent: Node<'float'>;
    hazeScatteringCoefficient: Node<'float'>;
    hazeAbsorptionCoefficient: Node<'float'>;
    skyLightScale: Node<'float'>;
    phaseFunction: (cosTheta: Node<'float'>) => Node<'float'>;
    groundSunIrradiance: Node<'vec3'>;
    groundSkyIrradiance: Node<'vec3'>;
}
export declare function createApproximateHaze(deps: HazeMarchDeps): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec4", import('three/webgpu').ConstNode<"vec4", import('three').Vector4>>>;
export declare function blendHaze(color: Node<'vec4'>, haze: Node<'vec4'>): import('three/webgpu').JoinNode<"vec4">;
export declare function remapClampedCPU(value: number, inLow: number, inHigh: number): number;
export declare function approximateHazeCPU(normalDotDir: number, maxRayDistance: number, _cosTheta: number, shadowLength: number, coverage: number, cameraHeight: number, hazeDensityScale: number, hazeExponent: number, _hazeScatteringCoefficient: number, _hazeAbsorptionCoefficient: number): {
    transmittance: number;
    opticalDepth: number;
    shadowOpticalDepth: number;
};
export declare function blendHazeCPU(colorRgb: [number, number, number], colorA: number, hazeRgb: [number, number, number], hazeA: number): {
    rgb: [number, number, number];
    a: number;
};
export declare function getHazeRayNearFarCPU(cameraHeight: number, maxHeight: number, ground: boolean, cameraNear: number, firstX: number, secondZ: number): [number, number];
