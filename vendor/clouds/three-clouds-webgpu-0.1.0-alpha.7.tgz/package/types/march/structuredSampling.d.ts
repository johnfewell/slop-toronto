import { Node } from 'three/webgpu';
export declare const getStructureNormal: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec3", Node<"vec3">>>;
export declare const intersectStructuredPlanes: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], import('three/webgpu').JoinNode<"vec2">>;
