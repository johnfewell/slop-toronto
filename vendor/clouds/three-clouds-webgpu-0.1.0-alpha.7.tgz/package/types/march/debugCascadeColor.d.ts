import { Node } from 'three/webgpu';
export interface DebugCascadeColorDeps {
    getFadedCascadeIndex: (worldPosition: Node<'vec3'>, jitter: Node<'float'>) => Node<'int'>;
    ecefToWorldMatrix: Node<'mat4'>;
    altitudeCorrection: Node<'vec3'>;
    cascadeCount: number;
}
export declare function createDebugCascadeColor(deps: DebugCascadeColorDeps): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec3", import('three/webgpu').ConstNode<"vec3", import('three').Vector3>>>;
