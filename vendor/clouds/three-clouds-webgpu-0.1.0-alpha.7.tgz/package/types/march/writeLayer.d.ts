import { Node } from 'three/webgpu';
export declare const layerOutputStruct: import('three/tsl').Struct;
export declare const writeLayer: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').StructNode>;
