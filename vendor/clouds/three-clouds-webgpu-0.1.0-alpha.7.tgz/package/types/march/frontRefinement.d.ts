import { Node } from 'three/webgpu';
export declare function createRefineCloudFront(occupied: (position: Node<'vec3'>, mip: Node<'float'>, jitter: Node<'float'>) => Node<'bool'>): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"float", import('three/webgpu').ConvertNode<"float">>>;
export declare function refineCloudFrontCPU(occupied: (distance: number) => boolean, near: number, far: number): number;
export declare function createFrontTracker(refine: ReturnType<typeof createRefineCloudFront> | null): {
    initialize: () => void;
    record: (distance: Node<"float">, occupied: Node<"bool">) => void;
    refine: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"float", Node<"float">>>;
};
