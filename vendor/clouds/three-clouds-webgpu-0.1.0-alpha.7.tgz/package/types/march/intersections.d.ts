import { Node } from 'three/webgpu';
export declare function assertFourLaneIntersections(marker: unknown): void;
export declare function assertR186Kernels(atmosphereMarker: unknown, geospatialMarker: unknown, revision: string): void;
export declare const rayIntersectsGround: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], Node<"bool">>;
export declare const intersectionsStruct: import('three/tsl').Struct;
export declare const getIntersections: import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').StructNode>;
interface IntersectionMembers {
    ground: Node<'bool'>;
    first: Node<'vec4'>;
    second: Node<'vec4'>;
}
export declare const rayNearFarFrom: (intersections: () => IntersectionMembers) => import('three/tsl').FnNode<[number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec2", import('three/webgpu').ConstNode<"vec2", import('three').Vector2>>>;
export declare const getRayNearFar: import('three/tsl').FnNode<[boolean | Node<"bool">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec2", import('three/webgpu').ConstNode<"vec2", import('three').Vector2>>>;
export declare const getShadowRayNearFar: import('three/tsl').FnNode<[boolean | Node<"bool">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec2", import('three/webgpu').ConstNode<"vec2", import('three').Vector2>>>;
export declare const getHazeRayNearFar: import('three/tsl').FnNode<[boolean | Node<"bool">, import('three').Vector4 | Node<"vec4">, import('three').Vector4 | Node<"vec4">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], import('three/webgpu').VarNode<"vec2", import('three/webgpu').ConstNode<"vec2", import('three').Vector2>>>;
export {};
