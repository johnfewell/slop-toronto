import { QualityPreset, QualityPresetTarget, QualityPresetValues } from './qualityPresets.js';
/** What a governor drives: a `CloudsContext`, or anything shaped like one */
export interface QualityGovernorTarget extends QualityPresetTarget {
    qualityPreset: QualityPreset;
    qualityGovernor?: QualityGovernor | null;
}
/** 0 is the target's own settings, 1 the perf map's c3, 2 the lowEnd preset */
export type QualityGovernorLevel = 0 | 1 | 2;
export interface QualityGovernorStepEvent {
    from: QualityGovernorLevel;
    to: QualityGovernorLevel;
    /** Frames fed since arm() */
    frame: number;
    /** The frame time that completed the decision, 0 on disarm */
    frameMs: number;
    reason: 'late' | 'headroom' | 'disarm';
}
export interface QualityGovernorOptions {
    /** Frame interval above which a frame is late. Default 24, a missed vsync at 60 fps */
    budgetMs?: number;
    /** The window of recent frames a step down reads. Default 10 */
    stepDownFrames?: number;
    /** Frames without a late one before a step up. Default 120 */
    stepUpFrames?: number;
    /** The share of the window that must be late to step down. Default 0.5 */
    lateFraction?: number;
    /** Frame time that must accumulate between two steps. Default 3000 */
    cooldownMs?: number;
    /** Frames ignored after a step: the first after a rebuild is unlit and slow. Default 3 */
    settleFrames?: number;
    /** A step down this soon after a step up doubles the next step-up wait. Default 5000 */
    revertWindowMs?: number;
    /** Called after every level change */
    onStep?: (event: QualityGovernorStepEvent) => void;
}
type ResolvedOptions = Readonly<Required<Omit<QualityGovernorOptions, 'onStep'>>>;
/** The defaults every option falls back to */
export declare const qualityGovernorDefaults: ResolvedOptions;
export declare const QUALITY_GOVERNOR_LEVEL_1: QualityPresetValues;
/**
 * Steps a target between its own settings (level 0), the perf map's c3
 * (level 1) and the `lowEnd` preset (level 2), down when frames run late and
 * back up when headroom returns. The host feeds frame intervals: the library
 * never reads a clock. Opt-in: nothing happens until `arm()`.
 *
 * @remarks
 * Domain: rAF intervals in ms, one `update()` per frame. Late is over 24 ms,
 * a missed vsync at 60 fps. A step down follows half of the last ten frames
 * late, a step up 120 without one, and a step up that misses backs off
 * Mutation: a step writes the level through the target's setters, which
 * rebuild the graph and reset history. Level 0 restores the captured values
 * Ownership: one governor per target, registered by `createQualityGovernor`
 */
export declare class QualityGovernor {
    readonly options: ResolvedOptions;
    private readonly onStep;
    private readonly target;
    private _level;
    private _enabled;
    private base;
    private frame;
    private readonly lateFlags;
    private lateInLong;
    private settling;
    private sinceStepMs;
    private elapsedMs;
    private upCooldownMs;
    private lastUpAtMs;
    private readonly _events;
    constructor(target: QualityGovernorTarget, options?: QualityGovernorOptions);
    /** The current level, 0 until a step down */
    get level(): QualityGovernorLevel;
    /** True between `arm()` and `disarm()` */
    get enabled(): boolean;
    /** The last 64 level changes, oldest first */
    get events(): readonly QualityGovernorStepEvent[];
    /** Frames fed since `arm()` */
    get frames(): number;
    /**
     * Capture the target's current settings as level 0 and start governing.
     * A second call while armed does nothing.
     */
    arm(): void;
    /** Restore level 0 if needed and stop governing */
    disarm(): void;
    /**
     * Feed one frame interval in milliseconds, the delta between two
     * requestAnimationFrame timestamps. Decides at most one step per call.
     */
    update(frameMs: number): void;
    private expireBackoff;
    private count;
    private lateInShort;
    private decide;
    private step;
    private apply;
    private resetCounters;
    private record;
}
/**
 * Create a governor for a target and register it as the target's
 * `qualityGovernor`, which is what `applyReferenceMode` disarms. The governor
 * starts disarmed: call `arm()` to begin, and feed `update(frameMs)` per frame.
 */
export declare function createQualityGovernor(target: QualityGovernorTarget, options?: QualityGovernorOptions): QualityGovernor;
export {};
