import { Node } from 'three/webgpu';
declare const splitIlluminance: import('three/tsl').Struct;
export { splitIlluminance };
export declare function atmosphereWorldToUnit(): Node<'float'>;
export declare const cloudsSolarLuminance: import('three/tsl').FnNode<[], any>;
export declare function createCloudsSunSkyIrradiance(sunDirectionECEF: Node<'vec3'>): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">], any>;
export declare function createGroundSunSkyIrradiance(sunDirectionECEF: Node<'vec3'>): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], any>;
export interface SunSkyIrradianceCache {
    groundSun: Node<'vec3'>;
    groundSky: Node<'vec3'>;
    cloudsMinSun: Node<'vec3'>;
    cloudsMinSky: Node<'vec3'>;
    cloudsMaxSun: Node<'vec3'>;
    cloudsMaxSky: Node<'vec3'>;
}
export declare function createSunSkyIrradianceCache(sunDirectionECEF: Node<'vec3'>, cameraPositionECEF: Node<'vec3'>, bottomRadius: Node<'float'>, minHeight: Node<'float'>, maxHeight: Node<'float'>): SunSkyIrradianceCache;
export declare function createCloudsSunSkyIrradianceInterpolated(cache: SunSkyIrradianceCache, minHeight: Node<'float'>, maxHeight: Node<'float'>): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], import('three/webgpu').StructNode>;
export declare function createGroundSunSkyIrradianceInterpolated(cache: SunSkyIrradianceCache): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], import('three/webgpu').StructNode>;
export declare function createGroundIndirectIlluminance(sunDirectionECEF: Node<'vec3'>): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, number | Node<"float"> | Node<"uint">], any>;
export declare function createIndirectLuminance(sunDirectionECEF: Node<'vec3'>): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">], any>;
export declare function createIndirectLuminanceToPoint(sunDirectionECEF: Node<'vec3'>): import('three/tsl').FnNode<[import('three').Vector3 | Node<"vec3">, import('three').Vector3 | Node<"vec3">, import('three').Vector2 | Node<"vec2">], any>;
export declare const RECIPROCAL_PI4: number;
