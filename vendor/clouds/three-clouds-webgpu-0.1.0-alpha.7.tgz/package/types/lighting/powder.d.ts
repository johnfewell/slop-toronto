import { Node } from 'three/webgpu';
export declare const powderTerm: import('three/tsl').FnNode<[number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">, number | Node<"float"> | Node<"uint">], Node<"float">>;
